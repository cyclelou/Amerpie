---
title: A. A. Milne
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-03-12
attribution:
 
Author: 
fileClass: Quotes
source: A. A. Milne,
topics:
  - Organizing
  - Relaxation
  - Possibility
---

# A. A. Milne

[[+Quotes MOC|Quotes]]  

quote:: Organizing is what you do before you do something, so that when you do it, it is not all mixed up.  
quote:: Rivers know this: there is no hurry. We shall get there some day.  
quote:: People say nothing is impossible, but I do nothing every day.  
