---
title: Abraham Lincoln
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Abraham Lincoln
Author: 
fileClass: Quotes
source: 
topics:
  - Responsibility
  - Wisdom
  - Character
  - Success
---

[[+Quotes MOC]]

# Abraham Lincoln

quote:: You cannot escape the responsibility of tomorrow by evading it today.  
Abraham Lincoln  
^responsibility

quote:: I have been driven many times upon my knees by the overwhelming conviction that I had no where else to go. My own wisdom and that of all about me seemed insufficient for that day.  
^wisdom

quote:: Character is like a tree and reputation is like a shadow. The shadow is what we think of it; the tree is the real thing.  
^character

quote:: Always bear in mind that your resolution to succeed is more important than any one thing.  
^success
