---
attribution:
  - Abraham Lincoln
source: 
tags:
  - quote
topics:
  - responsibility
creation date: 2024-01-26
modification date: 2024-01-31
fileClass: Quotes
title: Abraham Lincoln
---

# Abraham Lincoln

You cannot escape the responsibility of tomorrow by evading it today.  
Abraham Lincoln
