---
title: Adam Clark
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-10
attribution:
  - Adam Clark
 
fileClass: Quotes
source:
  - The Gently Mad
 
topics:
  - Risk
---

# Adam Clark

[[+Quotes MOC|Quotes]]  

quote:: The greatest risk is not taking one.
