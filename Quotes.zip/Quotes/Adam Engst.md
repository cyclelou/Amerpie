---
attribution:
  - Adam Engst
source: Tidbits
tags:
  - quote
topics:
  - Learning
  - Education
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Adam Engst
---

# Adam Engst

We should never turn down an opportunity to learn — that's the secret to eternal youth.
