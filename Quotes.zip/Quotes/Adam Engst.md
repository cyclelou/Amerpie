---
title: Adam Engst
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-10
attribution:
  - Adam Engst
 
fileClass: Quotes
source:
  - Tidbits
 
topics:
  - Learning
  - Education
---

[[+Quotes MOC|Quotes]]

# Adam Engst

quote:: We should never turn down an opportunity to learn — that's the secret to eternal youth.
