---
title: Adam Savage
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-11
attribution:
  - Adam Savage
fileClass: Quotes
source: ""
topics:
  - Science
  - Management
---

# Adam Savage

[[+Quotes MOC|Quotes]]  

quote:: The only difference between science and screwing around is writing it down.  
^science

quote:: This is not a problem to solve, it's a paradox (or process) to manage.
