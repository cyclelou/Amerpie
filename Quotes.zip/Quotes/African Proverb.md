---
title: African Proverb
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-10
attribution:
  - African Proverb
 
fileClass: Quotes
source: ""
topics:
  - Togetherness
---

# African Proverb

[[+Quotes MOC|Quotes]]

quote:: If you want to go fast, go alone. If you want to go far, go together.
