---
attribution:
  - Alian de Botton
source: 
tags:
  - quote
topics:
  - personality
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
created: 2024-01-11
title: Alain de Botton
aliases: [Alain De Botton]
linter-yaml-title-alias: Alain De Botton
---

# Alain De Botton

"The largest part of what we call 'personality' is determined by how we've opted to defend ourselves against anxiety and sadness."  
– Alain de Botton
