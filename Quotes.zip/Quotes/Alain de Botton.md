---
title: Alain de Botton
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-13
attribution:
  - Alian de Botton
 
created: 2024-01-11
fileClass:
  - Quotes
source: ""
topics:
  - Personality
---

[[+Quotes MOC|Quotes]]

# Alain De Botton

quote:: "The largest part of what we call 'personality' is determined by how we've opted to defend ourselves against anxiety and sadness."  
