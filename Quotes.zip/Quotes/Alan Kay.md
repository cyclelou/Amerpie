---
title: Alan Kay
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-10
attribution:
  - Alan Kay
 
fileClass: Quotes
source: ""
topics:
  - Worry
---

# Alan Kay

[[+Quotes MOC|Quotes]]

quote:: Don't worry about what anybody else is going to do. The best way to predict the future is to invent it.
