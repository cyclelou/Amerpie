---
title: Alan Moore
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-10
attribution:
  - Alan Moore
 
fileClass: Quotes
source: ""
topics:
  - Imagination
---

# Alan Moore

[[+Quotes MOC|Quotes]]

quote:: I have a theory, which has not let me down so far, that there is an inverse relationship between imagination and money. Because the more money and technology that is available to create a work, the less imagination there will be in it.
