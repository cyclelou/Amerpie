---
attribution:
  - Albert Camus
source: 
topics:
  - Philosophy
  - Positive Thinking
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Albert Camus
---

# Albert Camus

`= this.name` `= this.quote`
