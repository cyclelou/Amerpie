---
title: Albert Camus
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-10
attribution:
  - Albert Camus
 
fileClass:
  - Quotes
source: ""
topics:
  - Philosophy
  - Positive Thinking
---

[[+Quotes MOC|Quotes]]

# Albert Camus

quote:: "The welfare of humanity is always the alibi of tyrants."  
— Albert Camus

quote:: "In the depth of winter I finally learned that within me there was an invincible summer."  
— Albert Camus
