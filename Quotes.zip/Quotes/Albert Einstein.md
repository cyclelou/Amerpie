---
attribution:
  - Albert Einstein
source: 
topics:
  - cycling
  - philosophy
tags:
  - quote
fileClass: Quotes
title: Albert Einstein
creation date: 2024-01-31
modification date: 2024-01-31
---

# Albert Einstein

Life is like riding a bicycle. To keep your balance you must keep moving.
