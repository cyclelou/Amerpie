---
title: Albert F. Schlieder
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Albert F. Schlieder
fileClass: Quotes
source: 
topics:
  - Judgement
---

# Albert F. Schlieder

[[+Quotes MOC|Quotes]]

quote:: We tend to judge others by their behavior and ourselves by our intentions.
