---
title: Albert Schweitzer
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-25
attribution: Albert Schweitzer
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Optimism
---

[[+Quotes MOC|Quotes]]

# Albert Schweitzer

quote:: To the question whether I am a pessimist or an optimist, I answer that my knowledge is pessimistic, but my willing and hoping are optimistic. ^optimistic

---


