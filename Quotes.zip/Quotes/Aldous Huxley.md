---
attribution:
  - Aldous Huxley
source: 
topics:
  - History
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Aldous Huxley
---

# Aldous Huxley

That men do not learn very much from the lessons of history is the most important of all the lessons that history has to teach
