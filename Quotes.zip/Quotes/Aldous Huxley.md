---
title: Aldous Huxley
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Aldous Huxley
fileClass:
  - Quotes
source: ""
topics:
  - History
---

[[+Quotes MOC|Quotes]]

# Aldous Huxley

quote:: That men do not learn very much from the lessons of history is the most important of all the lessons that history has to teach
