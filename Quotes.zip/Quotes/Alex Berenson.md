---
title: Alex Berenson
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Alex Berenson
fileClass: Quotes
source: ""
topics:
  - Hope
---

# Alex Berenson

[[+Quotes MOC|Quotes]]

quote:: Against hysteria, satire. Against storytelling, data. Against groupthink, reporting. Against authoritarianism, bravery. Most of all: against millennialism, realism. And hope.
