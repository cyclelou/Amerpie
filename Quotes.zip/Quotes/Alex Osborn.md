---
title: Alex Osborn
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
 
fileClass: Quotes
source: ""
topics:
  - Worry
  - Imagination
---

# Alex Osborn

[[+Quotes MOC|Quotes]]

quote:: Worry is essentially a misuse of imagination.
