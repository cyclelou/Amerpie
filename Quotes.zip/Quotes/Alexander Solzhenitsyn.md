---
attribution:
  - Alexander Solzhenitsyn
source: 
topics:
  - Truth
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Alexander Solzhenitsyn
---

# Alexander Solzhenitsyn

Everything you add to the truth subtracts from the truth.
