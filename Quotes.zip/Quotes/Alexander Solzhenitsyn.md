---
title: Alexander Solzhenitsyn
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Alexander Solzhenitsyn
fileClass:
  - Quotes
source: ""
topics:
  - Truth
  - Honesty
  - Courage
  - Evil
---

[[+Quotes MOC|Quotes]]

# Alexander Solzhenitsyn

quote:: Everything you add to the truth subtracts from the truth.

quote:: You can resolve to live your life with integrity. Let your credo be this: Let the lie come into the world, let it even triumph. But not through me.

quote:: The simple step of a courageous individual is not to take part in the lie. One word of truth outweighs the world. ^courage

quote:: "In keeping silent about evil, in burying it so deep within us that no sign of it appears on the surface, we are implanting it, and it will rise up a thousand fold in the future. When we neither punish nor reproach evildoers, we are not simply protecting their trivial old age, we are thereby ripping the foundations of justice from beneath new generations."  
