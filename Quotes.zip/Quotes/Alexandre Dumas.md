---
attribution:
  - Alexandre Dumas
source: 
topics:
  - Philosophy
  - Truth
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Alexandre Dumas
---

# Alexandre Dumas

All generalizations are dangerous, even this one.
