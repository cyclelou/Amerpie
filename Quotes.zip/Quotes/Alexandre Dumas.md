---
title: Alexandre Dumas
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Alexandre Dumas
 
fileClass:
  - Quotes
source: ""
topics:
  - Philosophy
  - Truth
---

[[+Quotes MOC|Quotes]]

# Alexandre Dumas

quote:: All generalizations are dangerous, even this one.
