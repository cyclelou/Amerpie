---
attribution:
  - Alexis Carrel
source: 
tags:
  - quote
topics:
  - advice
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
date: 2024-01-21
title: Alexis Carrel
---

# Alexis Carrel

Alexis Carrel  
"All of us, at certain moments of our lives, need to take advice and to receive help from other people."
