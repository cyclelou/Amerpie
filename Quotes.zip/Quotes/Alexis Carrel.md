---
title: Alexis Carrel
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-13
attribution:
  - Alexis Carrel
date: 2024-01-21
fileClass: Quotes
source: ""
topics:
  - Advice
---

[[+Quotes MOC|Quotes]]

# Alexis Carrel

quote:: "All of us, at certain moments of our lives, need to take advice and to receive help from other people."
