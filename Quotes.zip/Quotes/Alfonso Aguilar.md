---
title: Alfonso Aguilar
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Alfonso Aguilar
fileClass: Quotes
source: Associated Press
topics:
  - Politics
---

[[+Quotes MOC|Quotes]]

# Alfonso Aguilar

quote:: "The initial reaction from Republicans is going to be very ugly and not well thought-out, unfortunately," said Alfonso Aguilar, former chief of the U.S. Office of Citizenship in the George W. Bush administration and executive director of Latino Partnership for Conservative Principles on Obama's post election immigration proposals."
