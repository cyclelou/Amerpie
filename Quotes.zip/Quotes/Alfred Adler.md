---
title: Alfred Adler
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Alfred Adler
fileClass: Quotes
source: ""
topics:
  - Empathy
---

# Alfred Adler

[[+Quotes MOC|Quotes]]

quote:: It is the individual who is not interested in his fellow men who has the greatest difficulties in life and provides the greatest injury to others. It is from among such individuals that all human failures spring.
