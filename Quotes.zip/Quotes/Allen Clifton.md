---
title: Allen Clifton
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Allen Clifton
fileClass: Quotes
source: Forward Progressives
topics:
  - Labor
  - Capitalism
  - Work
---

[[+Quotes MOC|Quotes]]

# Allen Clifton

quote:: If their workers are underpaid, overworked, lack benefits or safe working conditions, in the mind of a sociopath—who cares? Quit and get another job or stop complaining because they don't owe workers anything. They only have an obligation to themselves and their own self interests. If workers want better pay, safer working conditions or benefits—find another job. If you can't find a job which offers any of that—too bad.
