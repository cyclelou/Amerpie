---
title: Amelia Earhart
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Amelia Earhart
fileClass: Quotes
source: ""
topics:
  - Action
---

# Amelia Earhart

[[+Quotes MOC|Quotes]]

quote:: The most difficult thing is the decision to act. The rest is merely tenacity.
