---
attribution:
  - Amy Chua
source: 
topics:
  - Courage
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Amy Chua
---

# Amy Chua

A foreign accent is a sign of bravery.
