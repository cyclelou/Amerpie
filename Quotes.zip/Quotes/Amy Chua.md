---
title: Amy Chua
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Amy Chua
fileClass: Quotes
source: ""
topics:
  - Courage
---

[[+Quotes MOC|Quotes]]

# Amy Chua

quote:: A foreign accent is a sign of bravery.
