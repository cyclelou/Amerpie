---
title: Anatole France
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Anatole France
fileClass: Quotes
source: ""
topics:
  - Intelligence
  - Speech
  - Law
---

[[+Quotes MOC|Quotes]]

# Anatole France

quote:: Even if fifty million people say something really stupid, it is, nevertheless, still really stupid.

# Anatole France

The law, in its majestic equality, forbids rich and poor alike to sleep under bridges, beg in the streets or steal bread.
