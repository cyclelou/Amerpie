---
title: Anatole France
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Anatole France
fileClass: Quotes
source: 
topics:
  - Intelligence
  - Speech
  - Law
---

# Anatole France

Even if fifty million people say something really stupid, it is, nevertheless, still really stupid.

# Anatole France

The law, in its majestic equality, forbids rich and poor alike to sleep under bridges, beg in the streets or steal bread.
