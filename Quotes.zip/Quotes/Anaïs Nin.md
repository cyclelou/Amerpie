---
title: Anaïs Nin
url: 
tags:
  - quote
creation date: 2024-01-22
modification date: 2024-02-05
attribution:
  - Anaïs Nin
fileClass: Quotes
source: 
topics:
  - Self
  - Philosophy
  - Dreams
---

# Anaïs Nin

There is not one big cosmic meaning for all, there is only the meaning we each give to our life.

# Anaïs Nin

We don't see things as they are; we see them as we are

# Anaïs Nin

"Dreams are necessary to life."
