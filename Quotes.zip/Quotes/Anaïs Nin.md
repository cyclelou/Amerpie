---
title: Anaïs Nin
url: 
tags:
  - Quote
creation date: 2024-01-22
modification date: 2024-02-13
attribution:
  - Anaïs Nin
fileClass: Quotes
source: ""
topics:
  - Self
  - Philosophy
  - Dreams
---

[[+Quotes MOC|Quotes]]

# Anaïs Nin

quote:: There is not one big cosmic meaning for all, there is only the meaning we each give to our life.

# Anaïs Nin

quote:: We don't see things as they are; we see them as we are

# Anaïs Nin

quote:: "Dreams are necessary to life."
