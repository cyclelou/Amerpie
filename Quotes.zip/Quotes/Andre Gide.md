---
title: Andre Gide
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Andre Gide
fileClass: Quotes
source: ""
topics:
  - Speech
  - Knowledge
---

# Andre Gide

[[+Quotes MOC|Quotes]]

quote:: Everything has been said before but because no one ever listens you always have to say it again.  
^again
