---
title: Andrew Jackson
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Andrew jackson
fileClass: Quotes
source: ""
topics:
  - Humility
---

# Andrew Jackson

[[+Quotes MOC|Quotes]]

quote:: Any man worth his salt will stick up for what he believes right, but it takes a slightly better man to acknowledge instantly and without reservation that he is in error.
