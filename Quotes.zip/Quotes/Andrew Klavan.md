---
title: Andrew Klavan
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution: 
fileClass: Quotes
source: ""
topics:
  - Desire
  - Wisdom
  - Fear
---

[[+Quotes MOC|Quotes]]

# Andrew Klavan

quote:: Fear nothing, do right.

quote:: Your past shapes your desires which shape your future.

quote:: Wisdom is to love the good.
