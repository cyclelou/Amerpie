---
title: Andy Andrews
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Andy Andrews
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Leadership
  - Struggle
  - Action
---

# Andy Andrews

[[+Quotes MOC|Quotes]]

quote:: It is never the duty of a leader to struggle for someone else; a leader must encourage others to struggle and assure them that the struggles are worthwhile.

quote:: When I am faced with the choice of doing nothing or doing something, I will always choose to act. (Chamberlain)
