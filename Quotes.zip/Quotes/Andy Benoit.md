---
attribution:
  - Andy Benoit
source: 
topics:
  - Philosophy
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Andy Benoit
---

# Andy Benoit

Most geniuses—especially those who lead others—prosper not by deconstructing intricate complexities but by exploiting unrecognized simplicities.
