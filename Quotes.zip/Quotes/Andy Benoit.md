---
title: Andy Benoit
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Andy Benoit
 
fileClass:
  - Quotes
source: ""
topics:
  - Philosophy
---

[[+Quotes MOC|Quotes]]

# Andy Benoit

quote:: Most geniuses—especially those who lead others—prosper not by deconstructing intricate complexities but by exploiting unrecognized simplicities.
