---
attribution:
  - Anne Frank
source: The Diary Of Anne Frank
topics:
  - Peace
  - Hope
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Anne Frank
---

# Anne Frank

Things will change, and men become good again. And these pitiless days will come to an end, and the world will once again, know order, trust and peace.
