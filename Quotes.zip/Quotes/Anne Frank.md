---
title: Anne Frank
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Anne Frank
 
fileClass: Quotes
source: The Diary Of Anne Frank
topics:
  - Peace
  - Hope
---

[[+Quotes MOC|Quotes]]

# Anne Frank

quote:: Things will change, and men become good again. And these pitiless days will come to an end, and the world will once again, know order, trust and peace.
