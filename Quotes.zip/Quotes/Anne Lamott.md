---
title: Anne Lamott
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Anne Lamott
fileClass: Quotes
source: ""
topics:
  - Marriage
  - Self-confidence
---

[[+Quotes MOC|Quotes]]

# Anne Lamott

quote:: A good marriage is one in which each spouse secretly thinks he or she got the better deal, and this is true also of our friendships.

# Anne Lamott

[[+Quotes MOC|Quotes]]

You get your confidence and intuition back by trusting yourself, by being militantly on your own side.
