---
attribution:
  - Anne Lamott
source: 
topics:
  - Friendship
  - Marriage
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Anne Lamott
---

# Anne Lamott

A good marriage is one in which each spouse secretly thinks he or she got the better deal, and this is true also of our friendships.
