---
title: Annie Jean-Veau
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Annie Jean-Veau
fileClass: Quotes
source: Radiolab
topics:
  - Decisions
  - Rationality
---

# Annie Jean-Veau

[[+Quotes MOC|Quotes]]

quote:: We don't make purely rational decisions about important things in our lives very often.
