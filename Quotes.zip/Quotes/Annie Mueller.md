---
title: Annie Mueller
url: 
tags:
  - Quote
creation date: 2024-01-23
modification date: 2024-02-13
attribution:
  - Annie Mueller
 
fileClass:
  - Quotes
source: ""
topics:
  - Understanding
  - Empathy
---

[[+Quotes MOC|Quotes]]

# Annie Mueller

> [!quote] AnnieMeller  
> quote:: To understand someone else's perspective (even a little), you've got to acknowledge that your own is limited. That your views come not from absolute truth but from subjective experience.
