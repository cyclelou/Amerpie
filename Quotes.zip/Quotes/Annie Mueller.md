---
attribution:
  - Annie Mueller
source: 
tags:
  - quote
topics:
  - understanding
  - empathy
creation date: 2024-01-23
modification date: 2024-01-31
fileClass: Quotes
title: Annie Mueller
---

# Annie Mueller

> [!quote] AnnieMeller  
> To understand someone else's perspective (even a little), you've got to acknowledge that your own is limited. That your views come not from absolute truth but from subjective experience.
