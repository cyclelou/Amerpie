---
title: Annie Murphy Paul
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - Annie Murphy Paul
fileClass: Quotes
source: ""
topics:
  - Enrichment
  - Thinking
---

# Annie Murphy Paul

[[+Quotes MOC|Quotes]]

quote:: We extend beyond our limits, not by revving our brains like a machine or bulking them up like a muscle—but by strewing our world with rich materials, and by weaving them into our thoughts.
