---
title: Anonymous
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Anonymous
 
fileClass:
  - Quotes
source: ""
topics:
  - Idiocy
  - Flying
---

[[+Quotes MOC|Quotes]]

# Anonymous

quote:: Arguing with an idiot is like playing chess with a pigeon. It'll just knock over all the pieces, shit on the board, and strut about like it won anyway.

# Anonymous

[[+Quotes MOC|Quotes]]  

quote:: To most people, the sky is the limit. To aviation, the sky is home.
