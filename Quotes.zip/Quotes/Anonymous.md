---
attribution:
  - Anonymous
source: 
topics:
  - Idiocy
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Anonymous
---

# Anonymous

Arguing with an idiot is like playing chess with a pigeon. It'll just knock over all the pieces, shit on the board, and strut about like it won anyway.
