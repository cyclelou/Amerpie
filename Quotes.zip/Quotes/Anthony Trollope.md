---
title: Anthony Trollope
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Anthony Trollope
fileClass: Quotes
source: ""
topics:
  - Work
---

[[+Quotes MOC|Quotes]]

# Anthony Trollope

quote:: A small daily task, if it be really daily, will beat the labours of a spasmodic Hercules.
