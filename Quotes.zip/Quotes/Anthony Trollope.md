---
attribution:
  - Anthony Trollope
source: 
topics:
  - Work
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Anthony Trollope
---

# Anthony Trollope

A small daily task, if it be really daily, will beat the labours of a spasmodic Hercules.
