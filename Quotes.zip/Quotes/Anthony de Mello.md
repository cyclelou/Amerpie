---
title: Anthony de Mello
url: 
tags: quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - Anthony de Mello
fileClass: Quotes
source: 
topics:
  - Revolution
---

# Anthony De Mello

Most people end up being conformists; they adapt to prison life. A few become reformers; they fight for better lighting, better ventilation. Hardly anyone becomes a rebel, a revolutionary who breaks down the prison walls. You can only be a revolutionary when you see the prison walls in the first place.
