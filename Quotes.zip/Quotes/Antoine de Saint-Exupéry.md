---
attribution:
  - Antoine de Saint-Exupéry
source: 
tags:
  - quote
topics:
  - love
  - goals
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Antoine de Saint-Exupéry
aliases: [Antoine De Saint-Exupéry]
linter-yaml-title-alias: Antoine De Saint-Exupéry
---

# Antoine De Saint-Exupéry

"Love does not consist of gazing at each other but in looking outward together in the same direction."  
​— Antoine de Saint-Exupéry, Wind, Sand and Stars​  
​
