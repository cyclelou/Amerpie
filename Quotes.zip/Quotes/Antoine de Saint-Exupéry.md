---
title: Antoine de Saint-Exupéry
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-13
attribution:
  - Antoine de Saint-Exupéry
 
fileClass: Quotes
source: Wind, Sand and Stars
topics:
  - Love
  - Goals
---

[[+Quotes MOC|Quotes]]

# Antoine De Saint-Exupéry

quote:: "Love does not consist of gazing at each other but in looking outward together in the same direction."  
​— Antoine de Saint-Exupéry,  
​
