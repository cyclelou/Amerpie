---
attribution:
  - Anton Chekhov
source: 
topics:
  - Love
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Anton Chekhov
---

# Anton Chekhov

Perhaps the feelings that we experience when we are in love represent a normal state. Being in love shows a person who he should be.
