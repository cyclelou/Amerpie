---
title: Anton Chekhov
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Anton Chekhov
 
fileClass:
  - Quotes
source: ""
topics:
  - Love
---

[[+Quotes MOC|Quotes]]

# Anton Chekhov

quote:: Perhaps the feelings that we experience when we are in love represent a normal state. Being in love shows a person who he should be.
