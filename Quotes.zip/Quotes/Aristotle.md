---
attribution:
  - Aristotle
source: 
topics:
  - Education
  - Philosophy
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Aristotle
---

# Aristotle

It is the mark of an educated mind to be able to entertain a thought without accepting it.
