---
title: Aristotle
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Aristotle
fileClass: Quotes
source: ""
topics:
  - Education
  - Philosophy
---

# Aristotle

quote:: It is the mark of an educated mind to be able to entertain a thought without accepting it.

# Aristotle

[[+Quotes MOC|Quotes]]  

If you want a virtue, act as if you already have it and then it will be yours.

Friendship is a single soul dwelling in two bodies.
