---
attribution:
  - Arthur Korstler
source: 
topics:
  - Creatvity
  - language
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Arthur Korstler
---

# Arthur Korstler

"Language can become a screen which stands between the thinker and reality. This is the reason why true creativity often starts where language ends."
