---
title: Arthur Korstler
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Arthur Korstler
 
fileClass:
  - Quotes
source: ""
topics:
  - Creatvity
  - Language
---

[[+Quotes MOC|Quotes]]

# Arthur Korstler

quote:: "Language can become a screen which stands between the thinker and reality. This is the reason why true creativity often starts where language ends."
