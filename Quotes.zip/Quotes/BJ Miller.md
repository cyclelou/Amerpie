---
title: BJ Miller
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: BJ Miller
Author: 
fileClass: Quotes
source: 
topics: Perspective
---

# BJ Miller

[[+Quotes MOC|Quotes]]

quote:: The small things ain't so small.
