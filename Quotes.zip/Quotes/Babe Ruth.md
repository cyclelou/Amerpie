---
title: Babe Ruth
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution: 
fileClass: Quotes
source: ""
topics:
  - Perseverance
---

# Babe Ruth

[[+Quotes MOC|Quotes]]

quote:: Every strike brings me closer to the next home run.
