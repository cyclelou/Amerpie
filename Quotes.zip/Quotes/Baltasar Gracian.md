---
attribution:
  - Baltasar Gracian
source: 
topics:
  - Decisions
  - sleep
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31 05:35
modification date: 2024-01-31 07:22
title: Baltasar Gracian
title: Baltasar Gracian
creation date: 2024-01-31 05:35
modification date: 2024-01-31 07:22
---


# Baltasar Gracian

It is better to sleep on things beforehand than lie awake about them afterwards.
