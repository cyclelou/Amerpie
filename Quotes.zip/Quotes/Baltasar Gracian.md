---
title: Baltasar Gracian
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Baltasar Gracian
 
fileClass:
  - Quotes
source: ""
topics:
  - Decisions
  - Sleep
---

[[+Quotes MOC]]

# Baltasar Gracian

quote:: It is better to sleep on things beforehand than lie awake about them afterwards.
