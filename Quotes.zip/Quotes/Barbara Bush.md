---
title: Barbara Bush
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - ""
fileClass: Quotes
source: ""
topics:
  - Relevance
---

# Barbara Bush

[[+Quotes MOC]]

quote:: What happens in your house is a lot more important than what happens in the White House.
