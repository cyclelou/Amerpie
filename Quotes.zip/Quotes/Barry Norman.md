---
title: Barry Norman
url: 
tags:
  - Quote
creation date: 2024-02-10
modification date: 2024-02-13
attribution:
  - Barry Norman
fileClass: Quotes
source: 
topics:
  - Censorship
---

[[+Quotes MOC]]

# Barry Norman

quote:: While children should be protected against potentially corrupting material, adults are too often over-protected. If they're old enough to choose a government, they're certainly old enough to decide what they want to watch on TV.
