---
title: Ben Franklin
url: 
tags:
  - Quote
creation date: 2024-01-28
modification date: 2024-02-18
attribution:
  - Ben Franklin
 
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Action
  - Thinking
  - Speech
---

[[+Quotes MOC]]

# Ben Franklin

quote:: "If everybody is thinking alike, then no one is thinking."

# Ben Franklin

quote:: Sloth, like rust, consumes… while the used key stays bright.

# Ben Franklin

quote:: Well done is better than well said.
