---
title: Ben Franklin
creation date: 2024-01-28
modification date: 2024-01-31
attribution:
  - Ben Franklin
source: 
tags:
  - quote
topics:
  - Action
  - thinking
  - Speech
fileClass: Quotes
---

# Ben Franklin

"If everybody is thinking alike, then no one is thinking."

# Ben Franklin

Sloth, like rust, consumes… while the used key stays bright.

# Ben Franklin

Well done is better than well said.
