---
title: Ben Horowitz
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution:
  - Ben Horowitz
Author: 
fileClass: Quotes
source: ""
topics:
  - ""
---

# Ben Horowitz

[[+Quotes MOC]]

quote:: Perhaps the most important thing that I learned as an entrepreneur was to focus on what I needed to get right and stop worrying about all the things that I did wrong or might do wrong.
