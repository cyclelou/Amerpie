---
attribution:
  - Ben Lovejoy
source: 
tags:
  - quote
topics:
  - technology
creation date: 2024-01-23
modification date: 2024-01-31
fileClass: Quotes
title: Ben Lovejoy
---

# Ben Lovejoy

It smiled at you as it started-up. You didn't have directory listings, you had images of folders. You didn't type the name of an application or file to open it, you used this strange new thing called a mouse to double-click it. When you made a word bold, it appeared in bold on the screen. You had different typefaces! It could talk to you! […]

I immediately knew this was what computers were supposed to be like. I wanted one.
