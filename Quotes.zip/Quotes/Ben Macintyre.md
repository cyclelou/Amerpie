---
attribution:
  - Ben Macintyre
source: Agent Zigzag
topics:
  - War
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Ben Macintyre
---

# Ben Macintyre

War is too messy to produce easy heroes and villains; there are always brave people on the wrong side, and evil men among the victors, and a mass of perfectly ordinary people struggling to survive and understand in between.
