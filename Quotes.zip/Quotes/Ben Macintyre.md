---
title: Ben Macintyre
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution:
  - Ben Macintyre
 
Author: 
fileClass:
  - Quotes
source:
  - Agent Zigzag
 
topics:
  - War
---

[[+Quotes MOC]]

# Ben Macintyre

quote:: War is too messy to produce easy heroes and villains; there are always brave people on the wrong side, and evil men among the victors, and a mass of perfectly ordinary people struggling to survive and understand in between.
