---
title: Ben Stein
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution:
  - Ben Stein
Author: 
fileClass: Quotes
source: ""
topics:
  - Decisions
---

# Ben Stein

[[+Quotes MOC|Quotes]]

quote:: The first step to getting the things you want out of life is this: Decide what you want.
