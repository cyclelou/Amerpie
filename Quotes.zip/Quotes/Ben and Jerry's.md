---
title: "Ben and Jerry's"
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-18
attribution:
  - Ben and Jerry's
 
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Racism
  - Privilege
---

[[+Quotes MOC]]

# Ben and Jerry's

quote:: Unless and until white America is willing to collectively acknowledge its privilege, take responsibility for its past and the impact it has on the present, and commit to creating a future steeped in justice, the list of names that George Floyd has been added to will never end. We have to use this moment to accelerate our nation's long journey towards justice and a more perfect union.

Ben and Jerry's
