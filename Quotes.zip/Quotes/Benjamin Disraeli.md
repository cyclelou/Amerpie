---
title: Benjamin Disraeli
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: []
Author: 
fileClass: Quotes
source: ""
topics:
  - Good
---

# Benjamin Disraeli

[[+Quotes MOC|Quotes]]

quote:: The greatest good you can do for others is not to just share your riches, but to reveal to them their own.
