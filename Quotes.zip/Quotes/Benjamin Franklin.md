---
title: Benjamin Franklin
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution:
  - Benjamin Franklin
Author: 
date: 2023-03-22T09:35
fileClass: Quotes
source: ""
topics:
  - Praise
  - Safety
  - Wealth
  - Action
  - Philosophy
updated: 2023-09-20T15:47
---

# Benjamin Franklin

quote:: I will speak ill of no man, and speak all the good I know of everybody.  
^praise

quote:: Those who would give up essential liberty to purchase a little temporary safety deserve neither liberty nor safety.  
^safety

quote:: Wealth is not his that has it, but his that enjoys it.  
^wealth

quote:: Well done is better than well said.  
^done

quote:: Be studious in your profession, and you will be learned. Be industrious and frugal and you will be rich. Be sober and temperate and you will be healthy. Be in general virtuous and you will be happy.  
^life
