---
title: Benjamin Mee
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: 
Author: Benjamin Mee
fileClass: Quotes
source: ""
topics:
  - Courage
---

# Benjamin Mee

[[+Quotes MOC|Quotes]]

quote:: Sometimes all you need is twenty seconds of insane courage. Just literally twenty seconds of just embarrassing bravery. And I promise you, something great will come of it. (We Bought A Zoo)
