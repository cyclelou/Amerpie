---
attribution:
  - Bernie Shine
source: Huffington Post
topics:
  - Politics
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Bernie Shine
---

# Bernie Shine

Trump claims he has a great memory. I agree. Unfortunately, like Mark Twain, he seems to be able to remember things whether they happened or not.
