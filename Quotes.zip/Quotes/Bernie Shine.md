---
title: Bernie Shine
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution:
  - Bernie Shine
 
Author: <% tp.file.title %>
fileClass:
  - Quotes
source:
  - Huffington Post
 
topics:
  - Politics
---

# Bernie Shine

[[+Quotes MOC]]

quote:: Trump claims he has a great memory. I agree. Unfortunately, like Mark Twain, he seems to be able to remember things whether they happened or not.
