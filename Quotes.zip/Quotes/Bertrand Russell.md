---
title: Bertrand Russell
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bertrand Russell
Author: 
fileClass: Quotes
source: 
topics:
  - Intelligence
  - Doubt
---

# Bertrand Russell

[[+Quotes MOC|Quotes]]

quote:: One of the painful things about our time is those who feel certainty are stupid, and those with any imagination and understanding are filled with doubt and indecision.
