---
title: Bill Bryson
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bill Bryson
Author: 
fileClass: Quotes
source: 
topics:
  - Technology
---

# Bill Bryson

[[+Quotes MOC|Quotes]]

quote:: Then it occurred to me that a computer is a stupid machine with the ability to do smart things, while computer programmers are smart people with the ability to do incredibly stupid things. They are, in short, a dangerously perfect match.
