---
title: Bill Clinton
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bill Clinton
Author: 
fileClass: Quotes
source: ""
topics:
  - Obfuscation
---

# Bill Clinton

[[+Quotes MOC|Quotes]]

quote:: That depends what your definition of the word 'is' is.
