---
title: Bill Murray
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bill Murray
Author: 
fileClass: Quotes
source: ""
topics:
  - Intelligence
---

# Bill Murray

[[+Quotes MOC]]

quote:: It's hard to win an argument with a smart person, but it's damn near impossible winning an argument with a stupid person.
