---
title: "Bill Tregle's Dad"
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bill Tregle's Dad
Author: 
fileClass: Quotes
source: ""
topics: Action
---

# Bill Tregle's Dad

[[+Quotes MOC|Quotes]]

quote:: It's amazing how much you can get done in a day if you just sit and you do it.
