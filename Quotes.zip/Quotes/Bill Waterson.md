---
title: Bill Waterson
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bill Waterson
Author: 
fileClass: Quotes
source: ""
topics:
  - Friendship
  - Time
---

# Bill Waterson

[[+Quotes MOC|Quotes]]

quote:: If your friends are contractual, you don't have any.

quote:: A day can really slip by when you're deliberately avoiding what you're supposed to do.
