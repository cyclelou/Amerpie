---
title: Billy Schwartz
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-03-03
attribution: Billy Schwartz
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Knowledge
---

# Billy Schwartz

[[+Quotes MOC|Quotes]]  
%% tags: quote memorize %%

quote:: Lee-la, lee-la, this life is but a game.  
Winners lose and losers win, the game is still the same.  
Lee-la, lee-la, this life is but a play.  
Those who say they know, don't know,  
And those who know, don't say.
