---
title: Billy Sunday
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Billy Sunday
Author: 
fileClass: Quotes
source: 
topics: Purpose
---

# Billy Sunday

[[+Quotes MOC|Quotes]]

quote:: More fail through a lack of purpose than lack of talent.
