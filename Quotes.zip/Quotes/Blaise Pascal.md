---
attribution:
  - Blaise Pascal
source: 
topics:
  - Truth
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Blaise Pascal
---

# Blaise Pascal

Truth is so obscure in these times, and falsehood so established, that unless we love the truth, we cannot know it
