---
title: Blaise Pascal
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution:
  - Blaise Pascal
 
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Truth
---

# Blaise Pascal

[[+Quotes MOC]]

quote:: Truth is so obscure in these times, and falsehood so established, that unless we love the truth, we cannot know it
