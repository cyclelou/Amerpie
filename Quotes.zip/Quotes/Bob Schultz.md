---
title: Bob Schultz
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bob Schultz
Author: 
fileClass: Quotes
source: ""
topics:
  - Work
  - Possibility
---

# Bob Schultz

[[+Quotes MOC|Quotes]]

quote:: What seems impossible will become possible when attacked with a lot of hard work.
