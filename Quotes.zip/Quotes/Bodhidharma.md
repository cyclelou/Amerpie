---
title: Bodhidharma
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bodhidharma
Author: 
fileClass: Quotes
source: 
topics:
  - Action
  - Knowledge
---

# Bodhidharma

[[+Quotes MOC|Quotes]]

All know the way. Few actually walk it.
