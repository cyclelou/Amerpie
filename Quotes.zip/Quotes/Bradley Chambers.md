---
title: Bradley Chambers
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution:
  - Bradley Chambers
 
Author: 
fileClass:
  - Quotes
source:
  - Back To School
 
topics:
  - Education
  - Technology
---

# Bradley Chambers

[[+Quotes MOC]]

quote:: I've never been a fan of pilot programs. When you are doing a technology deployment, you have to go all in. Pilots are essentially saying that we aren't sure what we are doing. Pilots are also a way to protect yourself from failure.
