---
attribution:
  - Bradley Chambers
source: Back To School
topics:
  - Education
  - Technology
tags:
  - quote
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Bradley Chambers
---

# Bradley Chambers

I've never been a fan of pilot programs. When you are doing a technology deployment, you have to go all in. Pilots are essentially saying that we aren't sure what we are doing. Pilots are also a way to protect yourself from failure.
