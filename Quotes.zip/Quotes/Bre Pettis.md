---
title: Bre Pettis
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bre Pettis
Author: 
fileClass: Quotes
source: Linchpin
topics: Knowledge
---

# Bre Pettis

[[+Quotes MOC|Quotes]]

quote:: Pretending you know what you're doing is almost the same as knowing what you are doing, so accept that you know what you're doing even if you don't and do it. (Linchpin)
