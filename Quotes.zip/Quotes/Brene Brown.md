---
title: Brene Brown
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Brene Brown
Author: 
fileClass: Quotes
source: ""
topics:
  - Accountability
  - Humility
---

# Brene Brown

[[+Quotes MOC|Quotes]]

quote:: Just show up and be seen.

quote:: Don't shrink, don't puff up, just stand your sacred ground.
