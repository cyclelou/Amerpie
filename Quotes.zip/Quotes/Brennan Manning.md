---
title: Brennan Manning
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Brennan Manning
Author: 
fileClass: Quotes
source: 
topics:
  - Disappointment
---

# Brennan Manning

[[+Quotes MOC|Quotes]]

quote:: Our disappointments arise from presuming to know the outcome of a particular endeavor.
