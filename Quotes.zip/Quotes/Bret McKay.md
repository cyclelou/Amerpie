---
title: Bret McKay
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bret McKay
Author: 
fileClass: Quotes
source: 
topics:
  - Choice
  - Responsibility
---

# Bret McKay

[[+Quotes MOC|Quotes]]

quote:: A man does as he chooses, while a boy does as he should.
