---
title: Bret Victor
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bret Victor
Author: 
fileClass: Quotes
source: 
topics:
  - Knowledge
  - Creatvity
---

# Bret Victor

[[+Quotes MOC|Quotes]]

quote:: The most dangerous thought you can have as a creative person is to think that you know what you're doing.
