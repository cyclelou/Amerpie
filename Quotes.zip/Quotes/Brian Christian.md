---
title: Brian Christian
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: <% tp.file.title %>
Author: 
fileClass: Quotes
source: 
topics:
  - Art
  - Vision
---

# Brian Christian

[[+Quotes MOC|Quotes]]

quote:: The Arts in America are strange that way: we seem to care what our vision falls upon, but not whose vision it is.
