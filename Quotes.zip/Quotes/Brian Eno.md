---
title: Brian Eno
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution:
  - Brian Eno
 
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Money
---

# Brian Eno

quote:: If all I'd ever wanted to do was make money, I'd probably be really poor by now.
