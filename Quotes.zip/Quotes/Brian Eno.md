---
attribution:
  - Brian Eno
source: 
topics:
  - Money
tags:
  - quote
fileClass: Quotes
title: Brian Eno
creation date: 2024-01-31
modification date: 2024-01-31
---

# Brian Eno

If all I'd ever wanted to do was make money, I'd probably be really poor by now.
