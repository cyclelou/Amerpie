---
title: Brian Tracy
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Brian Tracy
Author: 
fileClass: Quotes
source: 
topics:
  - Giving
---

# Brian Tracy

[[+Quotes MOC|Quotes]]

quote:: Don't be reluctant to give of yourself generously. It's the mark of caring and compassion and personal greatness.
