---
title: Bruce Lee
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Bruce Lee
Author: 
fileClass: Quotes
source: 
topics:
  - Success
---

# Bruce Lee

[[+Quotes MOC|Quotes]]

quote:: The successful warrior is the average man with laser-like focus.
