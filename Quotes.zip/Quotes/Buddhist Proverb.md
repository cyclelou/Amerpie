---
title: Buddhist Proverb
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-18
attribution: Buddhist Proverb
Author: 
fileClass: Quotes
source: 
topics:
  - Morality
---

# Buddhist Proverb

[[+Quotes MOC|Quotes]]

quote:: If we are facing the right direction, all we have to do is keep walking.
