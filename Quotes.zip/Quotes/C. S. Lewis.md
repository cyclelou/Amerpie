---
title: C. S. Lewis
url: 
tags:
  - quote
creation date: 2024-01-29
modification date: 2024-02-04
attribution:
  - C.S.Lewis
fileClass: Quotes
source: 
topics:
  - writing
---

# C. S. Lewis

C. S. Lewis

The way for a person to develop a [writing] style is (a) to know exactly what he wants to say, and (b) to be sure he is saying exactly that. The reader, we must remember, does not start by knowing what we mean. If our words are ambiguous, our meaning will escape him. I sometimes think that writing is like driving sheep down a road. If there is any gate open to the left or the right the readers will most certainly go into it.
