---
title: Calvin Coolidge
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Calvin Coolidge
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Abundance
---

# Calvin Coolidge

[[+Quotes MOC|Quotes]]

quote:: We live in an age of science and of abounding accumulation of material things. These did not create our Declaration. Our Declaration created them. The things of the spirit come first. Unless we cling to that, all out material prosperity, overwhelming though it may appear, will turn to a barren scepter in our grasp. ^abundance
