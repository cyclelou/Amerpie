---
title: Cap Watkins
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Kindness
---

# Cap Watkins

[[+Quotes MOC|Quotes]]

quote: Talk to the people around you (in classes, at conferences, at bars). Be kind to them. You never know who will think of you at the exact right moment and set you on a path you would never have found otherwise.
