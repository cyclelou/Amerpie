---
title: Carl Jung
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Carl Jung
fileClass: Quotes
source: 
topics:
  - Insight
---

# Carl Jung

Who looks outward dreams, who looks inward awakens.
