---
title: Carl Jung
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-21
attribution: Carl Jung
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Insight
  - Danger
  - Fear
---

# Carl Jung

quote: Who looks outward dreams, who looks inward awakens.

[[+Quotes MOC|Quotes]]

quote: It is not earthquakes, not microbes, not cancer but man himself who is man's greatest danger to man, for the simple reason that there is no adequate protection against psychic epidemics, which are infinitely more devastating than the worst of natural catastrophes.  

quote: All one's neighbours are in the grip of some uncontrolled and uncontrollable fear… In lunatic asylums it is a well-known fact that patients are far more dangerous when suffering from fear than when moved by rage or hatred. ^2
