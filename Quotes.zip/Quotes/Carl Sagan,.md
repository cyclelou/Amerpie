---
title: Carl Sagan,
url: 
tags: quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - Carol Sagan
fileClass: Quotes
source: The Ascent of man
topics:
  - Sport
---

# Carl Sagan

Carl Sagan,  
"In themselves, his actions make no practical sense at all; they are an exercise that is not directed to the present. The athlete's mind is fixed ahead of him, building up his skill; and he vaults his imagination into the future." The Ascent of Man
