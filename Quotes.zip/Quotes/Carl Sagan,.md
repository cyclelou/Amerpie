---
title: Carl Sagan,
url: 
tags:
  - Quote
creation date: 2024-02-07
modification date: 2024-02-21
aliases:
  - Carl Sagan
attribution: Carol Sagan
Author: 
fileClass:
  - Quotes
source: The Ascent of Man
topics:
  - Sport
---

[[+Quotes MOC]]

# Carl Sagan

quote:: "In themselves, his actions make no practical sense at all; they are an exercise that is not directed to the present. The athlete's mind is fixed ahead of him, building up his skill; and he vaults his imagination into the future."
