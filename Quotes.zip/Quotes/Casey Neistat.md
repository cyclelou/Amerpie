---
title: Casey Neistat
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Casey Neistat
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Safety
---

# Casey Neistat

[[+Quotes MOC|Quotes]]

quote:: The most dangerous thing you can do in life is play it safe.
