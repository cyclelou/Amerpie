---
title: Charles Baudelaire
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Charles Baudelaire
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Devil
---

# Charles Baudelaire

[[+Quotes MOC|Quotes]]

quote:: The greatest trick the Devil ever played was convincing the world that he did not exist.
