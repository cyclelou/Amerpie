---
title: Charles Dickens
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Charles Dickens
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Improvement
  - Joy
---

# Charles Dickens

[[+Quotes MOC|Quotes]]

quote:: It is a pleasant thing to reflect upon, and furnishes a complete answer to those who contend for the gradual degeneration of the human species, that every baby born into the world is a finer one than the last.

quote:: The pain of parting is nothing to the joy of meeting again.
