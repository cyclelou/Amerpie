---
title: Charles Kettering
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Language
---

# Charles Kettering

[[+Quotes MOC|Quotes]]

quote:: A problem well stated is a problem half solved.
