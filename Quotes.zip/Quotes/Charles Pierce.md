---
title: Charles Pierce
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Charles Pierce
fileClass: Quotes
source: 
topics:
  - Business
  - Philosophy
  - Politics
---

# Charles Pierce

"The rise of idiot America today represents–for profit mainly, but also and more cynically, for political advantage in the pursuit of power–the breakdown of a consensus that the pursuit of knowledge is a good
