---
title: Charles Pierce
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-21
attribution: Charles Pierce
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Business
  - Philosophy
  - Politics
---

[[+Quotes MOC]]

# Charles Pierce

quote:: "The rise of idiot America today represents–for profit mainly, but also and more cynically, for political advantage in the pursuit of power–the breakdown of a consensus that the pursuit of knowledge is a good
