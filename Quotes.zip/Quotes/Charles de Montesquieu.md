---
title: Charles de Montesquieu
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Charles de Montesquieu
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Reading
---

# Charles De Montesquieu

[[+Quotes MOC|Quotes]]

quote:: I have never known any distress that an hour's reading did not relieve.
