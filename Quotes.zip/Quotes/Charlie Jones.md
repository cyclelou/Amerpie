---
title: Charlie Jones
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Charlie Jones
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Change
---

# Charlie Jones

[[+Quotes MOC|Quotes]]

quote:: You are the same today as you'll be in five years except for two things: the books you read and the people you meet.
