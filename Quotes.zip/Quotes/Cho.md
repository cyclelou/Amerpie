---
title: Cho
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Cho
Author: 
fileClass:
  - Quotes
source: Mentalist
topics:
  - Mental Health
---

# Cho

[[+Quotes MOC|Quotes]]

quote:: No it isn't (complicated). You just need mental help.
