---
title: Chris Brogan
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Chris Brogan
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Standards
---

# Chris Brogan

[[+Quotes MOC|Quotes]]

quote:: Don't settle: Don't finish bad books. If you don't like the menu, leave the restaurant. If you're not on the right path, get off it.
