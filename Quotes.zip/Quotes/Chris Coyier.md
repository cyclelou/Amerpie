---
title: Chris Coyier
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: Chris Coyier
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Technology
---

# Chris Coyier

[[+Quotes MOC|Quotes]]

quote:: Keep them dreams big and just build websites.
