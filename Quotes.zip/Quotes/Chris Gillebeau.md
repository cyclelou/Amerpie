---
title: Chris Gillebeau
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: ""
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Meaning
  - Problems
  - Worry
---

# Chris Gillebeau

[[+Quotes MOC|Quotes]]

quote:: To increase happiness, do something fun. To increase meaning, do something challenging.

quote:: Whether you believe you are here for a reason or you create the reason as you go along, the same holds true: Life is full of things you can't fix. In front of you every day are things that you can. Those are the things you should worry about.

### Related

[[#^8]]
