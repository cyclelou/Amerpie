---
title: Christopher Alexander
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-21
attribution: Christopher Alexander
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Self improvement
---

# Christopher Alexander

[[+Quotes MOC]]

quote:: It is hard, so terribly hard, to please yourself. Far from being the easy thing that it sounds like, it is almost the hardest thing in the world, because we are not always comfortable with that true self that lies deep within us.
