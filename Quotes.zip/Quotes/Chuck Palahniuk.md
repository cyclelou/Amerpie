---
title: Chuck Palahniuk
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-21
attribution: Chuck Palahniuk
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Imagination
  - Philosophy
  - Truth
---

[[+Quotes MOC]]

# Chuck Palahniuk

quote:: Old George Orwell got it backward. Big Brother isn't watching. He's singing and dancing. He's pulling rabbits out of a hat. Big Brother's busy holding your attention every moment you're awake. He's making sure you're always distracted. He's making sure you're fully absorbed. He's making sure your imagination withers. Until it's as useful as your appendix. He's making sure your attention is always filled. And this being fed, it's worse than being watched. With the world always filling you, no one has to worry about what's in your mind. With everyone's imagination atrophied, no one will ever be a threat to the world.
