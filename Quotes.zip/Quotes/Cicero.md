---
title: Cicero
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-21
attribution: ""
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Philosophy
---

# Cicero

[[+Quotes MOC|Quotes]]

quote:: You have no choice between having a philosophy and not having one, only between having a good one and having a bad one.
