---
title: Coco Channel
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Coco Channel
Author: 
fileClass:
  - Quotes
source: 
topics:
  - Advice
  - Life
---

[[+Quotes MOC]]

# Coco Channel

quote:: Don't spend time beating on a wall, hoping to transform it into a door
