---
title: Coco Channel
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Coco Channel
fileClass: Quotes
source: http://qs.gr
topics:
  - advice
  - life
---

# Coco Channel

Don't spend time beating on a wall, hoping to transform it into a door
