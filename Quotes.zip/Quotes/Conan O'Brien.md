---
title: "Conan O'Brien"
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Conan O'Brien
fileClass: Quotes
source: 
topics:
  - Future
  - Reaction
---

# Conan O'Brien

Real life is about reacting quickly to the opportunity at hand, not the opportunity you envisioned. Not thinking and scheming for the future, but letting it happen
