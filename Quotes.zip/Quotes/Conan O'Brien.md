---
title: "Conan O'Brien"
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Conan O'Brien
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Future
  - Reaction
---

[[+Quotes MOC]]

# Conan O'Brien

quote:: Real life is about reacting quickly to the opportunity at hand, not the opportunity you envisioned. Not thinking and scheming for the future, but letting it happen.
