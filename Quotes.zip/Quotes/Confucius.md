---
title: Confucius
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Confucius
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Progress
---

# Confucius

[[+Quotes MOC|Quotes]]

quote:: It does not matter how slowly you go as long as you do not stop.
