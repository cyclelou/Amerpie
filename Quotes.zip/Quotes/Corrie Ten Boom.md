---
title: Corrie Ten Boom
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Corrie Ten Boom
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Worry
---

# Corrie Ten Boom

[[+Quotes MOC|Quotes]]

quote:: Worrying does not empty tomorrow of its troubles. It empties today of its strength.

### Related

[[Brene Brown]]
