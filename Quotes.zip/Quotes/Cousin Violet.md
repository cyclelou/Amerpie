---
title: Cousin Violet
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Cousin Violet
Author: 
fileClass:
  - Quotes
source: Downton Abbey
topics:
  - Life
---

# Cousin Violet

[[+Quotes MOC|Quotes]]

quote:: Life is a game where the player must appear ridiculous.  
(Downton Abbey)
