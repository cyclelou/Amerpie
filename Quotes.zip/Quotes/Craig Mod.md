---
title: Craig Mod
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Craig Mod
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Art
  - Work
---

# Craig Mod

[[+Quotes MOC]]

quote:: Giving a shit does not require capital, simply attention and humility and diligence. Giving a shit is the best feeling you can imbue craft with.
