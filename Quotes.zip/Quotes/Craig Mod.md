---
title: Craig Mod
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Craig Mod
fileClass: Quotes
source: 
topics:
  - Art
  - work
---

# Craig Mod

Giving a shit does not require capital, simply attention and humility and diligence. Giving a shit is the best feeling you can imbue craft with.
