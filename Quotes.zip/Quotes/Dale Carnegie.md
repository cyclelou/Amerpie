---
title: Dale Carnegie
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Forgiveness
  - Action
---

# Dale Carnegie

[[+Quotes MOC|Quotes]]

quote:: Any fool can criticize, condemn, and complain—and most fools do. But it takes character and self-control to be understanding and forgiving.

quote:: Inaction breeds doubt and fear. Action breeds confidence and courage. If you want to conquer fear, do not sit home and think about it. Go out and get busy. ^courage

### Related
