---
title: Dan Harris
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dan Harris
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Mindfulness
---

# Dan Harris

[[+Quotes MOC]]

But it was in this moment, lying in bed late at night, that I first realized that the voice in my head—the running commentary that had dominated my field of consciousness since I could remember—was kind of an asshole.
