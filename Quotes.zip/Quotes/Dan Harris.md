---
title: Dan Harris
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Dan Harris
fileClass: Quotes
source: 
topics:
  - Mindfulness
---

# Dan Harris

But it was in this moment, lying in bed late at night, that I first realized that the voice in my head—the running commentary that had dominated my field of consciousness since I could remember—was kind of an asshole.
