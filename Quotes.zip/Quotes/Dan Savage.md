---
title: Dan Savage
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dan Savage
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Religion
  - Sex
---

# Dan Savage

[[+Quotes MOC]]

quote:: Judaism, Christianity, Islam and almost every other faith have constantly tried to insert themselves between your genitals and your salvation, because then they can regulate and control you. Then you need them to intercede with God, so they target your junk and stigmatize your sexual desire. If you have somebody by the balls or the ovaries, you've got them.
