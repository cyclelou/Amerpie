---
title: Dave Bendickson
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dave Bendickson
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Need
---

# Dave Bendickson

[[+Quotes MOC|Quotes]]

quote:: Givers don't take beyond their needs. Takers take even if they don't need it.
