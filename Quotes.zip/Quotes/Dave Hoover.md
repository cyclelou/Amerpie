---
title: Dave Hoover
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dave Hoover
Author: 
fileClass:
  - Quotes
source: 
topics:
  - Experience
---

# Dave Hoover

[[+Quotes MOC|Quotes]]

quote:: The critical distinction between a craftsman and an expert is what happens after a sufficient level of expertise has been achieved. The expert will do everything she can to remain wedded to a single context, narrowing the scope of her learning, her practice, and her projects. The craftsman has the courage and humility to set aside her expertise and pick up an unfamiliar technology or learn a new domain.
