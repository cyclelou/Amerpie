---
title: Dave Ramsey
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dave Ramsey
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Selfishness
  - Decisions
---

# Dave Ramsey

[[+Quotes MOC|Quotes]]

quote:: A good rule of thumb on decision making is this: the small, dinky little decisions you make in life, make 'em fast. That leaves you bandwidth, emotionally and time-wise, to spend time on the large decisions.

quote:: The only place where selfish people prosper is on television.
