---
title: Dave Wiskus
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
fileClass: Quotes
source: Twitter
topics:
  - Humor
---

# Dave Wiskus

Life's Ebola cherries.
