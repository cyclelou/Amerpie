---
title: Dave Wiskus
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dave Wiskus
Author: 
fileClass:
  - Quotes
source: Twitter
topics:
  - Humor
---

# Dave Wiskus

[[+Quotes MOC]]

Life's Ebola cherries.
