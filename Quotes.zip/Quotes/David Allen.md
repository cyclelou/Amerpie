---
title: David Allen
url: 
tags:
  - Quote
creation date: 2024-02-10
modification date: 2024-02-26
attribution: David Allen
Author: 
fileClass:
  - Quotes
source: 
topics:
  - Ideas
---

# David Allen

quote:: "Your mind is for having ideas, not holding them."
