---
title: David Brinkley
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: David Brinkley
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - News
---

# David Brinkley

[[+Quotes MOC|Quotes]]

quote:: The one function TV news performs very well, is that when there is no news, we will give it to you with the same emphasis as if there were.
