---
title: David Foster Wallace
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-03-08
attribution: David Foster Wallace
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Technology
---

# David Foster Wallace

quote:: Cause the technology is just gonna get better and better and it's gonna get easier and easier and more and more convenient and more and more pleasurable to sit alone with images on a screen given to us by people who do not love us but want our money and that's fine in low doses but if it's the basic main staple of your diet you're gonna die.
