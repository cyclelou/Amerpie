---
title: David Foster Wallace
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - David Foster Wallace
fileClass: Quotes
quote: 
source: 
topics:
  - Technology
---

# David Foster Wallace

Cause the technology is just gonna get better and better and it's gonna get easier and easier and more and more convenient and more and more pleasurable to sit alone with images on a screen given to us by people who do not love us but want our money and that's fine in low doses but if it's the basic main staple of your diet you're gonna die.
