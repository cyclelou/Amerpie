---
title: David J. Schwartz
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: ""
Author: 
fileClass:
  - Quotes
source: The Magic of Thinking Big
topics:
  - Action
  - Correctness
---

# David J. Schwartz

[[+Quotes MOC|Quotes]]

quote:: Make sure that what you plan to do is right. Then do it. No one ever does anything worthwhile for which he is not criticized. ^doright

quote:: Action cures fear. Indecision, postponement, on the other hand, fertilizes fear. ^action
