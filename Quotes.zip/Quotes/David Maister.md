---
title: David Maister
url: 
tags:
  - quote
creation date: 2024-01-24
modification date: 2024-02-04
attribution:
  - David Maister
fileClass: Quotes
source: The Trusted Advisor
topics:
  - work
---

# David Maister

" It is not enough for a professional to be right: An advisor's job is to be helpful."  
David Maister
