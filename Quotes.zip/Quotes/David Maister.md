---
title: David Maister
url: 
tags:
  - Quote
creation date: 2024-01-24
modification date: 2024-02-26
attribution: David Maister
Author: 
fileClass:
  - Quotes
source: The Trusted Advisor
topics:
  - Work
---

# David Maister

[[+Quotes MOC]]

quote:: It is not enough for a professional to be right: An advisor's job is to be helpful."  
