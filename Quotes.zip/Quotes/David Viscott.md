---
title: David Viscott
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: David Viscott
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Courage
  - Success
---

# David Viscott

[[+Quotes MOC|Quotes]]

quote:: If you have the courage to begin, you have the courage to succeed.
