---
title: Dean Smith
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Dean Smith
fileClass: Quotes
source: 
topics:
  - Winning
---

# Dean Smith

If you make every game a life-and-death thing, you're going to have problems. You'll be dead a lot.
