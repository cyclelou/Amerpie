---
title: Dean Smith
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dean Smith
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Winning
---

# Dean Smith

[[+Quotes MOC]]

quote:: If you make every game a life-and-death thing, you're going to have problems. You'll be dead a lot.
