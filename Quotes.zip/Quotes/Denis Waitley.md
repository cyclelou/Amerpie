---
title: Denis Waitley
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution:
  - Denis Waitley
 
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Acceptance
  - Responsibility
---

# Denis Waitley

[[+Quotes MOC]]

quote:: There are two primary choices in life: to accept conditions as they exist, or accept the responsibility for changing them.
