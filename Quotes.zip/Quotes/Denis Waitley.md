---
title: Denis Waitley
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Denis Waitley
fileClass: Quotes
source: 
topics:
  - Acceptance
  - responsibility
---

# Denis Waitley

There are two primary choices in life: to accept conditions as they exist, or accept the responsibility for changing them.
