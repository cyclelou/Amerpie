---
title: Derek Sivers
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Sleep
  - Exclusion
  - Common Sense
  - Improvement
---

# Derek Sivers

[[+Quotes MOC|Quotes]]

quote:: I'm not bad at sleeping. I'm just really good at staying awake. ^awake

quote:: It's a big world. You can loudly exclude 99 percent of it.

quote:: When you're on to something great, it won't feel like revolution. It'll feel like uncommon sense.

quote:: You can't please everyone, so proudly exclude people.

quote:: Success comes from persistently improving and inventing, not from persistently promoting what's not working.
