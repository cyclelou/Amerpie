---
title: Dick Cavett
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Knowledge
---

# Dick Cavett

[[+Quotes MOC|Quotes]]

quote:: It's a rare person who wants to hear what he doesn't want to hear.
