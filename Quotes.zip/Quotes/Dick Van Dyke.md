---
title: Dick Van Dyke
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dick Van Dyke
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Security
---

# Dick Van Dyke

[[+Quotes MOC|Quotes]]

quote:: I've made peace with insecurity, because there is no security of any kind.
