---
title: Dieter Rams
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Moderation
---

# Dieter Rams

[[+Quotes MOC|Quotes]]

quote:: Less, but better.
