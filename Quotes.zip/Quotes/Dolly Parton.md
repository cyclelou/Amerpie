---
title: Dolly Parton
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Dolly Parton
fileClass: Quotes
source: 
topics:
  - Identity
---

# Dolly Parton

Find out who you are and do it on purpose.
