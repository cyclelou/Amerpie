---
title: Dolly Parton
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dolly Parton
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Identity
---

# Dolly Parton

[[+Quotes MOC]]

quote:: Find out who you are and do it on purpose.
