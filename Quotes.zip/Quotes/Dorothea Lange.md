---
title: Dorothea Lange
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Dorothea Lange
fileClass: Quotes
source: 
topics:
  - Photography
---

# Dorothea Lange

The camera is an instrument that teaches people how to see without a camera.
