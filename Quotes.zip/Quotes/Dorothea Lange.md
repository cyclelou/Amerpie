---
title: Dorothea Lange
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dorothea Lange
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Photography
---

# Dorothea Lange

[[+Quotes MOC]]

quote:: The camera is an instrument that teaches people how to see without a camera.
