---
title: Dorothy Parker
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Curiousity
---

# Dorothy Parker

[[+Quotes MOC|Quotes]]

quote:: The cure for boredom is curiosity. There is no cure for curiosity.
