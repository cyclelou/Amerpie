---
title: Doug Larson
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Doug Larson
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Philosophy
---

# Doug Larson

[[+Quotes MOC]]

quote:: If people concentrated on the really important things in life, there'd be a shortage of fishing poles.
