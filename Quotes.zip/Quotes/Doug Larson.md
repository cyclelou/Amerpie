---
title: Doug Larson
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Doug Larson
fileClass: Quotes
source: 
topics:
  - Philosophy
---

# Doug Larson

If people concentrated on the really important things in life, there'd be a shortage of fishing poles.
