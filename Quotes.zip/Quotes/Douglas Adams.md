---
title: Douglas Adams
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Time
  - Deadlines
  - Flying
  - Design
  - Possibility
---

# Douglas Adams

[[+Quotes MOC|Quotes]]

quote:: Time is an illusion, lunchtime doubly so.

quote:: I love deadlines. I like the whooshing sounds they make as they fly by.

quote:: There is an art… to flying. It lies in learning how to throw yourself at the ground and miss.

quote:: A common mistake that people make when trying to design something completely foolproof is to underestimate the ingenuity of complete fools.

quote:: There is no point in using the word 'impossible' to describe something that has clearly happened.
