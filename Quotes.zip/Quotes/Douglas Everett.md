---
title: Douglas Everett
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Douglass Everett
fileClass: Quotes
source: 
topics:
  - Action
---

# Douglas Everett

There are some people who live in a dream world, and there are some who face reality; and then there are those who turn one into the other.
