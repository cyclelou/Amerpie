---
title: Douglas Everett
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Douglass Everett
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Dreams
  - Reality
---

# Douglas Everett

[[+Quotes MOC]]

quote:: There are some people who live in a dream world, and there are some who face reality; and then there are those who turn one into the other.
