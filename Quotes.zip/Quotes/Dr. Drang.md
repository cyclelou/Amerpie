---
title: Dr. Drang
url: 
tags:
  - quote
creation date: 2024-01-31
modification date: 2024-02-04
attribution:
  - Dr. Drang
fileClass: Quotes
source: Twitter
topics:
  - Humor
---

# Dr. Drang

A hotels chain that could guarantee Fox wouldn't be playing in the breakfast area would get all of my business.
