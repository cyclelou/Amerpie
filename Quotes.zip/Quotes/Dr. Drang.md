---
title: Dr. Drang
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-26
attribution: Dr. Drang
Author: 
fileClass:
  - Quotes
source: Twitter
topics:
  - Humor
---

# Dr. Drang

quote:: A hotels chain that could guarantee Fox wouldn't be playing in the breakfast area would get all of my business.
