---
title: Dr. Seuss
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: <% tp.file.title %>
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Time
  - Decisions
  - Knowledge
  - Learning
  - Meaning
---

# Dr. Seuss

[[+Quotes MOC|Quotes]]

quote:: Don't cry because it's over, smile because it happened.

quote:: How did it get so late so soon? It's night before it's afternoon. December is here before it's June. My goodness how the time has flewn. How did it get so late so soon?

quote:: You have brains in your head. You have feet in your shoes.  
You can steer yourself  
any direction you choose. You're on your own.  
And you know what you know.  
And YOU are the one who'll decide where to go.

quote:: So, on beyond Z! It's high time you were shown  
That you really don't know  
All there is to be known.

quote:: You can get help from teachers, but you are going to have to learn a lot by yourself, sitting alone in a room.

quote:: Sometimes the questions are complicated and the answers are simple.

quote:: Be who you are and say what you feel, because those who mind don't matter, and those who matter don't mind.
