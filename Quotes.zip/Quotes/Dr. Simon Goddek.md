---
title: Dr. Simon Goddek
url: https://twitter.com/goddeketal/status/1728997671179018243
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dr. Simon Goddek
Author: 
fileClass:
  - Quotes
source: Twitter
topics: 
updated: 2023-12-15T08:54:39-06:00
---

# Dr. Simon Goddek

[[+Quotes MOC|Quotes]]

quote:: The pharmaceutical industry is as interested in world health as the arms industry is in world peace. ^pharma

[^1]

[^1]: <https://twitter.com/goddeketal/status/1728997671179018243>
