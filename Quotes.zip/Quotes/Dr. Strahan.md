---
title: Dr. Strahan
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dr. Strahan
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Fairness
---

# Dr. Strahan

[[+Quotes MOC|Quotes]]

(My aviation medical examiner)

quotes:: If you aren't cheating you're not playing the game right.
