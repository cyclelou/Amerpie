---
title: Duke Ellington
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Duke Ellington
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Time
---

# Duke Ellington

[[+Quotes MOC|Quotes]]

quotes:: I don't need time. What I need is a deadline.
