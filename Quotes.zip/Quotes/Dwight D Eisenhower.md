---
title: Dwight D Eisenhower
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Dwight D Eisenhower
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Importance
  - Urgency
---

# Dwight D Eisenhower

[[+Quotes MOC|Quotes]]

quotes:: What is important is seldom urgent and what is urgent is seldom important.
