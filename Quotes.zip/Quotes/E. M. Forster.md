---
title: E. M. Forster
url: 
tags:
  - Quote
creation date: 2024-01-20
modification date: 2024-02-09
attribution:
  - E. M. Forster
 
fileClass:
  - Quotes
source: ""
topics:
  - Willingness
---

# E. M. Forster

"We must be willing to let go of the life we have planned, so as to have the life that is waiting for us."
