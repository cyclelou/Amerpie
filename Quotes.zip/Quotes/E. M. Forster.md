---
attribution:
  - E. M. Forster
source: 
tags:
  - quote
topics:
  - willingness
creation date: 2024-01-20
modification date: 2024-01-31
fileClass: Quotes
title: E. M. Forster
---

# E. M. Forster

"We must be willing to let go of the life we have planned, so as to have the life that is waiting for us."
