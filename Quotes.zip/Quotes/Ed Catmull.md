---
title: Ed Catmull
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ed Catmull

[[+Quotes MOC|Quotes]]

Craft is what we're expected to know, art is using our craft in unexpected ways.

You don't have to ask permission to take responsibility.

Visual polish often doesn't matter if you're getting the story right.
