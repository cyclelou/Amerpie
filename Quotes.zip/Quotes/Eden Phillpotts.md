---
title: Eden Phillpotts
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-09
attribution:
  - Eden Phillpotts
 
fileClass:
  - Quotes
source: ""
topics:
  - intellect
---

# Eden Phillpotts

"The universe is full of magical things patiently waiting for our wits to grow sharper."  
― Eden Phillpotts
