---
attribution:
  - Eden Phillpotts
source: 
tags:
  - quote
topics:
  - intellect
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Eden Phillpotts
---

# Eden Phillpotts

"The universe is full of magical things patiently waiting for our wits to grow sharper."  
― Eden Phillpotts
