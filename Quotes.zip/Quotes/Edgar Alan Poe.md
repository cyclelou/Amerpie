---
title: Edgar Alan Poe
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Edgar Alan Poe

[[+Quotes MOC|Quotes]]

I have great confidence in fools—self-confidence, my friends call it. ^a8ce86
