---
title: Edgar Degas
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Edgar Degas
fileClass: Quotes
source: ""
topics:
  - Art
  - Self
---

[[+Quotes MOC]]

# Edgar Degas

quote:: A painter paints a picture with the same feeling as that with which a criminal commits a crime.
