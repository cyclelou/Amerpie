---
quote: A painter paints a picture with the same feeling as that with which a criminal commits a crime.
source: 
topics:
  - Art,Self
tags:
  - quote
fileClass: Quotes
title: Edgar Degas
creation date: 2024-01-31
modification date: 2024-01-31
---

# Edgar Degas
