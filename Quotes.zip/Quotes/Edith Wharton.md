---
title: Edith Wharton
url: 
tags:
  - Quote
creation date: 2024-02-07
modification date: 2024-02-09
attribution:
  - Edith Wharton
 
fileClass:
  - Quotes
source: ""
topics:
  - Light
---

# Edith Wharton

There are 2 ways of spreading light. Be the candle or the mirror that reflects it.
