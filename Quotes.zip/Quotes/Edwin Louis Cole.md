---
title: Edwin Louis Cole
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Edwin Louis Cole

[[+Quotes MOC|Quotes]]

You don't drown by falling in the water, you drown by staying there.
