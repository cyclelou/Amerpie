---
title: Edwin Markham
url: 
tags:
  - Quote
creation date: 2024-01-22
modification date: 2024-02-09
attribution:
  - Edwin Markham
 
fileClass:
  - Quotes
source: ""
topics:
  - Defeat
---

# Edwin Markham

Edwin Markham  
Defeat may serve as well as victory to shake the soul and let the glory out.
