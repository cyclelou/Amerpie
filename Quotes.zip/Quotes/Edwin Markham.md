---
attribution:
  - Edwin Markham
source: 
tags:
  - quote
topics:
  - defeat
creation date: 2024-01-22
modification date: 2024-01-31
fileClass: Quotes
title: Edwin Markham
---

# Edwin Markham

Edwin Markham  
Defeat may serve as well as victory to shake the soul and let the glory out.
