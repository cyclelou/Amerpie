---
title: Edwn Philpots
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: The universe is full of magical things patiently waiting for our wits to grow sharper.
source: ""
topics:
  - Growth
---

# Edwn Philpots
