---
quote: The universe is full of magical things patiently waiting for our wits to grow sharper.
source: 
topics: Growth
tags: quote
fileClass: Quotes
title: Edwn Philpots
creation date: 2024-01-31
modification date: 2024-01-31
---

# Edwn Philpots
