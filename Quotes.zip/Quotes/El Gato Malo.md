---
title: El Gato Malo
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# El Gato Malo

[[+Quotes MOC|Quotes]]

if you grant near unlimited power to governments during emergencies, they will produce an endless cavalcade of hobgoblins and crises to get at them. emergency will become the norm.
