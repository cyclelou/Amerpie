---
quote: If hypocrisy is the tribute vice pays to virtue, then imperfect people  expressing the right sentiments and occasionally doing the right thing are to be praised.
source: Twitter
topics: Philosophy
tags: quote
fileClass: Quotes
title: Eliot Cohen
creation date: 2024-01-31
modification date: 2024-01-31
---
