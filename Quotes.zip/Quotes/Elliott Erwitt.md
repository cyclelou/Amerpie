---
quote: To me, photography is an art of observation. It’s about finding something interesting in an ordinary place… I’ve found it has little to do with the things you see and everything to do with the way you see them.
source: 
topics: Photography
tags: quote
fileClass: Quotes
title: Elliott Erwitt
creation date: 2024-01-31
modification date: 2024-01-31
---
