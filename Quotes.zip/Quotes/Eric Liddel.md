---
title: Eric Liddel
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Eric Liddel

[[+Quotes MOC|Quotes]]

When I run I feel His pleasure.
