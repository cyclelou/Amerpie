---
title: Eric Ludy
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Eric Ludy

[[+Quotes MOC|Quotes]]

The brotherhood has told us that all we need is mud on our tires and a muscular chest. But mud on a man's tires doesn't mean steel in a man's soul. And a muscular chest doesn't mean there's self-sacrificing nobility within that chest.
