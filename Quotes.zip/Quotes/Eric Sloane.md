---
title: Eric Sloane
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Eric Sloane

[[+Quotes MOC]]

In 1765 everything a man owned was made more valuable by the fact that he had made it himself or knew exactly from where it had come… it is less strange that the eighteenth-century man should have a richer and keener enjoyment of life through knowledge than that the twentieth-century man should lead an arid and empty existence in the midst of wealth and extraordinary material benefits.
