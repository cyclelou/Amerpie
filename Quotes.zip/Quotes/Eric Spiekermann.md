---
title: Eric Spiekermann
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Eric Spiekermann

[[+Quotes MOC|Quotes]]

We are interpreters - not merely translators between sender and receiver. What we say and how we say it makes a difference. If we want to speak to people, we need to know their language. In order to design for understanding, we need to understand design.
