---
title: Ernest Hemingway
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution:
  - Ernest Hemingway
 
fileClass:
  - Quotes
source: ""
topics:
  - Photography
---

# Ernest Hemingway

[[+Quotes MOC|Quotes]]  

Man is not made for defeat.

There is nothing noble in being superior to your fellow man; true nobility is being superior to your former self.

If something is wrong, fix it if you can. But train yourself not to worry. Worry never fixes anything.

# Ernest Hemingway

You take the most amazing pictures. What kind of camera do you use?"

Adams frowned and then replied, "You write the most amazing stories. What kind of typewriter do you use?
