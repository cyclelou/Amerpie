---
quote: You take the most amazing pictures. What kind of camera do you use?"

Adams frowned and then replied, "You write the most amazing stories. What kind of typewriter do you use?
source:  
topics: Photography
tags: quote
---
