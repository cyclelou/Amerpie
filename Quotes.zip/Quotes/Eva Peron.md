---
title: Eva Peron
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-09
attribution:
  - Eva Person
 
fileClass:
  - Quotes
source: ""
topics:
  - Fanaticism
---

# Eva Peron

"One cannot accomplish anything without fanaticism." ~ Eva Peron
