---
attribution:
  - Eva Person
source: 
tags:
  - quote
topics:
  - fanaticism
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Eva Peron
---

# Eva Peron

"One cannot accomplish anything without fanaticism." ~ Eva Peron
