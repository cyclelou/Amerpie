---
title: F. Scott Fitzgerald
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# F. Scott Fitzgerald

[[+Quotes MOC|Quotes]]

The test of a first-rate intelligence is the ability to hold two opposed ideas in mind at the same time, and still retain the ability to function
