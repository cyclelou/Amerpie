---
title: "Flannery O'Connor"
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Flannery O'Connor

[[+Quotes MOC|Quotes]]

You will know the reconciling truth, and that reconciling truth will make you odd.
