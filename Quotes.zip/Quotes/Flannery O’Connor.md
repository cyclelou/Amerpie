---
title: Flannery O’Connor
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
aliases: ["Flannery O'Connor"]
attribution: ""
fileClass:
  - Quotes
quote: I write because I don’t know what I think until I read what I say.
source: ""
topics:
  - Writing
---

# Flannery O'Connor
