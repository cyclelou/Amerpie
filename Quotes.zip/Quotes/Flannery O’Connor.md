---
quote: I write because I don’t know what I think until I read what I say.
source: 
topics:
  - Writing
tags:
  - quote
fileClass: Quotes
title: Flannery O’Connor
creation date: 2024-01-31
modification date: 2024-01-31
aliases: ["Flannery O'Connor"]
linter-yaml-title-alias: "Flannery O'Connor"
---

# Flannery O'Connor
