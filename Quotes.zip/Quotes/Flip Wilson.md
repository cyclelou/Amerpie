---
attribution:
  - Flip Wilson
source: 
tags:
  - quote
topics:
  - risk
creation date: 2024-01-12
modification date: 2024-01-31
fileClass: Quotes
title: Flip Wilson
---

# Flip Wilson

Flip Wilson

"You can't expect to hit the jackpot if you don't put a few nickels in the machine."
