---
title: Flip Wilson
url: 
tags:
  - Quote
creation date: 2024-01-12
modification date: 2024-02-09
attribution:
  - Flip Wilson
 
fileClass:
  - Quotes
source: ""
topics:
  - Risk
---

# Flip Wilson

Flip Wilson

"You can't expect to hit the jackpot if you don't put a few nickels in the machine."
