---
title: Fortune Cookie
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Fortune Cookie

[[+Quotes MOC|Quotes]]

No one would remember the good Samaritan if all he had were good intentions.
