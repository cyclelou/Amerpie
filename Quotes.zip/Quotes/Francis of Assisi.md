---
title: Francis of Assisi
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Francis of Assisi

[[+Quotes MOC|Quotes]]

Preach the gospel at all times and when necessary use words.
