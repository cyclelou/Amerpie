---
title: Frank Gelett Burgess
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
quote: Our bodies are apt to be our autobiographies.
source: ""
topics:
  - Health
---
