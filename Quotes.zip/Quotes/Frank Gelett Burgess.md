---
quote: Our bodies are apt to be our autobiographies.
source:  
topics: Health
tags: quote
title: Frank Gelett Burgess
creation date: 2024-01-31
modification date: 2024-01-31
---
