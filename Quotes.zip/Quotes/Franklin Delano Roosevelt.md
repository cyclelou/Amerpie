---
title: Franklin Delano Roosevelt
url: 
tags:
  - Quote
creation date: 2024-02-26
modification date: 2024-02-26
attribution: Franklin Delano Roosevelt
Author: 
fileClass:
  - Quotes
source: 
topics:
  - Progress
---

# Franklin Delano Roosevelt

[[+Quotes MOC]]

quote:: "There are many ways of going forward, but only one way of standing still."
