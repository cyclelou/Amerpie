---
title: Franklin P. Jones
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Franklin P. Jones

[[+Quotes MOC|Quotes]]

It's a strange world of language in which skating on thin ice can get you into hot water.
