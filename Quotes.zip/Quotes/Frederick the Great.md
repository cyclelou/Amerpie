---
attribution:
  - Frederick the Great
source: 
tags:
  - quote
topics:
  - belief
  - conviction
creation date: 2024-01-24
modification date: 2024-01-31
fileClass: Quotes
title: Frederick the Great
---

# Frederick the Great

He who defends everything defends nothing.  
 --Frederick the Great
