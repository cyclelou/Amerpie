---
title: Frederick the Great
url: 
tags:
  - Quote
creation date: 2024-01-24
modification date: 2024-02-13
attribution:
  - Frederick the Great
fileClass:
  - Quotes
source: ""
topics:
  - Belief
  - Conviction
---

# Frederick the Great

He who defends everything defends nothing.  
 --Frederick the Great
