---
title: Fredrich Neitzche
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Fredrich Neitzche

[[+Quotes MOC|Quotes]]

Blessed are the forgetful, for they get the better even of their blunders.
