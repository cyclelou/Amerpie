---
title: Fredrick W. Faber
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Fredrick W. Faber

[[+Quotes MOC|Quotes]]

Kindness has converted more souls than zeal, eloquence, or learning.
