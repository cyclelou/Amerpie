---
title: Fredrick William Robertson
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Fredrick William Robertson

[[+Quotes MOC|Quotes]]

It is not the situation which makes the man, but the man who makes the situation.
