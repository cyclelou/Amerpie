---
title: Friedrich Nietzsche
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-09
attribution:
  - Friedrich Nietzsche
 
fileClass:
  - Quotes
source:
  - Thus Spoke Zarathustra
 
topics:
  - Wisdom
---

# Friedrich Nietzsche

"There is more wisdom in your body than in your deepest philosophy."  
― Friedrich Nietzsche, Thus Spoke Zarathustra
