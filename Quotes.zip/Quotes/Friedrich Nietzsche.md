---
attribution:
  - Friedrich Nietzsche
source: Thus Spoke Zarathustra
tags:
  - quote
topics:
  - wisdom
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Friedrich Nietzsche
---

# Friedrich Nietzsche

"There is more wisdom in your body than in your deepest philosophy."  
― Friedrich Nietzsche, Thus Spoke Zarathustra
