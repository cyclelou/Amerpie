---
title: Galileo Galilei
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Galileo Galilei

[[+Quotes MOC|Quotes]]

All truths are easy to understand once they are discovered; the point is to discover them.

In questions of science, the authority of a thousand is not worth the humble reasoning of a single individual. ^consensus
