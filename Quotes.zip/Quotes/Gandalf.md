---
title: Gandalf
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Gandalf

[[+Quotes MOC|Quotes]]

Courage is the best defense you have now.
