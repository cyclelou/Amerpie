---
title: Gandhi
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Gandhi

[[+Quotes MOC|Quotes]]

Live simply so that others may simply live.

Strength does not come from physical capacity. It comes from an indomitable will.
