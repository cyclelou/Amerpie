---
title: Gary DeMar
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Gary DeMar

[[+Quotes MOC|Quotes]]

A vote is not a valentine, you aren't confessing your love for the candidate. It's a chess move for the world you want to live in.
