---
quote: Walking is the great adventure, the first meditation, a practice of heartiness and soul primary to humankind. Walking is the exact balance of spirit and humility.
source: 
topics: Exercise,Walking
tags: quote
fileClass: Quotes
title: Gary Snyder
creation date: 2024-01-31
modification date: 2024-01-31
---

# Gary Snyder
