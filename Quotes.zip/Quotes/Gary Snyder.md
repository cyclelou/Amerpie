---
title: Gary Snyder
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution: Gary Snyder
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Exercise
  - Walking
---

# Gary Snyder

[[+Quotes MOC]]

quote:: Walking is the great adventure, the first meditation, a practice of heartiness and soul primary to humankind. Walking is the exact balance of spirit and humility.
