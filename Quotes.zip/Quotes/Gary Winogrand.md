---
quote: Photographers mistake the emotion they feel while taking the photo as a judgment that the photograph is good
source: 
topics: Photography
tags: quote
fileClass: Quotes
title: Gary Winogrand
creation date: 2024-01-31
modification date: 2024-01-31
---
