---
title: Gary Winogrand
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Photographers mistake the emotion they feel while taking the photo as a judgment that the photograph is good
source: ""
topics:
  - Photography
---
