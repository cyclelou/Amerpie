---
title: George Bernard Shaw
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# George Bernard Shaw

[[+Quotes MOC|Quotes]]

The reasonable man adapts himself to the world; the unreasonable one persists in trying to adapt the world to himself. Therefore all progress depends on the unreasonable man.

Those who can not change their minds can not change anything.
