---
title: George Burns
url: 
tags:
  - Quote
creation date: 2024-01-20
modification date: 2024-02-09
attribution:
  - George Burns
 
fileClass:
  - Quotes
source: ""
topics:
  - Family
---

# George Burns

Happiness is having a large, loving, caring, close-knit family in another city.

- George Burns
