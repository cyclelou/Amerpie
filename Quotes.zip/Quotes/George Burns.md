---
attribution:
  - George Burns
source: 
tags:
  - quote
topics:
  - family
creation date: 2024-01-20
modification date: 2024-01-31
fileClass: Quotes
title: George Burns
---

# George Burns

Happiness is having a large, loving, caring, close-knit family in another city.

- George Burns
