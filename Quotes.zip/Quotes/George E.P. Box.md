---
title: George E.P. Box
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# George E.P. Box

[[+Quotes MOC|Quotes]]

All models are wrong, but some are useful.

### Related

[[Science MOC]]
