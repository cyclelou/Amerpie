---
title: George Eliot
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# George Eliot

[[+Quotes MOC|Quotes]]

There are many victories worse than defeat.
