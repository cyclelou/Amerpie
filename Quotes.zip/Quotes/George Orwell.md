---
title: George Orwell
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# George Orwell

[[+Quotes MOC]]

Some ideas are so stupid only intellectuals believe them.

To see what is in front of one's nose requires a constant struggle.

The further a society drifts from truth the more it will hate those who speak it.

Free speech is my right to say what you don't want to hear. ^4

All the war-propaganda, all the screaming and lies and hatred, comes invariably from people who are not fighting.

If people cannot write well, they cannot think well, and if they cannot think well, others will do their thinking for them. ^aeb101
