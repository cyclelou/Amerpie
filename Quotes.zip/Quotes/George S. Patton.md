---
title: George S. Patton
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# George S. Patton

[[+Quotes MOC|Quotes]]

All men are timid on entering any fight; whether it is the first fight or the last fight all of us are timid. Cowards are those who let their timidity get the better of their manhood.
