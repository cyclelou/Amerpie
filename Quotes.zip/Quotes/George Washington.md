---
attribution:
  - George Washington
source: 
tags:
  - quote
topics:
  - happiness
  - morality
creation date: 2024-01-26
modification date: 2024-01-31
fileClass: Quotes
title: George Washington
---

# George Washington

"Happiness and moral duty are inseparably connected."  
George Washington
