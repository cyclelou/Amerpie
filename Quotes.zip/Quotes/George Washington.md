---
title: George Washington
url: 
tags:
  - Quote
creation date: 2024-01-26
modification date: 2024-02-09
attribution:
  - George Washington
 
fileClass:
  - Quotes
source: ""
topics:
  - Happiness
  - Morality
---

# George Washington

"Happiness and moral duty are inseparably connected."  
George Washington
