---
title: Gertrude Stein
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Gertrude Stein

[[+Quotes MOC|Quotes]]

There ain't no answer.  
There ain't going to be any answer.  
There never has been an answer.  
That's the answer.
