---
title: Glennon Doyle Melton
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution: Glennon Doyle Melton
Author: 
fileClass:
  - Quotes
quote: 
source: 
topics:
  - Fear
  - Life
---

# Glennon Doyle Melton

[[+Quotes MOC]]

quote:: Be messy and complicated and afraid and show up anyways.
