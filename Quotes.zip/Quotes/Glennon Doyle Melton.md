---
quote: Be messy and complicated and afraid and show up anyways.
source: 
topics: Fear,Life
tags: quote
fileClass: Quotes
title: Glennon Doyle Melton
creation date: 2024-01-31
modification date: 2024-01-31
---

# Glennon Doyle Melton
