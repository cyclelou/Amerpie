---
quote: The truth will set you free, but first it will piss you off.
source: 
topics: Anger,Truth
tags: quote
fileClass: Quotes
title: Gloria Steinem
creation date: 2024-01-31
modification date: 2024-01-31
---
