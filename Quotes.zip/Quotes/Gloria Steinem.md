---
title: Gloria Steinem
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Gloria Steinen
fileClass: Quotes
source: ""
topics:
  - Anger
  - Truth
---

[[+Quotes MOC]]

# Gloria Steinem

quote:: The truth will set you free, but first it will piss you off.
