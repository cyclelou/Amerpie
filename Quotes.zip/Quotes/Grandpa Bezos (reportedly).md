---
title: Grandpa Bezos (reportedly)
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Grandpa Bezos (reportedly)

[[+Quotes MOC|Quotes]]

One day you'll understand that it's harder to be kind than clever.
