---
title: Groucho Marks
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Groucho Marks

[[+Quotes MOC|Quotes]]

Outside of a dog, a book is a man's best friend. Inside of a dog, it's too dark to read.
