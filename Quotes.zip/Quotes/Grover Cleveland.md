---
title: Grover Cleveland
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Grover Cleveland

[[+Quotes MOC|Quotes]]

Unswerving loyalty to duty, constant devotion to truth, and a clear conscience will overcome every discouragement and surely lead the way to usefulness and high achievement.
