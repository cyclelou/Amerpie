---
title: Gustave Flaubert
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Poetry is a subject as precise as geometry.
source: ""
topics:
  - Poetry
---

# Gustave Flaubert

[[+Quotes MOC|Quotes]]

Anything becomes interesting if you look at it long enough.
