---
quote: Poetry is a subject as precise as geometry.
source: 
topics: Poetry
tags: quote
fileClass: Quotes
title: Gustave Flaubert
creation date: 2024-01-31
modification date: 2024-01-31
---
