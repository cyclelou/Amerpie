---
title: H. Thurman
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# H. Thurman

[[+Quotes MOC|Quotes]]

Don't ask what the world needs. Ask what makes you come alive and go do it. Because what the world needs is people who have come alive.
