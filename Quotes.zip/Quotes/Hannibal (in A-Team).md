---
title: Hannibal (in A-Team)
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Hannibal (in A-Team)

[[+Quotes MOC|Quotes]]

Overkill is underrated, my friend.
