---
title: Harbhajan Singh
url: 
tags:
  - Quote
creation date: 2024-02-26
modification date: 2024-02-26
attribution: Harbhajan Singh
Author: 
fileClass:
  - Quotes
source: 
topics:
  - Friendship
---

# Harbhajan Singh

[[+Quotes MOC]]

I define friendship as a bond that transcends all barriers. When you are ready to expect anything and everything from friends, good, bad or ugly… that's what I call true friendship.
