---
title: Haruki Murakami
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Haruki Murakami

[[+Quotes MOC|Quotes]]

The most important thing we ever learn at school is the fact that the most important things can't be learned at school.

From What I Talk About When I Talk About Running
