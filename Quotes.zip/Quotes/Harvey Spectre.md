---
title: Harvey Spectre
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Harvey Spectre

[[+Quotes MOC|Quotes]]

What are your choices when someone puts a gun to your head? You take the gun, or you pull out a bigger one. Or you call their bluff. Or you do any one of a hundred and forty-six other things.

From Suits
