---
title: Henri Cartier-Bresson
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: A great photograph questions and decides simultaneously.
source: ""
topics:
  - Photography
---
