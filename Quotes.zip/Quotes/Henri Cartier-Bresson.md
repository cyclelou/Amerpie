---
quote: A great photograph questions and decides simultaneously.
source: 
topics: Photography
tags: quote
fileClass: Quotes
title: Henri Cartier-Bresson
creation date: 2024-01-31
modification date: 2024-01-31
---
