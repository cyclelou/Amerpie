---
title: Henri Nouwen
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Henri Nouwen

[[+Quotes MOC|Quotes]]

Compassion asks us to go where it hurts, to enter into the places of pain, to share in brokenness, fear, confusion, and anguish. Compassion challenges us to cry out with those in misery, to mourn with those who are lonely, to weep with those in tears. Compassion requires us to be weak with the weak, vulnerable with the vulnerable, and powerless with the powerless. Compassion means full immersion in the condition of being human.
