---
title: Henrik Ibsen
url: 
tags:
  - Quote
creation date: 2024-01-28
modification date: 2024-02-09
attribution:
  - Henrik Ibsen
 
fileClass:
  - Quotes
source: ""
topics:
  - Truth
---

# Henrik Ibsen

Henrik Ibsen  
"The majority is always wrong. The minority is rarely right."

# Henrik Ibsen

[[+Quotes MOC|Quotes]]

A thousand words will not leave so deep an impression as one deed.
