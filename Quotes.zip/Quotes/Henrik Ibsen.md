---
title: Henrik Ibsen
creation date: 2024-01-28
modification date: 2024-01-31
fileClass: Quotes
attribution:
  - Henrik Ibsen
source: 
tags:
  - quote
topics:
  - truth
---

# Henrik Ibsen

Henrik Ibsen  
"The majority is always wrong. The minority is rarely right."
