---
title: Henry David Thoreau
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Read the best books first, otherwise you’ll find you do not have time.
source: ""
topics:
  - Reading
---

# Henry David Thoreau

# Henry David Thoreau

[[+Quotes MOC|Quotes]]

Simplify simplify– Money is not required to buy one necessity of the soul.

What is the price—current of an honest man and patriot today? They hesitate, and they regret, and sometimes they petition; but they do nothing in earnest and with effect. They will wait, well disposed, for others to remedy the evil, that they may no longer have it to regret.  
(From Civil Disobedience)

If a man does not keep pace with his companions, perhaps it is because he hears a different drummer. Let him step to the music which he hears, however measured or far away.
