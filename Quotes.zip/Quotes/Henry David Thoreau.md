---
quote: Read the best books first, otherwise you’ll find you do not have time.
source: 
topics: Reading
tags: quote
fileClass: Quotes
title: Henry David Thoreau
creation date: 2024-01-31
modification date: 2024-01-31
---

# Henry David Thoreau
