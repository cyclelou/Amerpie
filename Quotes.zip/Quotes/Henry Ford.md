---
quote: “History is more or less bunk.”
source: 
topics: History
tags: quote
fileClass: Quotes
title: Henry Ford
creation date: 2024-01-31
modification date: 2024-01-31
---
