---
title: Henry Ford
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: “History is more or less bunk.”
source: ""
topics:
  - History
---

# Henry Ford

[[+Quotes MOC|Quotes]]

Thinking is the hardest work there is, which is probably the reason why so few engage in it.
