---
title: Henry J. Kaiser
url: 
tags: quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - Henry J. Kaiser
fileClass: Quotes
source: 
topics:
  - Work
---

# Henry J. Kaiser

Henry J. Kaiser

"When your work speaks for itself, don't interrupt."
