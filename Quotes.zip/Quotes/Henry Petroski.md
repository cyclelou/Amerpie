---
title: Henry Petroski
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Henry Petroski

[[+Quotes MOC|Quotes]]

The most amazing achievement of the computer software industry is its continued cancellation of the steady and staggering gains made by the computer hardware industry.
