---
title: Henry Thomas Buckle
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Henry Thomas Buckle

[[+Quotes MOC|Quotes]]

Great minds discuss ideas. Average minds discuss events. Small minds discuss people.
