---
title: Henry Van Dyke
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Henry Van Dyke

[[+Quotes MOC|Quotes]]

Genius is talent set on fire by courage.
