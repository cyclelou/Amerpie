---
title: Henry Young
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Henry Young

[[+Quotes MOC|Quotes]]

Americans are getting stronger. Twenty years ago, it took two people to carry ten dollars worth of groceries. Today, a five year old could do it.
