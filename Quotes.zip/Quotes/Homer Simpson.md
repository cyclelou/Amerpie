---
quote: Just because I don't care doesn't mean I don't understand.
source: 
topics: Understanding
tags: quote
fileClass: Quotes
title: Homer Simpson
creation date: 2024-01-31
modification date: 2024-01-31
---
