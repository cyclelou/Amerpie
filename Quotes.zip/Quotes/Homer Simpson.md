---
title: Homer Simpson
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Just because I don't care doesn't mean I don't understand.
source: ""
topics:
  - Understanding
---
