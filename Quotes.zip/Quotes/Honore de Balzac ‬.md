---
title: Honore de Balzac ‬
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-09
aliases: [Honore De Balzac ‬]
attribution:
  - Honoré de Balzac
 
fileClass:
  - Quotes
source: ""
topics:
  - Self Image
---

# Honore De Balzac ‬

 ‪  
"Nothing is a greater impediment to being on good terms with others than being ill at ease with yourself."  
— Honoré de Balzac

# Honore De Balzac

Honore de Balzac  
It is easy to sit up and take notice, What is difficult is getting up and taking action. -
