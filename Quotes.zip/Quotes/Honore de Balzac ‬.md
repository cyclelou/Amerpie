---
title: Honore de Balzac ‬
url: 
tags:
  - quote
creation date: 2023-12-20
modification date: 2024-02-07
attribution:
  - Honoré de Balzac
fileClass: Quotes
source: 
topics:
  - self-image
---

# Honore De Balzac ‬

 ‪  
"Nothing is a greater impediment to being on good terms with others than being ill at ease with yourself."  
— Honoré de Balzac


# Honore de Balzac
Honore de Balzac
It is easy to sit up and take notice, What is difficult is getting up and taking action. - 