---
quote: ‪It is easy to sit up and take notice, What is difficult is getting up and taking action.
source: 
topics: Action
tags: quote
fileClass: Quotes
title: Honore de Balzac
creation date: 2024-01-31
modification date: 2024-01-31
---
