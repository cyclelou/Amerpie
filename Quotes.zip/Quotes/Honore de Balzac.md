---
title: Honore de Balzac
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution: ""
fileClass:
  - Quotes
quote: ‪It is easy to sit up and take notice, What is difficult is getting up and taking action.
source: ""
topics:
  - Action
---

# Honore De Balzac
