---
quote: Historically, the most terrible things - war, genocide, and slavery - have resulted not from disobedience, but from obedience.
source: 
topics:
  - Government,History
tags:
  - quote
fileClass: Quotes
title: Howard Zinn
creation date: 2024-01-31
modification date: 2024-01-31
---

# Howard Zinn
