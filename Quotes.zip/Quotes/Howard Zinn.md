---
title: Howard Zinn
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution: Howard Zinn
Author: 
fileClass:
  - Quotes
quote: 
source: 
topics:
  - Government
  - History
---

# Howard Zinn

[[+Quotes MOC]]

quote:: Historically, the most terrible things - war, genocide, and slavery - have resulted not from disobedience, but from obedience.
