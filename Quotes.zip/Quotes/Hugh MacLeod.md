---
title: Hugh MacLeod
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Hugh MacLeod

[[+Quotes MOC|Quotes]]

The price of being a sheep is boredom. The price of being a wolf is loneliness. Choose one or the other with great care.

Being good at anything is like figure skating—the definition of being good at it is being able to make it look easy. But it never is easy. Ever. That's what the stupidly wrong people coveniently forget.  
(From <http://gapingvoid.com/2004/08/01/put-the-hours-in/>)
