---
attribution:
  - Immanuel Kant
source: 
tags:
  - quote
topics:
  - action
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Immanuel Kant
---

# Immanuel Kant

<font color="#ff0000">**"To be is to do."**</font>
