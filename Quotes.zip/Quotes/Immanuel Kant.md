---
title: Immanuel Kant
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-13
attribution:
  - Immanuel Kant
fileClass:
  - Quotes
source: ""
topics:
  - Action
---

# Immanuel Kant

<font color="#ff0000">**"To be is to do."**</font>
