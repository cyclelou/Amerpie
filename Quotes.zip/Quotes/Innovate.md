---
quote: Obsession is a word the lazy use to describe the dedicated
source: Trail Shoe Commercial
topics: Inspirational
tags: quote
fileClass: Quotes
title: Innovate
creation date: 2024-01-31
modification date: 2024-01-31
---

# Innovate
