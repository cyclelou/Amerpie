---
title: Innovate
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Obsession is a word the lazy use to describe the dedicated
source:
  - Trail Shoe Commercial
 
topics:
  - Inspirational
---

# Innovate
