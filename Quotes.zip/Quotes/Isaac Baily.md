---
quote: Their lines are so well-rehearsed, I can’t tell if they are sincere or a knee-jerk reaction to any criticism of the South.

“There were slave owners who fought for the North, too.”

“Did you know there were black slave owners?”

“Most white Confederate soldiers were too poor to own slaves.”

“That war had nothing to do with slavery; they invaded our homeland and we had to protect it. That’s why Lincoln will never represent me.”

“Thousands of black people fought for the South.”

“How I wish the South would have freed all the slaves, then fought the war.”
source: Politico
topics: Race,Racism
tags: quote
---
