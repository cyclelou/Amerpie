---
title: Isaac Newton
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Isaac Newton

[[+Quotes MOC|Quotes]]

Truth is ever to be found in simplicity, and not in the multiplicity and confusion of things.

In the absence of any other proof, the thumb alone would convince me of God's existence.
