---
quote: Failure is not fun. It can be awful. But living so cautiously that you never fail is worse.
source: 
topics: Failure
tags: quote
fileClass: Quotes
title: J. K. Rowling
creation date: 2024-01-31
modification date: 2024-01-31
---
