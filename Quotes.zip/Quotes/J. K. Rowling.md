---
title: J. K. Rowling
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution:
  - ""
fileClass: Quotes
quote: Failure is not fun. It can be awful. But living so cautiously that you never fail is worse.
source: ""
topics:
  - Failure
---

# J. K. Rowling
