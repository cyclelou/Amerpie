---
fileClass: Quotes
attribution:
  - J. Paul Getty
source: 
tags:
  - quote
topics:
  - wealth
creation date: 2024-01-29
modification date: 2024-01-31
title: J. Paul Getty
---

# J. Paul Getty

If you owe the bank $100 that's your problem. If you owe the bank $100 million, that's the bank's problem.  
— J. Paul Getty
