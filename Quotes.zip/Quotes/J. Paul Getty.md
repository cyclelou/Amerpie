---
title: J. Paul Getty
url: 
tags:
  - Quote
creation date: 2024-01-29
modification date: 2024-02-09
attribution:
  - J. Paul Getty
 
fileClass:
  - Quotes
source: ""
topics:
  - Wealth
---

# J. Paul Getty

If you owe the bank $100 that's your problem. If you owe the bank $100 million, that's the bank's problem.  
— J. Paul Getty
