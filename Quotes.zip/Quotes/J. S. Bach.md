---
title: J. S. Bach
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# J. S. Bach

[[+Quotes MOC|Quotes]]

There's nothing remarkable about it. All one has to do is hit the right keys at the right time and the instrument plays itself.
