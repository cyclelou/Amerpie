---
title: J.R.R. Tolkien
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# J.R.R. Tolkien

[[+Quotes MOC|Quotes]]

"I wish it need not have happened in my time," said Frodo.  
"So do I," said Gandalf, "and so do all who live to see such times. But that is not for them to decide. All we have to decide is what to do with the time that is given us."

I give hope to men, I keep none for myself. (Aragorn)

One writes such a story not out of the leaves of trees still to be observed, nor by means of botany and soil-science; but it grows like a seed in the dark of the leaf-mould of the mind: out of all that has been seen or thought or read, that has long ago been forgotten, descending into the deeps.  
(From a Biography by Humphrey Carpenter)
