---
title: JFK
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# JFK

[[+Quotes MOC|Quotes]]

Ask not what your country can do for you. Ask what you can do for your country.
