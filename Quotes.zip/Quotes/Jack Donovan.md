---
title: Jack Donovan
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jack Donovan

[[+Quotes MOC|Quotes]]

Men of ideas and men of action have much to learn from each other, and the truly great are men of both action and abstraction.
