---
title: Jack Handey
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jack Handey

[[+Quotes MOC|Quotes]]

Many people never stop to realize that a tree is a living thing, not that different from a tall, leafy dog that has roots and is very quiet.
