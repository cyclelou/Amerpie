---
title: Jack Kerouac
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Because in the end, you won’t remember the time you spent working in the office or mowing your lawn. Climb that goddamn mountain.
source: ""
topics:
  - Motivation
  - Philosophy
  - Self improvement
---

# Jack Kerouac

Because in the end, you won't remember the time you spent working in the office or mowing your lawn. Climb that goddamn mountain.
