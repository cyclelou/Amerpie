---
quote: Because in the end, you won’t remember the time you spent working in the office or mowing your lawn. Climb that goddamn mountain.
source: 
topics:
  - Motivation
  - Philosophy
  - Self improvement
tags:
  - quote
fileClass: Quotes
title: Jack Kerouac
creation date: 2024-01-31
modification date: 2024-01-31
---

# Jack Kerouac

Because in the end, you won't remember the time you spent working in the office or mowing your lawn. Climb that goddamn mountain.
