---
title: Jack London
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jack London

[[+Quotes MOC|Quotes]]

You can't wait for inspiration. You have to go after it with a club.

It is so much easier to live placidly and complacently. Of course, to live placidly and complacently is not to live at all.

A man must venture into the unknown because he is afraid of it.

I would rather be ashes than dust! I would rather that my spark should burn out in a brilliant blaze than it should be stifled by dry-rot. I would rather be a superb meteor, every atom of me in magnificent glow, than a sleepy and permanent planet. The function of man is to live, not to exist. I shall not waste my days in trying to prolong them. I shall use my time. ^ashes
