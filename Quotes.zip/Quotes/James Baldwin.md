---
attribution:
  - James Baldwin
source: 
tags:
  - quote
topics:
  - Love,Patriotism
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: James Baldwin
---

# James Baldwin

You think your pain and your heartbreak are unprecedented in the history of the world, but then you read. It was books that taught me that the things that tormented me most were the very things that connected me with all the people who were alive, or who had ever been alive.

# James Baldwin

"I love America more than any other country in this world, and, exactly for this reason, I insist on the right to criticize her perpetually."
