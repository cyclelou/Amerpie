---
attribution:
  - James Clear
source: 
tags:
  - quote
topics:
  - work
creation date: 2024-01-23
modification date: 2024-01-31
fileClass: Quotes
title: James Clear
---

# James Clear

The most invisible form of wasted time is doing a good job on an unimportant task.
