---
title: James Clear
url: 
tags:
  - Quote
creation date: 2024-01-23
modification date: 2024-02-09
attribution:
  - James Clear
 
fileClass:
  - Quotes
source: ""
topics:
  - Work
---

# James Clear

The most invisible form of wasted time is doing a good job on an unimportant task.

# James Clear

[[+Quotes MOC|Quotes]]

Anyone connected to the internet has the education power of a university and the distribution power of a media company at their fingertips.

Many people think they lack motivation when what they really lack is clarity. ^taskclarity
