---
title: James Rebanks
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: This landscape is our home and we rarely stray long from it, or endure anywhere else for long before returning. This may seem like a lack of imagination or adventure, but I don’t care. I love this place; for me it is the beginning and the end of everything, and everywhere else feels like nowhere
source: A Shepherd's Life
topics:
  - Literature
  - Writing
---

# James Rebanks
