---
title: James Shelley
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# James Shelley

[[+Quotes MOC|Quotes]]

Remember that you are a leader not to the degree that you are an expert, but to the degree that you effectively work with those around you.  
From <http://jamesshelley.net/2013/04/the-experts/>
