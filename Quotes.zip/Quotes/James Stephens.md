---
title: James Stephens
url: 
tags:
  - Quote
creation date: 2024-02-10
modification date: 2024-02-10
attribution:
  - James Stephens
fileClass: Quotes
source: 
topics:
  - Curiousity
---

# James Stephens

quote:: "Curiosity will conquer fear even more than bravery will."
