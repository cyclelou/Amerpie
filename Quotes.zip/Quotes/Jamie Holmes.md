---
title: Jamie Holmes
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jamie Holmes

[[+Quotes MOC|Quotes]]

Having negative capability means having a low need for closure, even in stressful situations. It's not the same as being indecisive. Negative capability just means not fixating for clutching one aspect of a complex and shifting reality. It's a special form of restraint.  
From Nonsense
