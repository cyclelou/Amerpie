---
title: Jason Nabb
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jason Nabb

[[+Quotes MOC|Quotes]]

The single greatest human motivator: Task clarity. ^motivation
