---
title: Jay Wilkenson
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jay Wilkenson

[[+Quotes MOC|Quotes]]

You can't stop the waves but you can learn to surf.
