---
quote: Our entire life - consists ultimately in accepting ourselves as we are
source: 
topics:
  - Acceptance,Self improvement
tags:
  - quote
fileClass: Quotes
title: Jean Anouilh
creation date: 2024-01-31
modification date: 2024-01-31
---

# Jean Anouilh
