---
title: Jean Anouilh
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Jean Anouilh
fileClass: Quotes
source: ""
topics:
  - Acceptance
  - Self improvement
---

# Jean Anouilh

quote:: Our entire life - consists ultimately in accepting ourselves as we are.
