---
title: Jean Cocteau
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Jean Cocteau
fileClass: Quotes
source: ""
topics:
  - Comfort
  - Fear
---

[[+Quotes MOC]]

# Jean Cocteau

quote:: You have comfort. You don't have luxury. And don't tell me that money plays a part. The luxury I advocate has nothing to do with money. It cannot be bought. It is the reward of those who have no fear of discomfort.
