---
quote: He who jumps into the void owes no explanation to those who stand and watch.
source: 
tags:
  - quote
fileClass: Quotes
title: Jean-Luc Godard
creation date: 2024-01-31
modification date: 2024-01-31
---

# Jean-Luc Godard
