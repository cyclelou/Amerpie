---
title: Jean-Paul Sartre
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-03-03
attribution: Jean-Paul Sartre
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Optimism
  - Knowledge
---

[[+Quotes MOC]]

# Jean-Paul Sartre

quote:: "With despair, true optimism begins: the optimism of the man who expects nothing, who knows he has no rights and nothing coming to him, who rejoices in counting on himself alone and in acting alone for the good of all."  

quote:: "Everything has been figured out, except how to live."
