---
attribution:
  - Jean-Paul Sartre
source: 
tags:
  - quote
topics:
  - optimism
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Jean-Paul Sartre
---

# Jean-Paul Sartre

"With despair, true optimism begins: the optimism of the man who expects nothing, who knows he has no rights and nothing coming to him, who rejoices in counting on himself alone and in acting alone for the good of all."  
— Jean-Paul Sartre
