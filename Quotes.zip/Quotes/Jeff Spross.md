---
title: Jeff Spross
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-25
attribution:
  - Jeff Spross
Author: 
fileClass:
  - Quotes
source: The Week
topics:
  - Politics
  - 2016 Election
---

# Jeff Spross

If Trump is going to take the stage at debates and say "build a wall and deport the immigrants," Clinton will need a better retort than "non-refundable income-scaling tax credits for certain classes of Americans."
