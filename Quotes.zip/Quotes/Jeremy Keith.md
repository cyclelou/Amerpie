---
title: Jeremy Keith
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jeremy Keith

[[+Quotes MOC|Quotes]]

Maybe reinventing the wheel isn't such a bad idea if all you have to work with is a square wheel.  
From HTML5 for Designers
