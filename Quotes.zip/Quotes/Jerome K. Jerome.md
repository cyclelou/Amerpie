---
title: Jerome K. Jerome
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jerome K. Jerome

[[+Quotes MOC|Quotes]]

I like work—it fascinates me—I can sit and look at it for hours.

Alas! alas! ere thirty he has joined the ranks of the sneerers. It is not his fault. Our passions, both the good and bad, cease with our blushes. We do not hate, nor grieve, nor joy, nor despair in our thirties like we did in our teens. Disappointment does not suggest suicide, and we quaff success without intoxication.
