---
quote: In religion, faith is a virtue. In science, faith is a vice.
source: 
topics: Religion,Science
tags: quote
fileClass: Quotes
title: Jerry Coyne
creation date: 2024-01-31
modification date: 2024-01-31
---
