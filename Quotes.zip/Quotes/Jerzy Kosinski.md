---
title: Jerzy Kosinski
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jerzy Kosinski

[[+Quotes MOC|Quotes]]

Going around under an umbrella interferes with one's looking up at the sky.
