---
title: Jim Collins
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jim Collins

[[+Quotes MOC|Quotes]]

If you have more than three priorities, then you don't have any.
