---
title: Jim Elliot
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jim Elliot

[[+Quotes MOC|Quotes]]

He is no fool who gives what he cannot keep to gain what he cannot lose.
