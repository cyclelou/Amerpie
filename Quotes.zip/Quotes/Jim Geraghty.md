---
title: Jim Geraghty
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: Years of effort spent attempting to dispel the accusations of inherent Republican misogyny, xenophobia, hypocrisy, ignorance and blind rage have been undone by Trump’s campaign.
source:
  - National Review
topics:
  - Politics
  - Republicans
---
