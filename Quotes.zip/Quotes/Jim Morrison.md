---
title: Jim Morrison
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jim Morrison

[[+Quotes MOC|Quotes]]

We fear violence less than our own feelings. Personal, private, solitary pain is more terrifying than what anyone else can inflict.
