---
title: Jim Rohn
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jim Rohn

[[+Quotes MOC|Quotes]]

Formal education will make you a living. Self-education will make you a fortune.

Take advantage of every opportunity to practice your communication skills so that when important occasions arise, you will have the gift, the style, the sharpness, the clarity, and the emotions to affect other people.

We must suffer one of two things: the pain of discipline or the pain of regret and disappointment.

The more you know the less you need to say.

Maturity is the ability to reap without apology and not complain when things don't go well.

Effective communication is 20% what you know and 80% what you feel about what you know.

Success is doing ordinary things extraordinarily well.
