---
title: Joan Westenberg
url: 
tags:
  - Quote
creation date: 2024-01-28
modification date: 2024-02-09
attribution:
  - Joan Westenberg
 
fileClass:
  - Quotes
source: ""
topics:
  - Healthcare
---

# Joan Westenberg

Joan Westenberg

'Ask not what your country can do for you,' because chances are, there's probably a form for that, and it's not covered by your plan
