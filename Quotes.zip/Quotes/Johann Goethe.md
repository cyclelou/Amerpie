---
title: Johann Goethe
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Johann Goethe

[[+Quotes MOC|Quotes]]

The hardest thing to see is what is in front of your eyes.

#### Related

[[George Orwell]]
