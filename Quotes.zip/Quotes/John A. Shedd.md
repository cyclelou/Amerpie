---
title: John A. Shedd
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John A. Shedd

[[+Quotes MOC|Quotes]]

A ship in a harbor is safe, but that is not what ships are built for.
