---
quote: “Too often we enjoy the comfort of opinion without the discomfort of thought."
source: 
topics: Opinion,Philosophy
tags: quote
fileClass: Quotes
title: John F. Kennedy
creation date: 2024-01-31
modification date: 2024-01-31
---
