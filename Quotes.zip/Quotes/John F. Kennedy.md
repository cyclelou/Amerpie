---
title: John F. Kennedy
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - John F. Kennedy
fileClass: Quotes
quote: 
source: ""
topics:
  - Opinion
  - Philosophy
  - Comfort
---

# John F. Kennedy

[[+Quotes MOC|Quotes]]

quote:: A nation that is afraid to let its people judge the truth and falsehood in an open market is a nation that is afraid of its people. ^freespeech

quote:: The great enemy of truth is very often not the lie—deliberate, contrived and dishonest, but the myth, persistent, persuasive, and unrealistic. Belief in myths allows the comfort of opinion without the discomfort of thought.

quote:: "Too often we enjoy the comfort of opinion without the discomfort of thought."
