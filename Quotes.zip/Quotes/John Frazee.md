---
title: John Frazee
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John Frazee

[[+Quotes MOC|Quotes]]

When a cat is dropped, it always lands on its feet, and when toast is dropped, it always lands with the buttered side facing down. I propose to strap buttered toast to the back of a cat; the two will hover, spinning, inches above the ground. With a giant butter-cat array, a high-speed monorail could easily link New York with Chicago.  
(From Journal Of Irreproducible Results)
