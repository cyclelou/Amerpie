---
title: John Green
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John Green

[[+Quotes MOC|Quotes]]

What I actually needed was someone to tell me that it hurt because it mattered. I have found it very useful to think about over the years, and I find that it is a lot easier and more bearable to be sad when you aren't constantly berating yourself for being sad.

…because nerds like us are allowed to be unironically enthusiastic about stuff. Nerds are allowed to love stuff, like jump-up-and-down-in-the-chair-can't-control-yourself love it. Hank, when people call people nerds, mostly what they're saying is 'you like stuff'. Which is just not a good insult at all. Like 'you are too enthusiastic about the miracle of human consciousness'.
