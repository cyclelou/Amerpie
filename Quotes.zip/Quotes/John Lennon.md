---
title: John Lennon
url: 
tags:
  - Quote
creation date: 2024-01-07
modification date: 2024-02-09
attribution:
  - John Lennon
 
fileClass:
  - Quotes
source: ""
topics:
  - Imagination
---

# John Lennon

"Reality leaves a lot to the imagination."  
John Lennon

# John Lennon

[[+Quotes MOC|Quotes]]

I believe time wounds all heals.
