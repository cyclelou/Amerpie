---
attribution:
  - John Lennon
source: 
tags:
  - quote
topics:
  - imagination
creation date: 2024-01-07
modification date: 2024-01-31
fileClass: Quotes
title: John Lennon
---

# John Lennon

"Reality leaves a lot to the imagination."  
John Lennon
