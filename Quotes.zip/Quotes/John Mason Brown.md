---
title: John Mason Brown
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John Mason Brown

[[+Quotes MOC|Quotes]]

A good conversationalist is not one who remembers what was said, but says what someone wants to remember.
