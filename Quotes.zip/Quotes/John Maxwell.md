---
title: John Maxwell
url: 
tags:
  - Quote
creation date: 2024-02-26
modification date: 2024-02-26
attribution: John Maxwell
Author: 
fileClass:
  - Quotes
source: 
topics:
  - Importance
---

# John Maxwell

John Maxwell

[[+Quotes MOC]]

quote:: You cannot overestimate the unimportance of practically everything.
