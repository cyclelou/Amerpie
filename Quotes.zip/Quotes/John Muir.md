---
attribution: John Muir
source: 
tags:
  - quote
topics:
  - nature
creation date: 2024-01-12
modification date: 2024-01-31
fileClass: Quotes
title: John Muir
---

# John Muir

 "And into the forest I go to lose my mind and find my soul."

-- John Muir
