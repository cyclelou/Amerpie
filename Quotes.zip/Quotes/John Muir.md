---
title: John Muir
url: 
tags:
  - Quote
creation date: 2024-01-12
modification date: 2024-02-09
attribution:
  - John Muir
 
fileClass:
  - Quotes
source: ""
topics:
  - Nature
---

# John Muir

 "And into the forest I go to lose my mind and find my soul."

-- John Muir
