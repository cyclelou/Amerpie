---
title: John Parker
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John Parker

[[+Quotes MOC|Quotes]]

A runner is a miser, spending the pennies of his energy with great stinginess, constantly wanting to know how much he has spent and how much longer he will be expected to pay. He wants to be broke at precisely the moment he no longer needs his coin.
