---
title: John Pavlovitz
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: John Pavlovitz
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Culture
  - Politics
  - Religion
---

# John Pavlovitz

quote:: They passionately worship a deity made in their own image: white, American, Republican, male—and perpetually terrified of just about everything: Muslims, immigrants, gay children, Special Counsel reports, mandalas, Harry Potter, Starbuck holiday cups, yoga, wind turbines, Science—everything.

quote:: Their God is so laughably minuscule, so fully neutered of power, so completely devoid of functioning vertebrae that "He" cannot protect them from the encroaching monsters they are certain lurk around every corner to overwhelm them.  
source:
