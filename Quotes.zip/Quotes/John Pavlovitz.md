---
topics:
  - Culture
  - Politics
  - Religion
tags:
  - quote
fileClass: Quotes
attribution:
  - John Pavlovitz
source: 
creation date: 2024-01-31
modification date: 2024-01-31
title: John Pavlovitz
---

# John Pavlovitz

They passionately worship a deity made in their own image: white, American, Republican, male—and perpetually terrified of just about everything: Muslims, immigrants, gay children, Special Counsel reports, mandalas, Harry Potter, Starbuck holiday cups, yoga, wind turbines, Science—everything.

Their God is so laughably minuscule, so fully neutered of power, so completely devoid of functioning vertebrae that "He" cannot protect them from the encroaching monsters they are certain lurk around every corner to overwhelm them.  
source:
