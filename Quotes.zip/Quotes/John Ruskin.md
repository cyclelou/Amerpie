---
title: John Ruskin
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John Ruskin

[[+Quotes MOC|Quotes]]

A man is one whose body has been trained to be the ready servant of his mind; whose passions are trained to be the servants of his will; who enjoys the beautiful, loves truth, hates wrong, loves to do good, and respects others as himself.
