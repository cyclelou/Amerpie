---
title: John Smith
url: 
tags:
  - Quote
creation date: 2024-01-29
modification date: 2024-02-09
attribution:
  - John Smith
 
fileClass:
  - Quotes
source: ""
topics:
  - Philosophy
---

# John Smith

Some really deep shit.  
-- John Smith
