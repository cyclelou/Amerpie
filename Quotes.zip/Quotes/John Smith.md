---
title: John Smith
attribution:
  - John Smith
source: 
tags:
  - quote
topics:
  - philosophy
creation date: 2024-01-29
modification date: 2024-01-31
fileClass: Quotes
---

# John Smith

Some really deep shit.  
-- John Smith
