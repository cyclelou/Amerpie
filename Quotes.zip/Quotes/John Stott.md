---
title: John Stott
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# John Stott

[[+Quotes MOC|Quotes]]

For the essence of sin is man substituting himself for God, while the essence of salvation is God substituting Himself for man.
