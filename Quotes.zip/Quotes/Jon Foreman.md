---
title: Jon Foreman
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jon Foreman

[[+Quotes MOC|Quotes]]

Hope waits in the shadows. And it shines brightest in the dark and broken places.

The dragons that some of us are running from are the very dragons that others are chasing.

We bring the songs we love to uncomfortable places, because that's where we feel they're needed.
