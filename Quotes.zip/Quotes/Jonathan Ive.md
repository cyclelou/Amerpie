---
title: Jonathan Ive
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Jonathan Ive

[[+Quotes MOC|Quotes]]

It's very easy to be different, but very difficult to be better.
