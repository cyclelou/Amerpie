---
attribution:
  - Joseph Brodsky
source: 
tags:
  - quote
topics:
  - reading
  - knowledge
creation date: 2024-01-23
modification date: 2024-01-31
fileClass: Quotes
title: Joseph Brodsky
---

# Joseph Brodsky

"Man is what he reads."
