---
title: Joseph Brodsky
url: 
tags:
  - Quote
creation date: 2024-01-23
modification date: 2024-02-09
attribution:
  - Joseph Brodsky
 
fileClass:
  - Quotes
source: ""
topics:
  - Reading
  - Knowledge
---

# Joseph Brodsky

"Man is what he reads."
