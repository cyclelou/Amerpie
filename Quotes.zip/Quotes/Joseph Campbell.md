---
quote: The  privilege of a lifetime is being who you are.
source: 
topics: Self
tags: quote
fileClass: Quotes
title: Joseph Campbell
creation date: 2024-01-31
modification date: 2024-01-31
---

# Joseph Campbell
