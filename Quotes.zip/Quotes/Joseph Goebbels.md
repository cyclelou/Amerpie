---
quote: If you tell a lie big enough and keep repeating it, people will eventually come to believe it. The lie can be maintained only for such time as the State can shield the people from the political, economic and/or military consequences of the lie. It thus becomes vitally important for the State to use all of its powers to repress dissent, for the truth is the mortal enemy of the lie, and thus by extension, the truth is the greatest enemy of the State.
source: 
topics: Government,Truth
tags: quote
fileClass: Quotes
title: Joseph Goebbels
creation date: 2024-01-31
modification date: 2024-01-31
---
