---
title: Joseph Henry
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Joseph Henry

[[+Quotes MOC|Quotes]]

The seeds of great discovery are constantly floating around us, but they only take root in minds well prepared to receive them.
