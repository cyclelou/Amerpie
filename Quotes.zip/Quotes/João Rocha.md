---
title: João Rocha
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: There are only 2 kinds of people in this world, those that find this blog hilarious and those that have no sense of humor whatsoever.
source:
  - Beautiful, clever blog
 
topics:
  - Humor
---

# João Rocha
