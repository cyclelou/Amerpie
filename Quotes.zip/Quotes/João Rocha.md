---
quote: There are only 2 kinds of people in this world, those that find this blog hilarious and those that have no sense of humor whatsoever.
source: Beautiful, clever blog
topics: Humor
tags: quote
fileClass: Quotes
title: João Rocha
creation date: 2024-01-31
modification date: 2024-01-31
---

# João Rocha
