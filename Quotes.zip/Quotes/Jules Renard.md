---
quote: It is not how old you are, but how you are old.
source: 
topics: Aging
tags: quote
fileClass: Quotes
title: Jules Renard
creation date: 2024-01-31
modification date: 2024-01-31
---
