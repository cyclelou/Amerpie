---
title: Jules Renard
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: It is not how old you are, but how you are old.
source: ""
topics:
  - Aging
---
