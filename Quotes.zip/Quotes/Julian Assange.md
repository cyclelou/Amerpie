---
title: Julian Assange
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Julian Assange

[[+Quotes MOC|Quotes]]

Nearly every war that has started in the past 50 years has been a result of media lies. ^war
