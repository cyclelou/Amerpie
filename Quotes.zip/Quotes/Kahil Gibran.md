---
title: Kahil Gibran
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: “You talk when you cease to be at peace with your thoughts.”
source:
  - The Prophet
 
topics:
  - Peace
---
