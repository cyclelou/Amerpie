---
quote: “You talk when you cease to be at peace with your thoughts.”
source: The Prophet
topics: Peace
tags: quote
fileClass: Quotes
title: Kahil Gibran
creation date: 2024-01-31
modification date: 2024-01-31
---
