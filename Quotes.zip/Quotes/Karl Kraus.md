---
title: Karl Kraus
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Karl Kraus

[[+Quotes MOC|Quotes]]

An aphorism is never exactly true. It is either a half-truth or a truth and a half.
