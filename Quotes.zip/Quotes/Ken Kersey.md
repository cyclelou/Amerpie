---
title: Ken Kersey
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ken Kersey

[[+Quotes MOC|Quotes]]

You can count how many seeds are in the apple, but not how many apples are in the seed.
