---
title: Kenworth Reeves Jr.
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Kenworth Reeves Jr

[[+Quotes MOC|Quotes]]

Don't be discouraged. If it was easy, then everyone would be doing it. In fact, easy adventures tend to create boring stories.  
From <https://twitter.com/theandhedrew/status/151152576639930369>
