---
title: Kevin DeYoung
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Kevin DeYoung

[[+Quotes MOC|Quotes]]

So we can stop pleading with God to show us the future, and start living and obeying like we are confident that He holds the future.  
From Just Do Something
