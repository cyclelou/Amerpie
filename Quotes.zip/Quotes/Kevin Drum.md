---
title: Kevin Drum
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: Maybe what the GOP really needs is an institutional-size Prozac. Or Viagra. Or something.
source: Mother Jones
topics:
  - Politics
  - Republicans
---
