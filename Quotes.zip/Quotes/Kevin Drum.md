---
quote: Maybe what the GOP really needs is an institutional-size Prozac. Or Viagra. Or something.
source: Mother Jones
topics: Politics,Republicans
tags: quote
fileClass: Quotes
title: Kevin Drum
creation date: 2024-01-31
modification date: 2024-01-31
---
