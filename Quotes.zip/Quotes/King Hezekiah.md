---
title: King Hezekiah
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# King Hezekiah

[[+Quotes MOC|Quotes]]

Surely it was for my benefit that I suffered such anguish.  
(Isaiah 38:17) ^benefit

---

[[The Problem of Pain]]
