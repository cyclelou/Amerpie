---
title: Kori Feener
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Kori Feener
fileClass: Quotes
source: SB Nation
topics:
  - Appalachian Trail
  - Hiking
---

# Kori Feener

quote:: The trail is a present endeavor, with the focus often being on the pain you are in, the beauty you saw that day, where you are going to sleep that night and where your next water source is.
