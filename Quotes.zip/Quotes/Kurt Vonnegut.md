---
quote: True terror is to wake up one morning and discover that your high school class is running the country.
source: 
topics: Humor,Philosophy
tags: quote
fileClass: Quotes
title: Kurt Vonnegut
creation date: 2024-01-31
modification date: 2024-01-31
---
