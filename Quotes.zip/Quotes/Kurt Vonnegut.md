---
title: Kurt Vonnegut
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - ""
fileClass:
  - Quotes
quote: True terror is to wake up one morning and discover that your high school class is running the country.
source: ""
topics:
  - Humor
  - Philosophy
---

# Kurt Vonnegut
