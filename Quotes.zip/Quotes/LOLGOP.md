---
quote: Still waiting for the first openly scientific Republican.
source: Twitter
topics: Humor,Republicans
tags: quote
fileClass: Quotes
title: LOLGOP
creation date: 2024-01-31
modification date: 2024-01-31
---
