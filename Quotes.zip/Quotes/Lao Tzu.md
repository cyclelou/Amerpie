---
title: Lao Tzu
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-13
attribution:
  - Lao Tzu
fileClass: Quotes
source: ""
topics:
  - Accomplishment
---

# Lao Tzu

"Nature does not hurry, yet everything is accomplished."  
— Lao Tzu
