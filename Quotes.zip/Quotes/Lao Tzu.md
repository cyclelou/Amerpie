---
attribution:
  - Lao Tzu
source: 
tags:
  - quote
topics:
  - accomplishment
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Lao Tzu
---

# Lao Tzu

"Nature does not hurry, yet everything is accomplished."  
— Lao Tzu
