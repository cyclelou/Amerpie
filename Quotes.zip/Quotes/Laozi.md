---
title: Laozi
url: 
tags:
  - Quote
creation date: 2024-01-24
modification date: 2024-02-13
attribution:
  - Laozi
fileClass: Quotes
source: ""
topics:
  - Contentment
  - Happiness
---

[[+Quotes MOC]]

# Laozi

quote:: He who is contented is rich.  
