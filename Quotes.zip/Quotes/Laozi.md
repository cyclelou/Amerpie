---
attribution:
  - Laozi
source: 
tags:
  - quote
topics:
  - contentment
  - happiness
creation date: 2024-01-24
modification date: 2024-01-31
fileClass: Quotes
title: Laozi
---

# Laozi

He who is contented is rich.  
— Laozi
