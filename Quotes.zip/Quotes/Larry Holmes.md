---
title: Larry Holmes
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: It's hard being black. You ever been black? I was black once -- when I was poor.
source: ""
topics:
  - Poverty
  - Race
---

# Larry Holmes
