---
quote: It's hard being black. You ever been black? I was black once -- when I was poor.
source: 
topics: Poverty,Race
tags: quote
fileClass: Quotes
title: Larry Holmes
creation date: 2024-01-31
modification date: 2024-01-31
---

# Larry Holmes
