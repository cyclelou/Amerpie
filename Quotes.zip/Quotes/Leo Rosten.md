---
title: Leo Rosten
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Leo Rosten

[[+Quotes MOC|Quotes]]

You can understand and relate to most people better if you look at them—no matter how old or impressive they may be—as if they are children. For most of us never really grow up or mature all that much—we simply grow taller. Oh, to be sure, we laugh less and play less and wear uncomfortable disguises like adults, but beneath the costume is the child we always are, whose needs are simple, whose daily life is still best described by fairy tales.
