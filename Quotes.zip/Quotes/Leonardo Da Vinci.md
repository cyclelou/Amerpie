---
title: Leonardo Da Vinci
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Leonardo Da Vinci

[[+Quotes MOC|Quotes]]

Once you have tasted flight, you will forever walk the earth with your eyes turned skyward, for there you have been, and there you will always long to return.

Simplicity is the ultimate sophistication.
