---
title: Lord Baden-Powell
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Lord Baden-Powell

[[+Quotes MOC|Quotes]]

We never fail when we try to do our duty, we always fail when we neglect to do it.
