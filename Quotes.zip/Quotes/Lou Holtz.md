---
quote: If you're bored with life - you don't get up every morning with a burning desire to do things - you don't have enough goals.
source: 
topics: Goals
tags: quote
fileClass: Quotes
title: Lou Holtz
creation date: 2024-01-31
modification date: 2024-01-31
---
