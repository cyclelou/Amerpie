---
title: Lou Holtz
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-03-04
attribution: Lou Holtz
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Goals
  - Action
---

# Lou Holtz

[[+Quotes MOC|Quotes]]

quote:: I can't believe that God put us on earth to be ordinary.

quote:: Ability is what you're capable of doing. Motivation determines what you do. Attitude determines how well you do it.

quote:: If you're bored with life - you don't get up every morning with a burning desire to do things - you don't have enough goals.
