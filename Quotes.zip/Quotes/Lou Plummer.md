---
attribution:
  - Lou Plummer
source: micro.blog
tags:
  - quote
topics:
  - technology
  - Military
  - Veterans Day
creation date: 2024-01-23
modification date: 2024-01-31
fileClass: Quotes
title: Lou Plummer
---

# Lou Plummer

After 30 years of owning a computer and at the end of a career deeply involved in technology, I still look forward to sitting with my Mac and discovering the cool things it can do. I hope I never lose that feeling.

# Lou Plummer

It really would be great if we only sacrificed our young people for freedom, but that's not the case. That doesn't detract from their commitment and it should only deepen our sorrow
