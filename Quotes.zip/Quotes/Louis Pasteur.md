---
title: Louis Pasteur
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Louis Pasteur

[[+Quotes MOC|Quotes]]

The greatest aberration of the mind is to believe a thing to be, because we desire it.

Bernard was right. The microbe is nothing, the soil is everything. [^1]

[^1]: [[Germ Theory]]
