---
title: Lucille Ball
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution:
  - Lucille Ball
 
fileClass:
  - Quotes
source: ""
topics:
  - Life
  - Regrets
---

# Lucille Ball

"I'd rather regret the things I've done than regret the things I haven't done.
