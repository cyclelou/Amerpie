---
attribution:
  - Lucille Ball
source: 
tags:
  - quote
topics:
  - life
  - Regrets
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
title: Lucille Ball
---

# Lucille Ball

"I'd rather regret the things I've done than regret the things I haven't done.
