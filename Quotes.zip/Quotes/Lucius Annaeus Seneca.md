---
title: Lucius Annaeus Seneca
url: 
tags:
  - Quote
creation date: 2024-01-24
modification date: 2024-02-09
attribution:
  - Lucius Annaeus Seneca
 
fileClass:
  - Quotes
source: ""
topics: ""
---

# Lucius Annaeus Seneca

Lucius Annaeus Seneca  
"Wherever there is a human being, there is an opportunity for a kindness."
