---
attribution:
  - Lucius Annaeus Seneca
source: 
tags:
  - quote
topics: 
creation date: 2024-01-24
modification date: 2024-01-31
fileClass: Quotes
title: Lucius Annaeus Seneca
---

# Lucius Annaeus Seneca

Lucius Annaeus Seneca  
"Wherever there is a human being, there is an opportunity for a kindness."
