---
title: Lucius Anneas Seneca
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Lucius Anneas Seneca

[[+Quotes MOC|Quotes]]

You should keep learning as long as there is something you do not know.
