---
title: Ludwig Van Beethoven
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ludwig Van Beethoven

[[+Quotes MOC|Quotes]]

Don't only practice your art, but force your way into its Secrets, for it and knowledge can raise men to the Divine.
