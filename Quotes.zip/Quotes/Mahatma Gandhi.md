---
quote: Live as if you were to die tomorrow. Learn as if you were to live forever.
source: 
topics: Learning
tags: quote
fileClass: Quotes
title: Mahatma Gandhi
creation date: 2024-01-31
modification date: 2024-01-31
---

# Mahatma Gandhi
