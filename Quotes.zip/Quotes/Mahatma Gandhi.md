---
title: Mahatma Ghandi
url: 
tags:
  - Quote
creation date: 2024-02-20
modification date: 2024-02-20
attribution: Mahatma Gandhi
fileClass:
  - Quotes
source: 
topics:
  - Learning
  - Thoughts
---

# Mahatma Gandhi



quote:: Live as if you were to die tomorrow. Learn as if you were to live forever.

quote:: "A man is but the product of his thoughts, what he thinks he becomes."
