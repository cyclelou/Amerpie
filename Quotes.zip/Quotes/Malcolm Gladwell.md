---
title: Malcolm Gladwell
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Malcolm Gladwell

[[+Quotes MOC|Quotes]]

Courage is not something that you already have that makes you brave when the tough times start. Courage is what you earn when you've been through the tough times and you discover they aren't so tough after all.
