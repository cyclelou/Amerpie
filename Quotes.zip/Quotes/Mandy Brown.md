---
title: Mandy Brown
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Mandy Brown

[[+Quotes MOC|Quotes]]

Always read with a pen in hand. The pen should be used both to mark the text you want to remember and to write from where the text leaves you. Think of the text as the starting point for your own words.
