---
quote: Let us be grateful to people who make us happy, they are the charming gardeners who make our souls blossom
source: 
topics: Happiness,Philosophy
tags: quote
fileClass: Quotes
title: Marcel Proust
creation date: 2024-01-31
modification date: 2024-01-31
---
