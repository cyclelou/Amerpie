---
title: Marcin Jakubowski
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Marcin Jakubowski

[[+Quotes MOC|Quotes]]

I finished my 20s with a PhD in fusion energy, and I discovered I was useless.
