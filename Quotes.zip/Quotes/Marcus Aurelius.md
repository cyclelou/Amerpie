---
quote: Remember this: that very little is needed to make a happy life.
source:  
topics: Happiness
tags: quote
---
