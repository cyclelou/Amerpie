---
title: Marcus Tullius
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Marcus Tullius

[[+Quotes MOC|Quotes]]

A room without books is like a body without a soul.
