---
title: Margaret Bonnano
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Margaret Bonnano

[[+Quotes MOC|Quotes]]

Being rich is having money, being wealthy is having time.  
The few who DO are the people who only watch.
