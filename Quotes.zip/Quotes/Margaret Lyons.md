---
title: Margaret Lyons
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Los Angeles is a complicated place, where people from all over the world convene to disappoint one another...
source:
  - New York Times
 
topics:
  - Disappointment
---
