---
quote: Los Angeles is a complicated place, where people from all over the world convene to disappoint one another...
source: New York Times
topics: Disappointment
tags: quote
fileClass: Quotes
title: Margaret Lyons
creation date: 2024-01-31
modification date: 2024-01-31
---
