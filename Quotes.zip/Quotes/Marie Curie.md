---
title: Marie Curie
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Marie Curie

[[+Quotes MOC|Quotes]]

Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we can fear less.
