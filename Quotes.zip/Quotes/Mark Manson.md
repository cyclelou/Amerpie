---
title: Mark Manson
url: 
tags:
  - Quote
creation date: 2024-01-23
modification date: 2024-02-09
attribution:
  - Mark Manson
 
fileClass:
  - Quotes
source: ""
topics:
  - Wisdom
---

# Mark Manson

# Mark Manson

Mark Manson  
"Wisdom is when you stop over-investing in every shiny new idea, feeling, or person that comes along."
