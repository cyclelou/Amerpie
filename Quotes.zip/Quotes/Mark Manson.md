---
attribution:
  - Mark Manson
source: 
tags:
  - quote
topics:
  - wisdom
creation date: 2024-01-23
modification date: 2024-01-31
fileClass: Quotes
title: Mark Manson
---

# Mark Manson

# Mark Manson

Mark Manson  
"Wisdom is when you stop over-investing in every shiny new idea, feeling, or person that comes along."
