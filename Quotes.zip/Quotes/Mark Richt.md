---
title: Mark Richt
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Mark Richt

[[+Quotes MOC|Quotes]]

"People tend to rise to the expectations you set for them."  
— M
