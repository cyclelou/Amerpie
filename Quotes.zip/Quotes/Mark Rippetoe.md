---
quote: Strong people are harder to kill then weak people and generally more useful.
source: Strong Enough
topics: Fitness,Strength
tags: quote
fileClass: Quotes
title: Mark Rippetoe
creation date: 2024-01-31
modification date: 2024-01-31
---

# Mark Rippetoe
