---
title: Mark Rippetoe
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-18
attribution: Mark Rippetoe
Author: 
fileClass:
  - Quotes
source: Strong Enough
topics:
  - Fitness
  - Strength
---

# Mark Rippetoe

[[+Quotes MOC]]

quote:: Strong people are harder to kill then weak people and generally more useful.
