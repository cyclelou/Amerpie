---
title: Mark Twain
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-26
attribution: Mark Twain
Author: 
fileClass:
  - Quotes
source: ""
topics:
  - Work
  - Judgement
  - Courage
  - Dreams
  - Knowledge
  - Belief
---

# Mark Twain

[[+Quotes MOC|Quotes]]

quote:: I am an old man and have known a great many troubles, but most of them never happened.

quote:: It ain't what you don't know that gets you into trouble. It's what you know for sure that just ain't so.

quote:: So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover.

quote:: It is curious that physical courage should be so common in the world and moral courage so rare. ^courage

quote:: It's easier to fool people than to convince them that they have been fooled.  
(note: [NOT actually](https://quoteinvestigator.com/2020/12/23/fooled/) a Mark Twain quote, but a delightful troll)

quote:: "If it's your job to eat a frog, it's best to do it first thing in the morning. And If it's your job to eat two frogs, it's best to eat the biggest one first."
