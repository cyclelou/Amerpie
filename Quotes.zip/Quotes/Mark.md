---
title: Mark
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - ""
fileClass:
  - Quotes
quote: “For what shall it profit a man, if he shall gain the whole world, but lose his soul?” — Mark 8:36.
source:
  - The Bible
topics:
  - Finance
  - Philosophy
---

# Mark
