---
quote: There are no passengers in spaceship earth. We are all crew.
source: 
topics: Action
tags: quote
fileClass: Quotes
title: Marshall McLuhan
creation date: 2024-01-31
modification date: 2024-01-31
---
