---
title: Martin Luther King, Jr.
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-13
attribution:
  - Martin Luther King, Jr.
fileClass:
  - Quotes
source: ""
topics:
  - Capitalism
  - Life
---

[[+Quotes MOC]]

# Martin Luther King, Jr

quote:: "The evils of capitalism are as real as the evils of militarism and racism. The problems of racial injustice and economic injustice cannot be solved without a radical redistribution of political and economic power".

quote:: "The quality, not the longevity, of one's life is what is important."

quote:: I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin, but by the content of their character
