---
attribution:
  - Martin Luther King, Jr.
source: 
tags:
  - quote
topics:
  - capitalism
  - life
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Martin Luther King, Jr.
aliases: ["Martin Luther King, Jr"]
linter-yaml-title-alias: "Martin Luther King, Jr"
---

# Martin Luther King, Jr

"The evils of capitalism are as real as the evils of militarism and racism. The problems of racial injustice and economic injustice cannot be solved without a radical redistribution of political and economic power".

# Martin Luther King, Jr

Martin Luther King, Jr.

"The quality, not the longevity, of one's life is what is important."
