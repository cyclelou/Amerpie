---
title: Martin Luther
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-27
attribution: ""
Author: 
fileClass: Quotes
source: ""
topics: ""
---

# Martin Luther

[[+Quotes MOC|Quotes]]

Peace if possible, truth at all costs.

We are all mere beggars telling other beggars where to find bread.
