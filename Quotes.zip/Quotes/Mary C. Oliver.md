---
title: Mary C. Oliver
source: 
topics:
  - Life
tags:
  - quote
fileClass: Quotes
attribution: 
creation date: 2024-01-31
modification date: 2024-01-31
---

# Mary C. Oliver

Tell me, what is it you plan to do with your one wild and precious life.
