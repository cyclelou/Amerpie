---
title: Mary C. Oliver
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
source: ""
topics:
  - Life
---

# Mary C. Oliver

Tell me, what is it you plan to do with your one wild and precious life.
