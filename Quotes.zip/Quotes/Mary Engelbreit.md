---
attribution:
  - Mary Engelbreit
source: 
tags:
  - quote
topics:
  - courage
creation date: 2024-01-17
modification date: 2024-01-31
fileClass:
  - Quotes
title: Mary Engelbreit
---

# Mary Engelbreit

"I will not stay silent so that you can stay comfortable."

Mary Engelbreit
