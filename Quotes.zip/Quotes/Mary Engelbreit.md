---
title: Mary Engelbreit
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-13
attribution:
  - Mary Engelbreit
fileClass:
  - Quotes
source: ""
topics:
  - Courage
---

# Mary Engelbreit

"I will not stay silent so that you can stay comfortable."

Mary Engelbreit
