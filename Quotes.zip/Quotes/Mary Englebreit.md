---
quote: I will not stay silent so you can stay comfortable.
source: 
topics:
  - Philosophy,Racism
tags:
  - quote
fileClass: Quotes
title: Mary Englebreit
creation date: 2024-01-31
modification date: 2024-01-31
---

# Mary Englebreit
