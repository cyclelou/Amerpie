---
title: Mary Englebreit
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - ""
fileClass:
  - Quotes
quote: I will not stay silent so you can stay comfortable.
source: ""
topics:
  - Philosophy
  - Racism
---

# Mary Englebreit
