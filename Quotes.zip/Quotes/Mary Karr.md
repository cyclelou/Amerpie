---
title: Mary Karr
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Propaganda seeks to destroy art in order to sanitize culture.
source:
  - The Art of Memoir
 
topics:
  - Culture
---

# Mary Karr
