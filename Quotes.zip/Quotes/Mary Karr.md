---
quote: Propaganda seeks to destroy art in order to sanitize culture.
source: The Art of Memoir
topics:
  - Culture
tags:
  - quote
fileClass: Quotes
title: Mary Karr
creation date: 2024-01-31
modification date: 2024-01-31
---

# Mary Karr
