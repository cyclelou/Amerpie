---
title: Mary Oliver
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Mary Oliver

[[+Quotes MOC|Quotes]]

Instructions for living a life. Pay attention. Be astonished. Tell about it.
