---
title: Matt Gemmell
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: If you don’t harbour a deep-seated, conflicted, fundamental resentment for tech, well… you’re probably not a very dedicated geek.
source:
  - His Blog
 
topics:
  - Technology
---

# Matt Gemmell
