---
quote: If you don’t harbour a deep-seated, conflicted, fundamental resentment for tech, well… you’re probably not a very dedicated geek.
source: His Blog
topics:
  - Technology
tags:
  - quote
fileClass: Quotes
title: Matt Gemmell
creation date: 2024-01-31
modification date: 2024-01-31
---

# Matt Gemmell
