---
title: Matt Walsch
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Matt Walsch

[[+Quotes MOC|Quotes]]

Christians in the Middle East would literally rather die than identify, even in words, as a Muslim. You do so just because it's trendy.
