---
title: Matthew B. Crawford
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Matthew B. Crawford

[[+Quotes MOC|Quotes]]

The media have become masters at packaging stimuli in ways that our brains find irresistible, just as food engineers have become expert in creating "hyperpalatable" foods by manipulating levels of sugar, fat, and salt. Distractability might be regarded as the mental equivalent of obesity.  
(The World Beyond Your Head)

You have to learn to unlock your eyes as quickly as possible from every hazard, and instead look where you want to go.  
(The World Beyond Your Head)

Cheap men need expensive jigs; expensive men need only the tools in their toolbox.  
(The World Beyond Your Head)
