---
title: Matthew Kelly
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-13
attribution:
  - ""
fileClass: Quotes
source: ""
topics: []
---

# Matthew Kelly

[[+Quotes MOC|Quotes]]

Our lives change when our habits change.

The measure of your life will be the measure of your courage. ^courage

It is of disturbing importance to note that the present culture has virtually no interest in pursuing this question. We seem more interested in how we want to live than we are in discovering the best way to live. Likewise, we are much more interested in developing self-expression than we are in developing selves that are worth expressing. (Off Balance)
