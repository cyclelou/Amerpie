---
title: Maureen Dowd
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-09
attribution:
  - Maureen Dowd
 
fileClass:
  - Quotes
source: ""
topics:
  - Politics
  - Trump
---

# Maureen Dowd

He needs the adoration of the mob more than he needs the acceptance of normal people.''

Maureen Dowd
