---
attribution:
  - Maureen Dowd
source: 
tags:
  - quote
topics:
  - Politics
  - Trump
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Maureen Dowd
---

# Maureen Dowd

He needs the adoration of the mob more than he needs the acceptance of normal people.''

Maureen Dowd
