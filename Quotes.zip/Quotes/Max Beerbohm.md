---
title: Max Beerbohm
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Max Beerbohm

[[+Quotes MOC|Quotes]]

Only mediocrity can be trusted to be always at its best. Genius must always have lapses proportionate to its triumphs.
