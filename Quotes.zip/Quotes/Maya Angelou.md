---
title: Maya Angelou
attribution:
  - Maya Angelou
source: 
tags:
  - quote
topics:
  - Love
fileClass: Quotes
creation date: 2024-01-31
modification date: 2024-01-31
---

# Maya Angelou

If you find it in your heart to care for somebody else, you will have succeeded.
