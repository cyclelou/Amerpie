---
title: Maya Angelou
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution:
  - Maya Angelou
 
fileClass:
  - Quotes
source: ""
topics:
  - Love
---

# Maya Angelou

If you find it in your heart to care for somebody else, you will have succeeded.

# Maya Angelou

[[+Quotes MOC|Quotes]]

Nothing will work unless you do.
