---
title: Meme Quote
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Meme Quote

[[+Quotes MOC|Quotes]]

I'm right 97% of the time. Who cares about the other 4%?  
— A Guy's Shirt
