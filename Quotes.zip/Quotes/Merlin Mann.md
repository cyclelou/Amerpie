---
title: Merlin Mann
url: 
tags:
  - Quote
creation date: 2024-01-12
modification date: 2024-02-26
attribution: Merlin Mann
Author: 
fileClass:
  - Quotes
source: Github
topics:
  - Language
  - Manners
  - Diet
  - Tradition
  - Sleep
  - Goals
  - Empathy
  - Obligation
---

# Merlin Mann

> [!A cool quote on Language]  
> quote:: There are no "bad words." Apart from "moist, "succulent," and "craveable."

Except: Always hold the door.

> [!A Cool quote on diet]  
.Merlin Mann  
quote:: Avoid vegetarian dishes that aspire to approximate a recipe that's typically based on meat.

quote:: While it's weird to *invent* a tradition, start noticing the things that have made you happy when (or because) they've happened more than once. Then, consider acknowledging those things as a tradition.

quote:: Related: you definitely need more sleep.

quote:: Stay focused on the outcome, not your original strategy. Viz.: if you're looking for *a* USB cable, don't fixate on finding a *specific* box that might contain a *specific* USB cable. Just find *a* goddamned cable.

quote:: Flirt with all elderly women.

quote:: Tip more.

quote:: "Experience" is rarely the verb you're looking for. Reword your sentence with a more clear and muscular focus on what actually happened—and who or what caused it to happen. So, maybe don't say "I am experiencing technical difficulties" if you really mean "I broke the internet." You're not fooling anyone.

quote:: If you have a small household responsibility—no matter how lame or quotidian—just do it now and without being asked. If you think the trash may need to go out, do not "check" to see if the trash needs to go out. Just take out the fucking trash. And quit reminding everybody you took the trash out. This is not Vietnam, and you are not a forgotten hero.

quote:: Always make ***all*** the bacon.

quote:: Just because you know something doesn't mean everybody knows it. Every day, somebody's born who's never seen *The Flintstones*.

quote:: If you can afford the dinner, you can afford the tip.
