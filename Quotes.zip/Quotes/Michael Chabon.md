---
title: Michael Chabon
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Michael Chabon

[[+Quotes MOC|Quotes]]

He's very stubborn. I've never known a genius who was not.  
(Amazing Adventures of Kabalier and Clay)

Nothing is boring, except to those who aren't really paying attention.  
(Summerland)
