---
title: Michael Crichton
url: 
tags:
  - Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
updated: 2024-01-20T13:50:19-06:00
---

# Michael Crichton

[[+Quotes MOC|Quotes]]

Consensus is the business of politics. Science, on the contrary, requires only one investigator who happens to be right, which means that he or she has results that are verifiable by reference to the real world. In science consensus is irrelevant. The greatest scientists in history are great precisely because they broke with consensus. There is no such thing as consensus science. If it's consensus, it isn't science. If it's science, it isn't consensus. Period. ^consensus

Historically, the claim of consensus has been the first refuge of scoundrels; it is a way to avoid debate by claiming that the matter is already settled.

Whenever you hear the consensus of scientists agrees on something or other, reach for your wallet, because you're being had. ^wallet

## Books I've Read

```dataview
list from [[]] and #bookreview 
```
