---
title: Michael Knowles
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Michael Knowles

[[+Quotes MOC|Quotes]]

I can define my existence as a 6'4" 200lb linebacker, but if I step on the football field it won't go very well for me. ^truth
