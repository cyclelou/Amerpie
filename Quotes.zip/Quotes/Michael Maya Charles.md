---
title: Michael Maya Charles
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Michael Maya Charles

[[+Quotes MOC|Quotes]]

The more I fly, the less I know—and the more questions I have. May we never be so sure that we don't have any questions.  
(Artful Flying)

Knowledge is the barrier to all learning.  
(Artful Flying)
