---
title: Michelangelo
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Michelangelo

[[+Quotes MOC|Quotes]]

It is not a schoolboy exercise, except to a schoolboy mind.  
(The Agony and the Ecstasy)
