---
title: Mike Monteiro
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Mike Monteiro

[[+Quotes MOC|Quotes]]

Confidence isn't about making you feel better. It's about reassuring your client that they hired the right person.
