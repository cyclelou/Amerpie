---
quote: Everyone has a plan until they get punched in the mouth
source: 
topics: Philosophy
tags: quote
fileClass: Quotes
title: Mike Tyson
creation date: 2024-01-31
modification date: 2024-01-31
---

# Mike Tyson
