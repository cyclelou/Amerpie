---
title: Mike Tyson
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Everyone has a plan until they get punched in the mouth
source: ""
topics:
  - Philosophy
---

# Mike Tyson

# Mike Tyson

[[+Quotes MOC|Quotes]]

Everybody has a plan until they get punched in the face.
