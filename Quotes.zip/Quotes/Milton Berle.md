---
title: Milton Berle
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Milton Berle

[[+Quotes MOC|Quotes]]

If opportunity doesn't knock, build a door.
