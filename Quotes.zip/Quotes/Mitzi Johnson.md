---
quote: Blacks marching to call attention to centuries of systemic oppression, violence, and injustice is in no way analgous to white supremacists aligning themselves with Nazis and asserting that anyone who doesn't look like them is unfit to be Americans or to live in this nation. There is a huge difference between saying "We matter." And saying, "You don't matter.
source: Letter
tags: quote
fileClass: Quotes
title: Mitzi Johnson
creation date: 2024-01-31
modification date: 2024-01-31
---
