---
title: Mohandas Gandhi
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: Satisfaction lies in the effort, not in the attainment. Full effort is full victory.
source: ""
topics:
  - Satisfaction
  - Victory
---
