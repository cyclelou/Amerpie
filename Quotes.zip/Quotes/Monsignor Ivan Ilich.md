---
quote: To hell with the future.  It is a man-eating idol.
source: 
topics: Future
tags: quote
fileClass: Quotes
title: Monsignor Ivan Ilich
creation date: 2024-01-31
modification date: 2024-01-31
---
