---
title: Moses
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Moses

[[+Quotes MOC|Quotes]]

The Lord will fight for you; you need only to be still.  
(Ex. 14:14)
