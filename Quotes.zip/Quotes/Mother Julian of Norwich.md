---
title: Mother Julian of Norwich
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Mother Julian of Norwich

[[+Quotes MOC|Quotes]]

God in your goodness, give me yourself, for you are enough for me. I can ask nothing less, if I am truly to live to your glory. If I were to ask for less, I would always remain in need for in you alone do I have all that I need.

I shall never know complete rest and true happiness until all that I am is united with him; until I am so joined to him that nothing on earth can come between my God and me.
