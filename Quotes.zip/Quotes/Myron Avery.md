---
title: Myron Avery
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Remote for detachment, narrow for chosen company, winding for leisure, lonely for contemplation, it beckons not merely north and south but upward to the body, mind and soul of man.
source:
  - In the Maine Woods
 
topics:
  - Appalachian Trail
---
