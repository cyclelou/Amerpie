---
quote: Remote for detachment, narrow for chosen company, winding for leisure, lonely for contemplation, it beckons not merely north and south but upward to the body, mind and soul of man.
source: In the Maine Woods
topics: Appalachian Trail
tags: quote
fileClass: Quotes
title: Myron Avery
creation date: 2024-01-31
modification date: 2024-01-31
---
