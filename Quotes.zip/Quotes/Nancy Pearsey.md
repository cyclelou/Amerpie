---
title: Nancy Pearsey
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Nancy Pearsey

[[+Quotes MOC|Quotes]]

Young people whose faith is mostly emotional are likely to retain it only as long as it is making them happy. As soon as a difficult crisis comes along, it will evaporate.
