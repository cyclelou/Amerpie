---
title: Nancy Pelosi
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: Science is the answer to our prayers.
source: ""
topics:
  - Prayer
  - Science
---
