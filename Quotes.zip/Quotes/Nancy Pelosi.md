---
quote: Science is the answer to our prayers.
source: 
topics: Prayer,Science
tags: quote
fileClass: Quotes
title: Nancy Pelosi
creation date: 2024-01-31
modification date: 2024-01-31
---
