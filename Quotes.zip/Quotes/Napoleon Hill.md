---
title: Napoleon Hill
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Napoleon Hill

[[+Quotes MOC|Quotes]]

Knowledge is only potential power. It becomes power only when, and if, it is organized into definite plans of action.
