---
title: Naval
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Naval

[[+Quotes MOC|Quotes]]

The modern mind is overstimulated and the modern body is understimulated and overfed. Meditation, exercise, and fasting restore an ancient balance.

Fast, lift, sprint, stretch, and meditate. Build, sell, write, create, invest, and own. Read, reflect, love, seek truth, and ignore society. Make these habits. Say no to everything else. Avoid debt, jail, addiction, disgrace, shortcuts, and media. Relax. Victory is assured.
