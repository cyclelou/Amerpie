---
title: Ned Piemaker
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ned Piemaker

[[+Quotes MOC|Quotes]]

The problem with starting fresh is that something old might go stale.  
(Pushing Daisies)
