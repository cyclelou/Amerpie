---
title: Neil Barringham
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Neil Barringham

[[+Quotes MOC|Quotes]]

The grass is greener where you water it.
