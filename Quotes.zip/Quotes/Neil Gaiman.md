---
title: Neil Gaiman
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: “The biggest problem we run into is going, ‘This is who I am, this is what I’m like, this is how I function’ while failing to notice that you don’t do that anymore.”
source:
  - Interview
 
topics:
  - Self
---

# Neil Gaiman
