---
title: Nicolas Chamfort
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-09
attribution:
  - Nicolas Chamfort
 
fileClass:
  - Quotes
source: ""
topics:
  - Laughter
---

# Nicolas Chamfort

# Nicolas Chamfort

Nicolas Chamfort  
"The most wasted day of all is that on which we have not laughed."
