---
attribution:
  - Nicolas Chamfort
source: 
tags:
  - quote
topics:
  - laughter
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Nicolas Chamfort
---

# Nicolas Chamfort

# Nicolas Chamfort

Nicolas Chamfort  
"The most wasted day of all is that on which we have not laughed."
