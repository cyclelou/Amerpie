---
title: Niels Bohr
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Niels Bohr

[[+Quotes MOC|Quotes]]

The opposite of a true statement is a false statement, but the opposite of a profound truth may be another profound truth.
