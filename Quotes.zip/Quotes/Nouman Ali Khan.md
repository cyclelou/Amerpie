---
quote: When a tree bears fruits, the branches will hang lower. When you acquire knowledge, which is the fruit, it should make you humble...
source: 
topics: Knowledge
tags: quote
fileClass: Quotes
title: Nouman Ali Khan
creation date: 2024-01-31
modification date: 2024-01-31
---

# Nouman Ali Khan
