---
title: Nouman Ali Khan
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: When a tree bears fruits, the branches will hang lower. When you acquire knowledge, which is the fruit, it should make you humble...
source: ""
topics:
  - Knowledge
---

# Nouman Ali Khan
