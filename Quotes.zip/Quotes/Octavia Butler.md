---
title: Octavia Butler
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: “The only lasting truth is Change.”
source: ""
topics:
  - Change
---
