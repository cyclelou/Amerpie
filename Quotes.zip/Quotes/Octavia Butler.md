---
quote: “The only lasting truth is Change.”
source: 
topics: Change
tags: quote
fileClass: Quotes
title: Octavia Butler
creation date: 2024-01-31
modification date: 2024-01-31
---
