---
quote: Most of us go to our graves with our music still inside us, unplayed.
source: 
topics: Philosophy
tags: quote
fileClass: Quotes
title: Oliver Wendell Holmes
creation date: 2024-01-31
modification date: 2024-01-31
---
