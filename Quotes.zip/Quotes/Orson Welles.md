---
title: Orson Welles
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Orson Welles

[[+Quotes MOC|Quotes]]

If you want a happy ending, that depends, of course, on where you stop your story.
