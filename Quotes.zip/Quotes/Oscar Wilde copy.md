---
quote: Dinner is not a feast, it is a ceremony.
source: 
topics: Eating
tags: quote
fileClass: Quotes
title: Oscar Wilde copy
creation date: 2024-01-31
modification date: 2024-01-31
aliases: [Oscar Wilde Copy]
linter-yaml-title-alias: Oscar Wilde Copy
---

# Oscar Wilde Copy
