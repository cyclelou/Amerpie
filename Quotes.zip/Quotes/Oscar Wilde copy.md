---
title: Oscar Wilde copy
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
aliases: [Oscar Wilde Copy]
attribution: ""
fileClass:
  - Quotes
quote: Dinner is not a feast, it is a ceremony.
source: ""
topics:
  - Eating
---

# Oscar Wilde Copy
