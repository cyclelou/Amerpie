---
attribution:
  - Oscar Wilde
source: 
tags:
  - quote
topics:
  - desire
creation date: 2023-12-09
modification date: 2024-01-31
fileClass: Quotes
title: Oscar Wilde
---

# Oscar Wilde

"In this world there are only two tragedies. One is not getting what one wants, and the other is getting it."  
— Oscar Wilde
