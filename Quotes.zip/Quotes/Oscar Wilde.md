---
title: Oscar Wilde
url: 
tags:
  - Quote
creation date: 2023-12-09
modification date: 2024-02-09
attribution:
  - Oscar Wilde
 
fileClass:
  - Quotes
source: ""
topics:
  - Desire
---

# Oscar Wilde

"In this world there are only two tragedies. One is not getting what one wants, and the other is getting it."  
— Oscar Wilde

# Oscar Wilde

[[+Quotes MOC|Quotes]]

A man who does not think for himself does not think at all.

The advantage of the emotions is that they lead us astray, and the advantage of science is that it is not emotional. ^sc1

(Dorian Gray)

Experience is one thing you can't get for nothing.
