---
title: Pablo Picasso
url: 
tags:
  - quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - Pablo Picasso
fileClass: Quotes
source: 
topics:
  - Art
---

# Pablo Picasso

Everything you can imagine is real.

# Pablo Picasso

To know what you're going to draw, you have to begin drawing.
