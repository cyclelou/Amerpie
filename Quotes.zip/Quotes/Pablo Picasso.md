---
title: Pablo Picasso
url: 
tags:
  - Quote
creation date: 2024-02-07
modification date: 2024-02-09
attribution:
  - Pablo Picasso
 
fileClass:
  - Quotes
source: ""
topics:
  - Art
---

# Pablo Picasso

Everything you can imagine is real.

# Pablo Picasso

To know what you're going to draw, you have to begin drawing.

# Pablo Picasso

[[+Quotes MOC|Quotes]]

Art washes away from the soul the dust of everyday life.

Every child is born an artist. The trouble is how to stay one as you grow up.
