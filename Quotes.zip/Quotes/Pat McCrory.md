---
quote: Let’s put aside our differences, the political rhetoric and yes, hypocrisy, and work on solutions that will make this bill better in the future. And to the people and businesses of North Carolina, we are a state of openness and diversity.
source: 
topics: LGBT,North Carolina,Politics,Republicans
tags: quote
fileClass: Quotes
title: Pat McCrory
creation date: 2024-01-31
modification date: 2024-01-31
---
