---
title: Patrick Henry
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Patrick Henry

[[+Quotes MOC|Quotes]]

Adversity toughens manhood, and the characteristic of the good or the great man is not that he has been exempt from the evils of life, but that he has surmounted them.
