---
title: Patrick Jane
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Patrick Jane

[[+Quotes MOC|Quotes]]

A room full of people who prescribe drugs they know little about to cure diseases they know less about to cure people they know nothing about. And they call me a fraud!
