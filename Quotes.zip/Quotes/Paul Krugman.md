---
quote: Politics  determines who has the power, not who has the truth.
source: New York Times
topics: Politics
tags: quote
fileClass: Quotes
title: Paul Krugman
creation date: 2024-01-31
modification date: 2024-01-31
---
