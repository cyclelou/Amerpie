---
title: Paul Valery
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Paul Valery

[[+Quotes MOC|Quotes]]

Books have the same enemies as people: fire, humidity, animals, weather, and their own content.
