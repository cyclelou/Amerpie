---
title: Paul Vira
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: The invention of the ship was also the invention of the shipwreck.
source: ""
topics:
  - Philosophy
---
