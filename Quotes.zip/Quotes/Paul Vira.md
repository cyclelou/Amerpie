---
quote: The invention of the ship was also the invention of the shipwreck.
source: 
topics: Philosophy
tags: quote
fileClass: Quotes
title: Paul Vira
creation date: 2024-01-31
modification date: 2024-01-31
---
