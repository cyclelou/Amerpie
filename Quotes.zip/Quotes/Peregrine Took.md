---
title: Peregrine Took
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Peregrine Took

[[+Quotes MOC|Quotes]]

The closer we are to danger, the farther we are from harm. It's the last thing he'll expect.
