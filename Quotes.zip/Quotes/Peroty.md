---
attribution:
  - Peroty
source: micro.blog
tags:
  - quote
topics:
  - flying
creation date: 2023-12-25
modification date: 2024-01-31
fileClass: Quotes
title: Peroty
---

# Peroty

Airport Quote  
I agree with every crying child in the airport. This is terrible. Nobody wants to do this.  
peroty on micro.blog
