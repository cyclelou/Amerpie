---
title: Peroty
url: 
tags:
  - Quote
creation date: 2023-12-25
modification date: 2024-02-09
attribution:
  - Peroty
 
fileClass:
  - Quotes
source:
  - micro.blog
 
topics:
  - Flying
---

# Peroty

Airport Quote  
I agree with every crying child in the airport. This is terrible. Nobody wants to do this.  
peroty on micro.blog
