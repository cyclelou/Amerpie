---
title: Pete Brown
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-09
attribution:
  - Pete Brown
 
fileClass:
  - Quotes
source:
  - Exploding Comma
 
topics:
  - Technology
---

# Pete Brown

We build these crazy contraptions using fifty different sets of mismatched tools, connect them all together with chewing gum and twine, and then pile billions of bits of junk on top of them. Of course none of it is going to work properly. TBH most of the time I'm surprised any of it even works at all.

in Exploding Comma
