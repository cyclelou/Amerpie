---
attribution:
  - Pete Brown
source: Exploding Comma
tags:
  - quote
topics:
  - technology
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Pete Brown
---

# Pete Brown

We build these crazy contraptions using fifty different sets of mismatched tools, connect them all together with chewing gum and twine, and then pile billions of bits of junk on top of them. Of course none of it is going to work properly. TBH most of the time I'm surprised any of it even works at all.

in Exploding Comma
