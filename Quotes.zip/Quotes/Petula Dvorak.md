---
title: Petula Dvorak
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-09
attribution:
  - Petula Dvorak
 
fileClass:
  - Quotes
source: ""
topics:
  - Sacrifice
  - Patriotism
---

# Petula Dvorak

Buying the stars-and-stripes yard art and truck decals and listening to country music aren't what define being an American. Right now? Sacrificing is American.  
		By Petula Dvorak
