---
attribution:
  - Petula Dvorak
source: 
tags:
  - quote
topics:
  - sacrifice
  - patriotism
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Petula Dvorak
---

# Petula Dvorak

Buying the stars-and-stripes yard art and truck decals and listening to country music aren't what define being an American. Right now? Sacrificing is American.  
		By Petula Dvorak
