---
title: Phil Karlton
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Phil Karlton

[[+Quotes MOC|Quotes]]

There are only two hard things in computer science: cache invalidation and naming things.
