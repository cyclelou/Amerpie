---
title: Phillip Dick
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Phillip Dick

[[+Quotes MOC|Quotes]]

Reality is that which, when you stop believing in it, doesn't go away.
