---
quote: Reality is that which, when you stop believing in it, doesn't go away.
source: 
topics: Philosophy,Reality
tags: quote
fileClass: Quotes
title: Phillip K. Dick
creation date: 2024-01-31
modification date: 2024-01-31
---

# Phillip K. Dick
