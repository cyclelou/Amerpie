---
title: Phillip K. Dick
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - ""
fileClass:
  - Quotes
quote: Reality is that which, when you stop believing in it, doesn't go away.
source: ""
topics:
  - Philosophy
  - Reality
---

# Phillip K. Dick
