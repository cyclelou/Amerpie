---
title: Plato
url: 
tags:
  - quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - Plato
fileClass: Quotes
source: 
topics:
  - Courage
---

# Plato

"We can easily forgive a child who is afraid of the dark; the real tragedy of life is when men are afraid of the light"
