---
title: Plato
url: 
tags:
  - Quote
creation date: 2024-02-07
modification date: 2024-02-09
attribution:
  - Plato
 
fileClass:
  - Quotes
source: ""
topics:
  - Courage
---

# Plato

"We can easily forgive a child who is afraid of the dark; the real tragedy of life is when men are afraid of the light"

# Plato

[[+Quotes MOC|Quotes]]

Always be kind, for everyone is fighting a hard battle.
