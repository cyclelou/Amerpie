---
attribution:
  - Primo Levin
source: If This is a Man
tags:
  - quote
topics:
  - civilization
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Primo Levin
---

# Primo Levin

"A country is considered the more civilised the more the wisdom and efficiency of its laws hinder a weak man from becoming too weak and a powerful one too powerful."  
― Primo Levi in If This Is a Man
