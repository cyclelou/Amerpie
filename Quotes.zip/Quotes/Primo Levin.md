---
title: Primo Levin
url: 
tags:
  - Quote
creation date: 2023-12-20
modification date: 2024-02-13
attribution:
  - Primo Levin
fileClass: Quotes
source: If This is a Man
topics:
  - Civilization
---

# Primo Levin

quote:: "A country is considered the more civilised the more the wisdom and efficiency of its laws hinder a weak man from becoming too weak and a powerful one too powerful."  
