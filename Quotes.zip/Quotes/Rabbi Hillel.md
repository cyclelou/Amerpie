---
quote: That which is hateful to you, do not do to your neighbor. The rest is commentary.
source: 
topics:
  - Ethics
tags:
  - quote
fileClass: Quotes
title: Rabbi Hillel
creation date: 2024-01-31
modification date: 2024-01-31
---

# Rabbi Hillel
