---
title: Rabbi Jonathan Sacks
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Rabbi Jonathan Sacks

[[+Quotes MOC|Quotes]]

Moral relativism seems to be the most tolerant form of morality—you do what you want to do and I will do what I want to do. However, it actually leads to enormous intolerance because if there is no objective standard of morality, how am I to show I'm right? When that happens, it is the loudest, angriest, rudest voice that wins.
