---
quote: For one human being to love another human being: that is perhaps the most difficult task that has been entrusted to us, the ultimate task, the final test and proof, the work for which all other work is merely preparation.
—
source: Tim Ferris Newsletter
topics: Love,Philosophy
tags: quote
---
# Rainer Maria Rilke
