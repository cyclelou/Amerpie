---
title: Ralph Nader
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ralph Nader

[[+Quotes MOC|Quotes]]

Pessimism has no function. It's an indulgence of people who have little stamina to confront the challenges of modern life. And it's a good way to rationalize their withdrawal from … justice.
