---
quote: Every artist was first an amateur.
source: 
topics: Art
tags: quote
fileClass: Quotes
title: Ralph Waldo Emerson
creation date: 2024-01-31
modification date: 2024-01-31
---
