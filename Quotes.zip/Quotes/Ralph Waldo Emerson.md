---
title: Ralph Waldo Emerson
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Every artist was first an amateur.
source: ""
topics:
  - Art
---

# Ralph Waldo Emerson

[[+Quotes MOC|Quotes]]

Once you make a decision, the universe conspires to make it happen.

An ounce of action is worth a ton of theory.

What is a weed? A weed is a plant whose virtues have not yet been discovered.
