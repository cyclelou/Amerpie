---
title: Rand Paul
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: “America shouldn’t fight wars where the best outcome is stalemate,” Paul plans to say, according to excerpts provided by his office. “America shouldn’t fight wars when there is no plan for victory. America shouldn’t fight wars that aren’t authorized by the American people, by Congress. America should and will fight wars when the consequences — intended and unintended — are worth the sacrifice
source: AP
topics:
  - Politics
  - Republicans
---
