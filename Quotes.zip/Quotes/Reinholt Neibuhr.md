---
title: Reinholt Neibuhr
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Reinholt Neibuhr

[[+Quotes MOC|Quotes]]

God grant me the serenity to accept what I cannot change, the courage to change the things I can, and the wisdom to know the difference.
