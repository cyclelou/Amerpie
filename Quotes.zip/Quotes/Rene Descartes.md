---
quote: To know what people really think, pay attention to what they do, rather than what they say.
source: French
topics: Knowledge,Philosophy
tags: quote
fileClass: Quotes
title: Rene Descartes
creation date: 2024-01-31
modification date: 2024-01-31
---
