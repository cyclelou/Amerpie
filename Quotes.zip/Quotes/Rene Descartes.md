---
title: Rene Descartes
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - ""
fileClass:
  - Quotes
quote: To know what people really think, pay attention to what they do, rather than what they say.
source:
  - French
topics:
  - Knowledge
  - Philosophy
---

# Rene Descartes
