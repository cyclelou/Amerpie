---
title: Rene Girard
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Rene Girard

[[+Quotes MOC|Quotes]]

If you scapegoat someone, it's a third party that will be aware of it. It won't be you, because you will believe you are doing the right thing. You will be either punishing someone who is guilty, or fighting someone who is trying to kill you, but you are never the one who is scapegoating. ^scapegoating
