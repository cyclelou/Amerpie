---
quote: What I cannot create, I do not understand.
source: 
topics: Knowledge
tags: quote
fileClass: Quotes
title: Richard Feynman
creation date: 2024-01-31
modification date: 2024-01-31
---
