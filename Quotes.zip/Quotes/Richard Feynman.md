---
title: Richard Feynman
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
date: 2023-06-16T08:53
fileClass:
  - Quotes
quote: What I cannot create, I do not understand.
source: ""
topics:
  - Knowledge
 
updated: 2023-09-15T10:40
---

# Richard Feynman

[[+Quotes MOC|Quotes]]

Science is the belief in the ignorance of experts. When someone says "science teaches such and such", he is using the word incorrectly.

Don't fool yourself (and you're the easiest one to fool)
