---
quote: A man who gives his children habits of industry provides for them better than by giving them fortune.
source: 
topics: Children,Parenting
tags: quote
fileClass: Quotes
title: Richard Whately
creation date: 2024-01-31
modification date: 2024-01-31
---
