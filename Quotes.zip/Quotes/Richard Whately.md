---
title: Richard Whately
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Richard Whately
fileClass: Quotes
source: ""
topics:
  - Children
  - Parenting
---

[[+Quotes MOC]]

# Richard Whately

quote:: A man who gives his children habits of industry provides for them better than by giving them fortune.
