---
title: Richard Wright
attribution:
  - Richard Wright
source: 
tags:
  - quote
topics:
  - self realization
creation date: 2024-01-28
modification date: 2024-01-31
fileClass: Quotes
---

# Richard Wright

Richard Wright  
"Men can starve from a lack of self-realization as much as they can from a lack of bread."
