---
title: Richard Wright
url: 
tags:
  - Quote
creation date: 2024-01-28
modification date: 2024-02-09
attribution:
  - Richard Wright
 
fileClass:
  - Quotes
source: ""
topics:
  - Self Realization
---

# Richard Wright

Richard Wright  
"Men can starve from a lack of self-realization as much as they can from a lack of bread."
