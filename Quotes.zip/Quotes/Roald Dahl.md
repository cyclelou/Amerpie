---
title: Roald Dahl
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Roald Dahl

[[+Quotes MOC|Quotes]]

If you have good thoughts they will shine out of your face like sunbeams and you will always look lovely.
