---
title: Rob McCoy 1
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Rob McCoy 1

[[+Quotes MOC|Quotes]]

Pastors by nature are peacemakers. But they don't understand that peace isn't the absence of conflict, it's the presence of God in the midst of conflict. (Fireside 188)
