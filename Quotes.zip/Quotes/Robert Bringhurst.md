---
title: Robert Bringhurst
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Robert Bringhurst

[[+Quotes MOC|Quotes]]

Good typography is like bread: ready to be admired, appraised and dissected before it is consumed.

In a world rife with unsolicited messages, typography must often draw attention to itself before it will be read. Yet in order to be read, it must relinquish the attention it has drawn.
