---
quote: When people look at my pictures I want them to feel the way they do when they want to read a line of a poem twice.
source: 
topics: Art,Photography
tags: quote
fileClass: Quotes
title: Robert Frank
creation date: 2024-01-31
modification date: 2024-01-31
---

# Robert Frank
