---
title: Robert Frank
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Robert Frank
fileClass: Quotes
quote: 
source: ""
topics:
  - Art
  - Photography
---

# Robert Frank

quote:: When people look at my pictures I want them to feel the way they do when they want to read a line of a poem twice.
