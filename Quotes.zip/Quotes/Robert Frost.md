---
title: Robert Frost
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Robert Frost

[[+Quotes MOC|Quotes]]

You have freedom when you're easy in your harness.
