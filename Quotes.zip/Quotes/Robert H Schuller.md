---
title: Robert H Schuller
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Robert H Schuller

[[+Quotes MOC|Quotes]]

I'd rather attempt to do something great and fail than to attempt to do nothing and succeed.
