---
title: Robert Louis Stevenson
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Robert Louis Stevenson

[[+Quotes MOC|Quotes]]

Don't judge each day by the harvest you reap but by the seeds that you plant.
