---
quote: The trail’s radical origins began to manifest themselves in unforeseen ways in the decades that followed, most notably in the community of hikers who, in ever-increasing waves since the end of the Second World War, undertook pilgrimages from one end to the other in search of their own answers to the problem of living.
source: "On Trails: An Exploration" by  http://a.co/9cJo4jg
topics: Appalachian Trail
tags: quote
---
