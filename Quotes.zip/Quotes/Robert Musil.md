---
title: Robert Musil
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: “Today I start a diary; it is against my usual habits, but out of a clearly felt need.”
source: ""
topics:
  - Self
---
