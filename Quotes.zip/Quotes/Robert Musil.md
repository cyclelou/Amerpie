---
quote: “Today I start a diary; it is against my usual habits, but out of a clearly felt need.”
source: 
topics: Self
tags: quote
fileClass: Quotes
title: Robert Musil
creation date: 2024-01-31
modification date: 2024-01-31
---
