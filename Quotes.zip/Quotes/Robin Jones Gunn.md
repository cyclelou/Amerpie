---
quote: If you want to go fast, go alone. If you want to go far, go together.
source: 
topics: Teamwork
tags: quote
fileClass: Quotes
title: Robin Jones Gunn
creation date: 2024-01-31
modification date: 2024-01-31
---
