---
title: Robin Roberts
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Robin Roberts

[[+Quotes MOC|Quotes]]

Be patient and persistent. Life is not so much what you accomplish as what you overcome.
