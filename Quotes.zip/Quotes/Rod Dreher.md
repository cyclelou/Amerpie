---
title: Rod Dreher
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Rod Dreher

[[+Quotes MOC|Quotes]]

The ordinary man may not be able to overturn the kingdom of lies, but he can at least say that he is not going to be its loyal subject.
