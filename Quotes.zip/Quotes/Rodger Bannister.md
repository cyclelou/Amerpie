---
title: Rodger Bannister
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Rodger Bannister

[[+Quotes MOC|Quotes]]

The man who can drive himself further once the effort gets painful is the man who will win.
