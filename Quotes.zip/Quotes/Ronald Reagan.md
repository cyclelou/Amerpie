---
title: Ronald Reagan
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ronald Reagan

[[+Quotes MOC|Quotes]]

I've noticed that everyone who is for abortion has already been born.

Freedom is never more than one generation away from extinction. We didn't pass it to our children in the bloodstream. It must be fought for, protected, and handed on for them to do the same, or one day we will spend our sunset years telling our children and our children's children what it was once like in the United States where men were free. ^freedom

Politics is not a bad profession. If you succeed there are many rewards, if you disgrace yourself you can always write a book.

Government's view of the economy could be summed up in a few short phrases: If it moves, tax it. If it keeps moving, regulate it. And if it stops moving, subsidize it.

The trouble with our liberal friends is not that they're ignorant: it's just that they know so much that isn't so.
