---
quote: Joy has nothing to do with ease and everything to do with the fact that we’re all going to die.
source: 
topics: Buddhism,Death,Joy
tags: quote
fileClass: Quotes
title: Ross Gay
creation date: 2024-01-31
modification date: 2024-01-31
---
