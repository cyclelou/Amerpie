---
title: Ross Gay
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Ross Gay
fileClass:
  - Quotes
source: ""
topics:
  - Buddhism
  - Death
  - Joy
---

[[+Quotes MOC]]

# Ross Gay

quote:: Joy has nothing to do with ease and everything to do with the fact that we're all going to die.
