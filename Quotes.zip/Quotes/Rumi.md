---
quote: “A thousand half-loves must be forsaken to take one whole heart home.”
source: 
topics: Love,Philosophy
tags: quote
fileClass: Quotes
title: Rumi
creation date: 2024-01-31
modification date: 2024-01-31
---
