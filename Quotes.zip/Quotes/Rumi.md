---
title: Rumi
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - ""
fileClass:
  - Quotes
quote: “A thousand half-loves must be forsaken to take one whole heart home.”
source: ""
topics:
  - Love
  - Philosophy
---

# Rumi
