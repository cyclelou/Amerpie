---
title: Ruth Bader Ginsburg
url: 
tags:
  - Quote
creation date: 2024-02-07
modification date: 2024-02-09
attribution:
  - Ruth Bader Ginsburg
 
fileClass:
  - Quotes
source:
  - Hobby Lobby Dissent
 
topics:
  - Perseverance
  - Religion
---

# Ruth Bader Ginsburg

 "Fight for the things that you care about, but do it in a way that will lead others to join you."

# Ruth Bader Ginsburg

Would the exemption the Court holds RFRA demands for employers with religiously grounded objections to the use of certain contraceptives extend to employers with religiously grounded objections to blood transfusions (Jehovah's Witnesses); antidepressants (Scientologists); medications derived from pigs, including anesthesia, intravenous fluids, and pills coated with gelatin (certain Muslims, Jews, and Hindus); and vaccinations (Christian Scientists, among others)?
