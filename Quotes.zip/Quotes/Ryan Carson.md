---
title: Ryan Carson
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ryan Carson

[[+Quotes MOC|Quotes]]

You're rich enough to own a computer. You're smart enough to understand HTML. You're lucky enough to be in your prime at this moment in history. If anyone has the opportunity to kick some serious ass and change the world, it's you.
