---
title: SCOTT ERIC KAUFMAN
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: Someone on Louisiana Governor Bobby Jindal’s campaign staff had the brilliant idea of opening up a discussion between the Republican hopeful and Twitter. The result was a terrible idea, poorly executed.
source: Salon
topics:
  - Politics
  - Republicans
---

# SCOTT ERIC KAUFMAN
