---
title: Saeed Abedini
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Saeed Abedini

[[+Quotes MOC|Quotes]]

When I think that all of these trials and persecutions are being recorded in heaven for me, my heart is filled with complete joy.
