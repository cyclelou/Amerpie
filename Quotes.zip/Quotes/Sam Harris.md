---
quote: Your mind is the basis of everything you experience and of every contribution you make to the lives of others. Given this fact, it makes sense to train it.
source: 
topics: Meditation
tags: quote
fileClass: Quotes
title: Sam Harris
creation date: 2024-01-31
modification date: 2024-01-31
---
