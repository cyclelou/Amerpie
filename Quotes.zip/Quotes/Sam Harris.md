---
title: Sam Harris
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Your mind is the basis of everything you experience and of every contribution you make to the lives of others. Given this fact, it makes sense to train it.
source: ""
topics:
  - Meditation
---
