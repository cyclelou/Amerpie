---
title: Sam Keen
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Sam Keen

[[+Quotes MOC|Quotes]]

There are two questions a man must ask himself: The first is 'Where am I going?' and the second is 'Who will go with me?' If you ever get these questions in the wrong order you are in trouble.
