---
title: Samuel Johnson
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Samuel Johnson

[[+Quotes MOC|Quotes]]

Nothing will ever be attempted if all possible objections must first be overcome.

The true art of memory is the art of attention.
