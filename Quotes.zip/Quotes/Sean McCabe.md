---
title: Sean McCabe
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
date: 2023-08-24T08:53
fileClass: Quotes
source: ""
topics: ""
updated: 2023-08-24T10:47
---

# Sean McCabe

[[+Quotes MOC|Quotes]]

Comparison is the thief of joy. ^joy
