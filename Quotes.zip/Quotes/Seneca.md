---
quote: We suffer more in imagination than in reality.
source: 
topics: Philosophy,Suffering
tags: quote
fileClass: Quotes
title: Seneca
creation date: 2024-01-31
modification date: 2024-01-31
---
