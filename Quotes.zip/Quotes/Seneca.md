---
title: Seneca
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Seneca
fileClass:
  - Quotes
source: 
topics:
  - Philosophy
  - Suffering
---

# Seneca

[[+Quotes MOC|Quotes]]

quote:: A good person dyes events with his own color… And turns whatever happens to his own benefit.

quote:: We suffer more in imagination than in reality.
