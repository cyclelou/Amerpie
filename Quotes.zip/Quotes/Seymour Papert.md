---
title: Seymour Papert
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Seymour Papert

[[+Quotes MOC|Quotes]]

One learns that the most powerful idea of all is the idea of powerful ideas.

You can't think seriously about thinking without thinking about thinking about something.

I see the classroom as an artificial and inefficient learning environment… I believe that the computer presence will enable us to so modify the learning environment outside the classrooms that much (if not all) knowledge… will be learned as the child learns to talk, painlessly, successfully, and without organized instruction.
