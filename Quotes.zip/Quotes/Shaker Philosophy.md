---
title: Shaker Philosophy
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Shaker Philosophy

[[+Quotes MOC|Quotes]]

Don't make something unless it is both necessary and useful; but if it is both necessary and useful, don't hesitate to make it beautiful.
