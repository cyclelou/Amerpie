---
title: Shawn
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Shawn

[[+Quotes MOC|Quotes]]

Just 'cause you put syrup on somethin' don't make it a pancake.  
(Psych)
