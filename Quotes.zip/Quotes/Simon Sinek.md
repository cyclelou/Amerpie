---
title: Simon Sinek
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Simon Sinek

[[+Quotes MOC|Quotes]]

There is no decision that we can make that doesn't come with some sort of balance or sacrifice.
