---
title: Sir Winston Churchill
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Sir Winston Churchill

[[+Quotes MOC|Quotes]]

The power of the Executive to cast a man into prison without formulating any charge known to the law, and particularly to deny him the judgment of his peers, is in the highest degree odious and is the foundation of all totalitarian government whether Nazi or Communist.
