---
quote: “No man has the right to be an amateur in the matter of physical training. It is a shame for a man to go through life without finding the true strength they are capable of.”
source: 
topics: Exercise,Self improvement,Strength
tags: quote
fileClass: Quotes
title: Socrates
creation date: 2024-01-31
modification date: 2024-01-31
---
