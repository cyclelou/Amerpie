---
quote: The mystery of life is not a problem to be solved, but a reality to be experienced
source: 
topics: Reality
tags: quote
fileClass: Quotes
title: Soren Kierkegaard
creation date: 2024-01-31
modification date: 2024-01-31
---
