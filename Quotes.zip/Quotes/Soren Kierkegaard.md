---
title: Soren Kierkegaard
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: The mystery of life is not a problem to be solved, but a reality to be experienced
source: ""
topics:
  - Reality
---
