---
title: Spencer Klavan
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Spencer Klavan

[[+Quotes MOC|Quotes]]

It is a bit of ancient wisdom that every society will produce more of what it honors publicly.
