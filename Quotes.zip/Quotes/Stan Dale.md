---
title: Stan Dale
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Stan Dale

[[+Quotes MOC|Quotes]]

Comfort zones are plush lined coffins. When you stay in your plush lined coffins, you die.
