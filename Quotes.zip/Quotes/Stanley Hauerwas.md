---
quote: To be poor does not mean you lack the means to extend charity to another. You may lack money or food, but you have the gift of friendship to overwhelm the loneliness that grips the lives of so many.
source: 
topics: Friendship
tags: quote
fileClass: Quotes
title: Stanley Hauerwas
creation date: 2024-01-31
modification date: 2024-01-31
---
