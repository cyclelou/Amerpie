---
title: Stephen Covey
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Stephen Covey

[[+Quotes MOC|Quotes]]

You have to decide what your highest priorities are and have the courage - pleasantly, smilingly, unnapologetically - to say 'no' to other things. And the way to do that is by having a bigger 'yes' burning inside.
