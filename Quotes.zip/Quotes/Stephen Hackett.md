---
quote: Seriously. LOL at Apple fans who are changing pharmacies because they can’t use week-old technology the way they want.
source: Twitter
topics: Apple
tags: quote
fileClass: Quotes
title: Stephen Hackett
creation date: 2024-01-31
modification date: 2024-01-31
---
