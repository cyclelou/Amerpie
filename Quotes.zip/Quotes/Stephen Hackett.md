---
title: Stephen Hackett
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Seriously. LOL at Apple fans who are changing pharmacies because they can’t use week-old technology the way they want.
source:
  - Twitter
 
topics:
  - Apple
---
