---
title: Stephen King
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Stephen King

[[+Quotes MOC|Quotes]]

Talent is cheaper than table salt. What separates the talented individual from the successful one is a lot of hard work.
