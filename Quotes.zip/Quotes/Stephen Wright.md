---
title: Stephen Wright
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Anywhere is within walking distance, if you've got the time
source: ""
topics:
  - Comedy
---
