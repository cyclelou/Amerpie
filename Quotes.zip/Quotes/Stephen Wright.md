---
quote: Anywhere is within walking distance, if you've got the time
source: 
topics: Comedy
tags: quote
fileClass: Quotes
title: Stephen Wright
creation date: 2024-01-31
modification date: 2024-01-31
---
