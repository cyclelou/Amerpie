---
title: Steve Krug
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Steve Krug

[[+Quotes MOC|Quotes]]

Experts are rarely insulted by something clear enough for beginners. Everybody appreciates clarity.

Sometimes time spent reinventing the wheel results in a revolutionary new rolling device. But sometimes it just amounts to time spent reinventing the wheel.
