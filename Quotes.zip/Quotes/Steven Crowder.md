---
title: Steven Crowder
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Steven Crowder

[[+Quotes MOC|Quotes]]

Typically liberals have more mental health disorders, they tend to be more motivated by fear, and the things that they fear are insecurity, versus a lack of freedom, a lack of liberty.
