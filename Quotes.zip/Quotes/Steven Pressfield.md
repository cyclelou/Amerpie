---
title: Steven Pressfield
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Steven Pressfield

[[+Quotes MOC|Quotes]]

The amateur, on the other hand, over identifies with his avocation, his artistic aspiration. Resistance loves this. Resistance knows that the amateur composer will never write his symphony because he is overly invested in its success and over terrified of its failure.
