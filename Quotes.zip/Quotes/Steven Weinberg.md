---
title: Steven Weinberg
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: With or without religion, you would have good people doing good things and evil people doing evil things. But for good people to do evil things, that takes religion.
source: ""
topics:
  - Religion
---
