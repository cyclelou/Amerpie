---
quote: With or without religion, you would have good people doing good things and evil people doing evil things. But for good people to do evil things, that takes religion.
source: 
topics: Religion
tags: quote
fileClass: Quotes
title: Steven Weinberg
creation date: 2024-01-31
modification date: 2024-01-31
---
