---
title: Steven Wright
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Steven Wright

[[+Quotes MOC|Quotes]]

If at first you don't succeed, destroy all evidence that you tried.

Half the people you know are below average.
