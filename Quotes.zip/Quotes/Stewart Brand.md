---
quote: On average, bad things happen fast and good things happen slow.
source: 
topics: Life
tags: quote
fileClass: Quotes
title: Stewart Brand
creation date: 2024-01-31
modification date: 2024-01-31
---
