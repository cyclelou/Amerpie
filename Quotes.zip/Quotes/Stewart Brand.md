---
title: Stewart Brand
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: On average, bad things happen fast and good things happen slow.
source: ""
topics:
  - Life
---
