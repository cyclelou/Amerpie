---
title: Sun Tzu
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Sun Tzu

[[+Quotes MOC|Quotes]]

Strategy without tactics is the slowest route to victory. Tactics without strategy is the noise before defeat.
