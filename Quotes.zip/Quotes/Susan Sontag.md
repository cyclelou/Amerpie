---
quote: There is an aggression implicit in every use of the camera. They manhandle time; they colonize experience; and they push us toward voyeurism, rather than participation. But there is also the democratization of the medium; we don’t all paint or sculpt, but we can all snap pictures.
source: 
topics: Photography
tags: quote
fileClass: Quotes
title: Susan Sontag
creation date: 2024-01-31
modification date: 2024-01-31
---
