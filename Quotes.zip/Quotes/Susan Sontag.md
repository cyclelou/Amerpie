---
title: Susan Sontag
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: There is an aggression implicit in every use of the camera. They manhandle time; they colonize experience; and they push us toward voyeurism, rather than participation. But there is also the democratization of the medium; we don’t all paint or sculpt, but we can all snap pictures.
source: ""
topics:
  - Photography
---
