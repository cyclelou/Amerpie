---
title: SusAnna Clarke
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# SusAnna Clarke

[[+Quotes MOC|Quotes]]

Since a smile is the most becoming ornament that any lady can wear, she had been known upon occasion to outshine women who were acknowledged beauties in three countries.
