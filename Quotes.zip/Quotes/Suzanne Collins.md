---
title: Suzanne Collins
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Suzanne Collins

[[+Quotes MOC|Quotes]]

Right now is the oldest you've ever been and the youngest you'll ever be. Ever again.
