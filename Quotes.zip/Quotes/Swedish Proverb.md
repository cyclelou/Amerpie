---
title: Swedish Proverb
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Swedish Proverb

[[+Quotes MOC|Quotes]]

Shared joy is double joy. Shared sorrow is half sorrow.
