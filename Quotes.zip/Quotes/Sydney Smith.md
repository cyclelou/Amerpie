---
title: Sydney Smith
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Sydney Smith

[[+Quotes MOC|Quotes]]

A great deal of talent is lost to the world for want of a little courage.
