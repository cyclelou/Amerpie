---
title: Ted Dekker
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Ted Dekker

[[+Quotes MOC|Quotes]]

Love comes naturally for humans. Stop making it difficult.
