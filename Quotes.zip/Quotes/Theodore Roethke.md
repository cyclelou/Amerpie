---
title: Theodore Roethke
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-13
attribution:
  - Theodore Roethke
fileClass: Quotes
source: ""
topics:
  - Philosophy
  - Seeing
  - Understanding
---

# Theodore Roethke

quote:: In a dark time, the eye begins to see.
