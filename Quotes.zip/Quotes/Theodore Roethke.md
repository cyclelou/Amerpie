---
quote: In a dark time, the eye begins to see.
source: 
topics: Philosophy,Seeing,Understanding
tags: quote
fileClass: Quotes
title: Theodore Roethke
creation date: 2024-01-31
modification date: 2024-01-31
---

# Theodore Roethke
