---
title: Thich Nhat Hanh
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: If you truly get in touch with a piece of carrot, you get in touch with the soil, the rain, the sunshine. You get in touch with Mother Earth and eating in such a way, you feel in touch with true life, your roots, and that is meditation. If we chew every morsel of our food in that way we become grateful and when you are grateful, you are happy.
source: ""
topics:
  - Meditation
  - Mindfulness
---
