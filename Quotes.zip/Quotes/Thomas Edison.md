---
title: Thomas Edison
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Thomas Edison

[[+Quotes MOC|Quotes]]

Many of life's failures are people who did not realize how close they were to success when they gave up.

There ain't no rules around here! We're trying to accomplish something!

If we all did the things we're capable of doing we would literally astound ourselves.  
(Dovel's Fridge)

The doctor of the future will give no medicine but will interest his patients in the care of the human frame, in diet and in the cause and prevention of disease. ^nutrition
