---
title: Thomas Hardy
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Thomas Hardy

[[+Quotes MOC|Quotes]]

Time changes everything except something within us which is always surprised by change.
