---
title: Thomas Jefferson
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Thomas Jefferson

[[+Quotes MOC|Quotes]]

If the people let the Government decide what foods they eat, and what medicines they take, their bodies will soon be in as sorry a state as are the souls of those who live under tyranny.

Nothing can stop the man with the right mental attitude from achieving his goal; nothing on earth can help the man with the wrong mental attitude.

I prefer dangerous freedom, to peaceful tyranny.
