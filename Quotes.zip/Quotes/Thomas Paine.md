---
title: Thomas Paine
url: 
tags:
  - Quote
creation date: 2024-01-17
modification date: 2024-02-09
attribution:
  - Thomas Paine
 
fileClass:
  - Quotes
source: ""
topics:
  - Simplicity
---

# Thomas Paine

 "The more simple anything is, the less liable it is to be disordered."

# Thomas Paine

[[+Quotes MOC|Quotes]]

The harder the conflict, the more glorious the triumph.

I love the man that can smile in trouble, that can gather strength from distress, and grow brave by reflection. 'Tis the business of little minds to shrink, but he whose heart is firm, and whose conscience approves his conduct, will pursue his principles unto death.
