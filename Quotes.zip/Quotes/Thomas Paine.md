---
attribution:
  - Thomas Paine
source: 
tags:
  - quote
topics:
  - simplicity
creation date: 2024-01-17
modification date: 2024-01-31
fileClass: Quotes
title: Thomas Paine
---

# Thomas Paine

 "The more simple anything is, the less liable it is to be disordered."
