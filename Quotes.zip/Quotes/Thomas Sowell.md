---
title: Thomas Sowell
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Thomas Sowell

[[+Quotes MOC|Quotes]]

Much of the social history of the Western world, over the past three decades, has been a history of replacing what worked with what sounded good.

It is hard to imagine a more stupid or dangerous way of making decisions than by putting those decisions in the hands of people who pay no price for being wrong. ^politics

There are no solutions. There are only trade-offs.
