---
title: Thomas Szasz
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Thomas Szasz

[[+Quotes MOC|Quotes]]

Clear thinking requires courage rather than intelligence.
