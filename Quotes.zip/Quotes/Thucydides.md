---
title: Thucydides
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Thucydides

[[+Quotes MOC|Quotes]]

The bravest are surely those who have the clearest vision of what is before them, glory and danger alike, and yet notwithstanding, go out and meet it.
