---
title: Tim Ferriss
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Tim Ferriss

[[+Quotes MOC|Quotes]]

The opposite of love is indifference, the opposite of happiness is boredom. ^boredom
