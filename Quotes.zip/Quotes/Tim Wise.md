---
title: Tim Wise
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-09
attribution: ""
fileClass:
  - Quotes
quote: Those who defend the flag consider the black experience irrelevant, a trifle, hardly worthy of their concern. Who cares if the flag represented a government that sought to consign them to permanent servitude? Who cares if segregationists used that flag as a blatant symbol of racist defiance during the civil rights movement?
source:
  - Alternet
 
topics:
  - Racism
---

# Tim Wise
