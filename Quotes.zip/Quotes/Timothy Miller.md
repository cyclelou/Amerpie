---
title: Timothy Miller
url: 
tags: Quote
creation date: 2024-02-09
modification date: 2024-02-09
attribution: ""
fileClass: Quotes
source: ""
topics: ""
---

# Timothy Miller

[[+Quotes MOC|Quotes]]

There's no point in playing a game that plays itself.

I read to live.

There's a funny thing about being smart. The more you know the more you realize how little you know.
