---
title: Toby Israel
url: 
tags:
  - Quote
creation date: 2024-01-31
modification date: 2024-02-19
attribution: ""
Author: 
fileClass:
  - Quotes
quote: To love a girl who wanders, realize that wanderlust is a true affliction.
source: Elephantjournal.com
topics:
  - Travel
  - Women
---
