---
quote: To love a girl who wanders, realize that wanderlust is a true affliction.
source: Elephantjournal.com
topics: Travel,Women
tags: quote
fileClass: Quotes
title: Toby Israel
creation date: 2024-01-31
modification date: 2024-01-31
---
