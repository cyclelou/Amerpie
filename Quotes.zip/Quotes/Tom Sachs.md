---
quote: The reward for good work is more work.
source: 
topics: Work
tags: quote
fileClass: Quotes
title: Tom Sachs
creation date: 2024-01-31
modification date: 2024-01-31
---
