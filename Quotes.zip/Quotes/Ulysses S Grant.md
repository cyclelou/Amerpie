---
attribution:
  - Ulysses S Grant
source: 
tags:
  - quote
topics:
  - war
  - civics
creation date: 2024-01-12
modification date: 2024-01-31
fileClass: Quotes
title: Ulysses S Grant
---

# Ulysses S Grant

Ulysses S Grant, 1875:

[Dave Mark: "Ulysses S Grant, 1875: "if we…" - social.lol](https://social.lol/deck/@davemark@mastodon.social/111743591001253777)

"If we are to have another contest in the near future of our national existence I predict that the dividing line will not be Mason & Dixon … but between patriotism & intelligence on the one side & superstition, ambition & ignorance on the other."
