---
attribution:
  - Unknown
source: 
tags: [quote]
topics:
  - Speech
  - Peace
  - Idiocy
  - Assertiveness
creation date: 2023-12-20
modification date: 2024-01-31
fileClass: Quotes
title: Unknown
quote:
---

# Unknown

"Peace is the only adequate war memorial.""

# Idiocy Quote

"Arguing with an idiot is like playing chess with a pigeon. It'll just knock over all the pieces, shit on the board, and strut about like it won anyway."

# Unknown

Man cannot do without beauty, and this is what our era pretends to want to disregard.

# Unknown

"No." is a complete sentence.
