---
quote: It is difficult to get a man to understand something, when his salary depends on his not understanding it.
source: https://signalvnoise.com
topics: Journalism,Philosophy
tags: quote
fileClass: Quotes
title: Upton Sinclair
creation date: 2024-01-31
modification date: 2024-01-31
---

# Upton Sinclair
