---
quote: Forgiveness is not forgetting. Forgiveness is freedom from hate.
source: 
topics: Forgiveness,Freedom
tags: quote
fileClass: Quotes
title: Valarie Kaur
creation date: 2024-01-31
modification date: 2024-01-31
---
