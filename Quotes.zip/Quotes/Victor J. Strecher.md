---
quote: Søren Kierkegaard wrote that “the thing is to find a truth which is true for me, to find the idea for which I can live and die.”
source: "Life on Purpose: How Living for What Matters Most Changes Everything" by  J. Strecher http://a.co/7RnoAko
topics: Self,Truth
tags: quote
---
