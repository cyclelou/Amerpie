---
quote: There are weeks when decades happen.
source: 
topics: History,Time
tags: quote
fileClass: Quotes
title: Vladimir Lenin
creation date: 2024-01-31
modification date: 2024-01-31
---
