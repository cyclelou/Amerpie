---
quote: The most courageous decision that you can make each day is to be in a good mood.
source: 
topics: Courage,Feelings
tags: quote
fileClass: Quotes
title: Voltaire
creation date: 2024-01-31
modification date: 2024-01-31
---
