---
quote: “It’s only when the tide goes out that you learn who’s been swimming naked.”
source: 
topics: Finance
tags: quote
fileClass: Quotes
title: Warren Buffett
creation date: 2024-01-31
modification date: 2024-01-31
---
