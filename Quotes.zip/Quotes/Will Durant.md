---
attribution:
  - Will Durant
source: 
tags:
  - quote
topics:
  - health
  - mental health
creation date: 2024-01-12
modification date: 2024-01-31
fileClass: Quotes
title: Will Durant
---

# Will Durant

 "Health lies in action, and so it graces youth. To be busy is the secret of grace, and half the secret of content. Let us ask the gods not for possessions, but for things to do; happiness is in making things rather than in consuming them."

— Will Durant
