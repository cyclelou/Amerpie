---
quote: “Things fall apart; the centre cannot hold; / Mere anarchy is loosed upon the world . . . And what rough beast, its hour come round at last, / Slouches toward Bethlehem to be born?”
source: The Second Coming
topics: Philosophy,Poetry,Politics
tags: quote
fileClass: Quotes
title: William Butler Yeats
creation date: 2024-01-31
modification date: 2024-01-31
---

# William Butler Yeats
