---
quote: “Read, read, read. Read everything—trash, classics, good and bad, and see how they do it. Just like a carpenter who works as an apprentice and studies the master. Read! You’ll absorb it. Then write. If it is good, you’ll find out. If it’s not, throw it out the window.”
source: 
topics: Reading,Writing
tags: quote
fileClass: Quotes
title: William Faulkner
creation date: 2024-01-31
modification date: 2024-01-31
---
