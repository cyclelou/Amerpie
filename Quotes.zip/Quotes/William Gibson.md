---
quote: The future is already here. It’s just not evenly distributed.
source: 
topics: Philosophy
tags: quote
fileClass: Quotes
title: William Gibson
creation date: 2024-01-31
modification date: 2024-01-31
---
