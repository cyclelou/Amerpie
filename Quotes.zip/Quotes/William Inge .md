---
fileClass: Quotes
attribution:
  - William Inge
source: 
tags:
  - quote
topics:
  - happiness
creation date: 2024-01-29
modification date: 2024-01-31
title: "William Inge "
aliases: [William Inge]
linter-yaml-title-alias: William Inge
---

# William Inge

William Inge

The happiest people seem to be those who have no particular cause for being happy except that they are so.
