---
title: William Whewell
url: 
tags:
  - quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - William Whewell
fileClass: Quotes
source: 
topics:
  - Success
---

# William Whewell

"Every failure is a step to success."
