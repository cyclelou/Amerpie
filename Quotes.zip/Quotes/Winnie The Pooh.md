---
quote: Don’t underestimate the value of Doing Nothing, of just going along, listening to all the things you can’t hear, and not bothering.
source: 
topics: Work
tags: quote
fileClass: Quotes
title: Winnie The Pooh
creation date: 2024-01-31
modification date: 2024-01-31
---

# Winnie The Pooh
