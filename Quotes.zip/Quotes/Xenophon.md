---
title: Xenophon
url: 
tags:
  - quote
creation date: 2024-02-07
modification date: 2024-02-07
attribution:
  - Xenophon
fileClass: Quotes
source: 
topics:
  - Praise
---

# Xenophon

The sweetest of all sounds is praise.
