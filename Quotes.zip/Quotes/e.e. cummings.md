---
quote: To be nobody but yourself in a world which is doing its best, night and day, to make you everybody else, means to fight the hardest battle which any human being can fight; and never stop fighting
source: 
topics:
  - Philosophy,Self improvement
tags:
  - quote
fileClass: Quotes
title: e.e. cummings
creation date: 2024-01-31
modification date: 2024-01-31
aliases: [e.e. Cummings]
linter-yaml-title-alias: e.e. Cummings
---

# e.e. Cummings
